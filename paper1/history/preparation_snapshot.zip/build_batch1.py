from pathlib import Path
import csv,json,re,zipfile,math,hashlib
from openpyxl import load_workbook
from openpyxl.styles import Font,PatternFill,Alignment
from docx import Document

B=Path(__file__).parent; O=B/'batch1_outputs';O.mkdir(exist_ok=True)
manifest=json.loads((B/'batch1_manifest.json').read_text())
pages={x['batch_id']:json.loads((B/'batch1'/x['batch_id']/'pages.json').read_text()) for x in manifest}

# All summaries below are analyst paraphrases of the supplied PDFs.
info=[
('Zanobetti et al.','2024','10.1016/j.jclepro.2024.143343','Journal article; conceptual process/sustainability model','Supporting — capture/avoidance distinction',
 'A 36 MW LNG cruise-ship case compares amine scrubbing, advanced cryogenic capture, membranes and adsorption using technical, economic, environmental and social indicators. Only amine scrubbing and advanced cryogenic capture meet the case-specific onboard integration constraints. At 95% capture, reported CO2 avoidance is 85.7% and 77.5%, respectively (p8, Table 7).',
 'Use to explain why capture fraction is not avoided-emissions fraction. Thermal and electrical demands are per kg CO2 AVOIDED, not per kg captured. The reported sustainability footprint is an aggregated index, not a CO2 emission factor.',
 'Cruise-ship exhaust capture is not bulk CO2 cargo transport; LNG cold integration and waste-heat assumptions are not transferable to an ordinary CO2 carrier. Supplementary process inputs were not supplied.'),
('Kawashiri, Kashihara & Fukada','2023','10.33313/387/045','AISTech proceedings; Rist-diagram calculation','Peripheral — alternative source-process boundary',
 'A carbon-recycling blast-furnace calculation compares methane recycling with direct hydrogen injection. Table 1 (p6) reports carbon consumption of 425, 324 and 293 kg/t hot metal for conventional, hydrogen and recycling cases; corresponding reported reductions are 24% and 31%.',
 'Use only if choosing a Japanese steel source or discussing alternative decarbonisation. Keep hot-metal output constant and include hydrogen/methanation utilities when constructing a full-system comparison.',
 'Recycled methane carbon is excluded from the paper\'s specific carbon-consumption accounting (p2). This is not geological storage or a whole-chain CCS LCA; the 31% cannot be used as a storage-retention or capture factor.'),
('García-Tenorio Corcuera & Petrakopoulou','2025','10.1016/j.clet.2025.101002','Journal article; hypothetical power-plant lifecycle-energy model','Supporting — energy boundary and capture penalties',
 'Hypothetical UK and Australian natural-gas and coal cases account for fuel preparation, conversion and CCS. The reference capture fraction is 95%. Table 3 (p5) assembles capture, compression and injection energy data from other publications. Results show strong dependence on fuel preparation and capture assumptions.',
 'Use the process inventory structure and sensitivity logic. Literature inputs in its Table 3 remain secondary evidence for the underlying technologies. Reported total efficiency is an energy-accounting metric, not net GHG mitigation.',
 'Several unit/summary problems require resolution before calibration: MJ/MWnet lacks an explicit time basis in the reported energy metric; abstract says losses exceed 50% in both fuels whereas detailed NG results reach about 49%; body p9 labels the 3.6/8.43 Mt/year comparison at 90% capture but conclusion p10 says 95%. Do not quote these as harmonised measured penalties.'),
('Pilisi, Ghorbani & Vasantharajan','2012','CMTC-151756','Conference paper; conceptual offshore feasibility/simulation','Japan concept — not injection-ready domestic service',
 'Three ultra-deepwater Japanese sediment cases model shallow subseabed injection under high-pressure, low-temperature gravitational trapping. Table 3 (p10) specifies 5,000 tons/day for each case; injection lasts 25 years, followed by 225 years of migration simulation. Deeper/hotter injection can reverse the density advantage.',
 'Use as an alternative Japanese storage concept and to demonstrate conditional retention and the importance of injection depth/temperature. Preserve the paper\'s original mass unit and speculative technology boundary.',
 'A 2012 feasibility concept with unavailable offshore storage/injection vessels at the time of publication is not evidence of present service availability. Large assumed injection rates are not tested deliverability. Simulated immobility is not a measured permanent-retention fraction or proof of greater safety across sites.'),
('Carpenter; synopsis of Sabzabadi, Gladman & Billingsley','2025','SPE-1225-0011-JPT; synopsis of SPE-225882','JPT technical-paper synopsis; underlying paper not supplied','High conceptual relevance — realised deliverability',
 'The synopsis attributes Gorgon constraints to water treatment/reinjection and pressure management rather than failure of CO2 containment. It reports August 2019 injection start, a design rate described as 150 kg/s or 4 Mt/year, and four water-production wells. More brine cannot be extracted if its receiving formation cannot accept treated water.',
 'Use as secondary operational context: effective CO2 delivery depends on auxiliary water-disposal systems, not just CO2 well injectivity. Track source chronology and independent verification.',
 'Do not present the synopsis as the underlying full technical paper or an audited current operational dataset. It prints sustained injection as “1.6 tonnes per year” (p3); retain the text and flag the apparent scale/unit error. Do not silently replace it with 1.6 Mt/year. Continuous annualisation of 150 kg/s also differs from 4 Mt/year unless an operating factor is assumed.'),
('Rashidi et al.','2024','ARMA-IGS-2024-0222','Conference paper; coupled-model-informed wellbore stability','High — downtime and completion feasibility',
 'An offshore Sarawak injector is assessed during drilling, brine displacement, injection and stoppages using stress, pressure and temperature outputs from a thermal/dynamic/geomechanical model. Cooling and changing wellbore support cause different shear/tensile failures over time. A perforated liner is selected instead of an unsupported openhole.',
 'Use to justify interruption/restart constraints and time-dependent usable injection service. Temperature reductions of 78 and 139 degrees Fahrenheit at later stages are differences, not absolute temperatures.',
 'Pressure-gradient equivalents in ppg and failure intervals are well-specific simulated conditions. They do not establish a general outage probability, annual rate reduction or universal completion design.'),
('Kukuu et al.','2025','10.2118/225812-MS','Conference paper; history-matched reservoir forecast','Core — named Japanese domestic candidate',
 'Higashi-Niigata models 100 geological realisations, selecting 10 after history matching. Case A uses three CO2 injectors; Case B adds three pressure-relief wells. Injection is assumed from 1 January 2029 to 1 January 2050. Case A reaches its pressure limit around 2040; pressure relief increases injection volume by approximately 25–30% (p8).',
 'Best supplied Japanese evidence for a pressure-limited domestic profile and a pressure-management sensitivity. The forecast provides a shape and relative improvement, not a confirmed commercial injection service.',
 'Figures 11/17/19 lack visible numerical vertical-axis scales in the supplied PDF (visually checked pp7/9). Absolute injected tonnes and pressure values cannot be reliably digitised. Obtain numerical annual series, initial pressure and well/service access before calibration. Do not invent a Mt/year profile from the relative uplift.'),
('Charoensuk et al.','2025','10.4043/35887-MS','Conference paper; steady-state and transient flow assurance/design','Core — Malaysian injection operating envelopes',
 'A Sarawak development targets up to 2.0 Mt/year through a 40 km offshore pipeline into shallow/intermediate/deep depleted reservoirs. Early-life thermal/hydraulic limits constrain the shallow case to 37.5% and deep case to 80% of well design capacity under specified conditions. An insulated pipeline is selected over offshore heating and gas-phase transport.',
 'Use to represent injection limits as functions of reservoir pressure, arrival temperature, flow and startup state. Table 4 (p10) gives relative energy/cost differences and 60,000 tCO2/year extra GHG for the electric-heater alternative relative to insulation.',
 'Design/forecast, not measured storage performance or access for imported Japanese CO2. The system handles CO2 separated from sour-gas production, so its industrial counterfactual differs. The paper labels a critical pressure as 73 barg (p3); retain as printed and do not confuse this with absolute-pressure property data.'),
('Nik Kamaruddin et al.','2019','IPTC-19491-MS','Conference paper; calibrated 4-D reservoir geomechanics','Core — site-specific pressure constraint',
 'A Malaysian carbonate Field X model uses field subsidence and laboratory-derived compaction/creep properties. It recommends maximum injection reservoir pressure of 4,000 psi with a 600 psi safety margin, while minimum horizontal stress during injection is 4,600–6,200 psi (p13).',
 'Use to justify a pressure-constrained deliverability envelope and explicit geological uncertainty. Modelled compaction, seabed movement and fault displacement are conditional outcomes, not annual capacities.',
 'An anonymised field is not a named storage service. The pressure ceiling cannot be transferred to another Malaysian sink or converted directly into tonnes/year without injectivity and well data. Planned 2024 injection start is a 2019 scenario assumption, not evidence it occurred.'),
('Hamid','2026','10.4043/36331-MS','Conference paper; exploratory pressure-aware economic dispatch','Core novelty context; inputs not site data',
 'A four-reservoir hub example supplies up to 10 Mt/year over 20 years with a five-year ramp. Transport distance, reservoir pressure evolution and injectivity influence annual allocation. A far-only route is reported at about USD148 million versus USD230 million in the compared configuration (p11).',
 'Use as prior art for dynamic pressure/distance allocation, with emphasis on its screening scope. The paper\'s body describes economic dispatch rather than an implemented and reported full MILP comparison.',
 'Inputs are explicitly modified/anonymised (p7). Average reservoir pressure is constrained but flowing bottomhole pressure is allowed above the fracture limit (pp10/12); such cases are not demonstrated injection-feasible. Do not inherit this as a safety constraint for Paper 1. Annual pipeline sizing also needs a fixed-design feasibility check.'),
('Tan, Musa & Nik Kamaruddin','2024','ARMA-IGS-2024-0183','Conference paper; analytical geomechanical screening','Core — thermal sensitivity of safe pressure',
 'An offshore Peninsular Malaysia Field X assessment uses eight offset wells and an analytical caprock/fault workflow. With estimated 50°C cooling, recommended pressures for Seals A–D fall from 2153/2731/3264/3701 psi to 1632/2209/2739/3178 psi (pp5–6, Tables 2–3).',
 'Use paired isothermal/cooled pressure limits to motivate thermal sensitivity in deliverability, not fixed universal pressure. Distinguish screen-level correlations, assumed degradation and field calibration.',
 'No measured rock properties were available for the selected field (p4). The up-to-26% stiffness/strength reduction and up-to-10% Poisson-ratio increase are database-based sensitivity evidence (p3), not directly measured at this site. The text extraction displaces psi/psia headers; values were visually checked and original header labels preserved.'),
('Hosseinzadeh et al.','2026','10.2118/234571-MS','Conference paper; isothermal coupled reservoir/geomechanics model','Core — Australian conceptual sink and scope limits',
 'South-West Hub/Harvey modelling describes a conceptual 800,000 tCO2/year, 30-year plan, nine injection wells and a reference BHP constraint of 360 bar at 2948 m (p18). No significant fault failure is predicted for the modelled isothermal pressure-driven response.',
 'Use the published reference-case configuration as a scenario, not operational supply. Explicitly retain the omitted thermal stresses and the difference between the 30-year injection programme and 1,000-year containment objective.',
 'Conference modelling does not establish present commercial availability or shipping access. Some text requires author/data clarification: 37/32 is not 1.125 (p18), a stress gradient is printed only in MPa, and Figure 10\'s pore-pressure range needs datum/quantity reconciliation. These do not justify silently changing reported numbers.'),
('Razali et al.','2024','10.4043/34777-MS','Conference paper; compositional aquifer simulation','Core — pressure sink versus theoretical resource',
 'A Malaysian restricted aquifer (K reservoirs, Z field) is simulated with and without brine production. Cumulative effective gas volumes are 4.9 Bscf without production, 80.13 Bscf with one injector/one producer, and 95.44 Bscf with two injectors/one producer. These are about 3%, 51% and 61% of theoretical volume (pp8–13).',
 'Direct evidence that nominal pore-volume resource does not equal delivered storage. Model pressure-management cases together with water production, CO2 breakthrough termination and its energy/disposal burden.',
 'The authors ultimately do not recommend proceeding with Z-field injection planning because volume is small and inputs uncertain (p13). Do not select it as a proven Malaysian sink. Bscf/MMscf cannot be turned into tonnes without declared standard conditions/composition and conversion. PVT/SCAL and permeability include analogue-based inputs.'),
('Wagner & Wiese','2018','10.1016/j.ijggc.2018.04.009','Journal article; multi-physical inverse model with field observations','Validation — injectivity impairment and uncertainty',
 'Ketzin inversion jointly uses hydraulic/CO2 pressure, arrival times and geoelectric observations. A near-injector permeability reduction to about 15 mD (roughly eightfold) and equivalent skin of 10 explain pressure overburden attributed to salt precipitation. Observed/modelled arrivals are 21.7/21.8 days and 271/283 days (p6).',
 'Use as evidence for near-well injectivity changes and multi-observation validation. Distinguish calibrated skin/permeability from independent field measurements.',
 'The earlier hydraulic-barrier hypothesis is not substantiated after suspect data are removed, but non-uniqueness means a barrier is not excluded (p8). Do not turn the eightfold local permeability change into an eightfold annual site-capacity decline.'),
('Class et al.','2015','10.1016/j.egypro.2015.07.883','Proceedings article; field history matching with two simulators','Validation — correlated inputs and held-out prediction',
 'Ketzin models match pressure and CO2 arrival despite strong porosity/permeability correlations. Table 3 (p5) compares observed arrival times of 21.7 and 271 days with alternative simulated arrivals; pressure-only fit does not uniquely identify spatial geology.',
 'Use separate calibration and prediction periods, record observation timing uncertainty and test alternative parameter sets. The 2018 inversion paper refines some earlier interpretations; these are related studies of one site, not independent replications.',
 'Table 1 prints a pressure gradient of 1.14 Pa/m (p4, visually confirmed). This is implausible as a normal brine hydrostatic gradient; hold this value pending correction, rather than insert a presumed exponent. Arrival dates depend on sensor location and completion, not merely plume contact.'),
('Couëslan et al.','2014','10.1016/j.egypro.2014.11.306','Proceedings article; integrated field monitoring','Validation — realised injection and containment monitoring',
 'Decatur couples time-lapse saturation logs, multilevel pressure, fluid chemistry, seismic and microseismic data. Approximately 925,300 tonnes had been injected by 1 September 2014 (p2), against a one-million-tonne three-year goal. Low-permeability layers restrict upward CO2 migration in the monitored interval.',
 'Use monitoring-based calibration, separation of pressure front and CO2 plume, and interruptions as operational factors. Retain as-of dates for cumulative injected mass.',
 'This is a US ethanol-fermentation source, not a fossil Japanese industrial baseline. Monitoring evidence of no detected migration is not a numerical permanence guarantee. The Zone 4 depth is inconsistent between p3 text and the other monitoring evidence; do not use that single text depth uncritically.'),
('Liebscher et al.','2013','10.1016/j.ijggc.2013.02.019','Journal article; observed pilot operation and monitoring','Validation — operating rates, pressure and measurement quality',
 'Ketzin recorded 61,396 t by September 2012. Typical injection was 1–3 t/hour, with 3,250 kg/hour nominal plant capacity. BHP rose from about 62 bara initially to 73 bara after five days, then stabilised around 73–79 bara (pp3–5). Downhole monitoring is needed because wellhead signals alone can mislead.',
 'Use actual operation as a small-scale validation benchmark, preserving measurement uncertainty and stop/restart behaviour. Monthly rates and pressure can test a simplified pressure-response implementation.',
 'Pilot rates and reservoir data are not commercial Japanese/Malaysian/Australian service. The 61,396 t as-of-2012 and later approximately 67,000 t final injection in other Ketzin papers refer to different dates, not contradictory estimates. Correct for gauge/absolute pressure before comparison.'),
('Strandli, Mehnert & Benson','2014','10.1016/j.egypro.2014.11.483','Proceedings article; pressure-based field history matching','Validation — plume tracking and limits of fit',
 'A layered radially symmetric Decatur model is calibrated over 40 days and compared against two years of pressure data. It uses an approximately 150 mD, 23–24 m injection interval and predicts mainly lateral migration below low-permeability layers (p8).',
 'Use multilevel pressure and held-out time periods for validation. The larger-time mismatch is expressly unresolved; a successful short fit is not proof of long-term prediction.',
 'Isothermal 49°C model neglects salinity explicitly, then rescales permeability for viscosity; several parameters are calibrated. US biogenic source and pressure-history fit do not define international route lifecycle emissions or a universal retained fraction.'),
('Jeong et al.','2025','10.1016/j.energy.2025.135837','Journal article; HYSYS/PSO process optimisation','Core — BOG loss and auxiliary-energy accounting',
 'Six reliquefaction process/pressure cases are compared at 0.05/0.10/0.15 mol% liquid nitrogen impurity. A 50,000 m3 carrier is assumed with 98% laden and 5% ballast filling, 0.1%/day mass-based boil-off, and 4000 operating hours/year for each voyage state. Annual CO2 includes purge plus auxiliary-generator emissions. Table 6 and Appendix A.6 have been transcribed into structured scenario data.',
 'Use process-specific BOG and power trade-offs to avoid treating all boil-off as a cargo loss. Derived generator factor is 0.633185 kgCO2/kWh from 197.5 g fuel/kWh and 3.206 tCO2/t fuel, excluding upstream fuel impacts. The annual-case comparison is not propulsion or full-chain LCA.',
 'Preserve the case/impurity combinations. Text on p8 claiming 79.2–84.6% and 89.8–95.6% reductions in compression-power emissions appears inconsistent with its much smaller stated power reductions and constant generator factor. Annual schedule (6 voyages/year and 8000 operating hours) is a modelling assumption, not a route-calibrated schedule.'),
('Deligiannis et al.','2026','10.1016/j.ijggc.2025.104544','Journal article; COSSMOS thermodynamic interface simulation','Core — terminal pressure mismatch and energy',
 'LP ships (7–10 bara) interface with MP terminals (12–20 bara). Case specifications use three 7300 m3 tanks (sensitivity 5840–8760 m3 each), 96% filling and 4% heel. Tables 6–7 (pp13–14) give nine pressure-pair cases with and without loading-stream subcooling. Tables are transcribed with mass, power, cost and original specific-demand labels.',
 'Use for explicit loading/unloading and vapor-return conditioning. Avoid a route-independent fixed terminal factor and avoid double-counting power already included in an integrated process result. Pressure units here are explicitly absolute.',
 'Specific-demand labels kWel/ton are dimensionally inconsistent with the stated kWh/ton intent; several values are consistent with a 12-hour transfer. Derived conversions are separate and conditional. Some textual claims of lower subcooler cost are case dependent; the full nine-case table must govern. These are process energy/cost results, not route-wide GHG factors.')]
# DOI of B1-20 is verified from the PDF rather than inferred from issue year below.
for i,row in enumerate(info):
 if i==19:
  text=' '.join(pages['B1-20'][:2]);matches=re.findall(r'10\.1016/j\.ijggc\.\d{4}\.104544',text)
  if matches:info[i]=tuple(list(row[:2])+[matches[0]]+list(row[3:]))

studies=[]
for m,d in zip(manifest,info):
 authors,year,doi,typ,role,summary,use,limits=d
 studies.append([m['batch_id'],Path(m['result']['path']).stem,authors,year,doi,typ,role,m['pages'],'Reviewed: methods/results and relevant inventories; visual checks for selected tables/figures',summary,use,limits,m['result']['path'],m['sha256']])

R=[]
def add(n,param,val,unit,p,loc,kind='Model input',scenario='',note='',normal='',nunit='',conversion=''):
 sid=f'B1-{n:02}'
 assert 1<=p<=len(pages[sid]),(sid,p)
 flag='EXTRACTED from supplied PDF; not independently validated'
 if 'HOLD' in note:flag='HOLD — source inconsistency / ambiguous unit'
 if kind.startswith('Derived'):flag='DERIVED arithmetic; source assumptions retained'
 R.append([f'E{len(R)+1:04}',sid,param,str(val),unit,p,loc,kind,scenario,flag,note,str(normal),nunit,conversion])
def block(n,text):
 for ln in text.strip().splitlines():
  a=ln.split('|');a+=['']*(8-len(a))
  param,val,unit,p,loc,kind,scenario,note=a[:8]
  add(n,param,val,unit,int(p),loc,kind or 'Model input',scenario,note)

block(1,'''
Propulsion power|36|MW|6|Section 3|Model input|Hyperion-class cruise ship|Not a CO2 cargo carrier
Annual trip time|6264|h/year|6|Section 3|Model input||
Single voyage duration|10|days|6|Section 3|Model input||
Reference capture efficiency|95|%|8|Table 7|Simulated result|AS and A3C|Capture fraction differs from avoidance
CO2 avoidance|85.7|%|8|Table 7|Simulated result|Amine scrubbing|Specific LNG cruise-ship energy integration
CO2 avoidance|77.5|%|8|Table 7|Simulated result|Advanced cryogenic capture|Not whole-chain storage mitigation
Thermal duty|3.55|MJ/kg CO2 avoided|8|Table 7|Simulated result|Amine scrubbing|Denominator is avoided CO2
Electrical consumption|0.95|MJ/kg CO2 avoided|8|Table 7|Simulated result|Amine scrubbing|Denominator is avoided CO2
Thermal duty|12.14|MJ/kg CO2 avoided|8|Table 7|Simulated result|Advanced cryogenic capture|
Electrical consumption|1.98|MJ/kg CO2 avoided|8|Table 7|Simulated result|Advanced cryogenic capture|
Available LNG cold duty|approximately 1.28|MW|7|Section 4.2|Model result/input||Specific LNG integration
CO2 saturated-liquid storage pressure|22.6|bar as printed|7|Section 4.2|Model input||Do not substitute for LP ship cargo regime
Heat-exchanger minimum approach|5|K|7|Section 4.2|Model input||
KPI uncertainty interval|±20|% of baseline KPI|5|Sensitivity methodology|Analyst assumption in source||Not measured uncertainty distribution
''')
block(2,'''
Conventional carbon consumption|425|kg/t hot metal|6|Table 1|Calculated result|Conventional BF|Recycled carbon accounting differs from full LCA
Hydrogen-case carbon consumption|324|kg/t hot metal|6|Table 1|Calculated result|Hydrogen BF|
Recycling-case carbon consumption|293|kg/t hot metal|6|Table 1|Calculated result|Carbon recycling BF|
Hydrogen-case CO2 reduction|24|%|6|Table 1|Calculated result|Hydrogen BF|No geological storage
Recycling-case CO2 reduction|31|%|6|Table 1|Calculated result|Carbon recycling BF|Recycled methane carbon excluded; no full-system LCA
Shaft efficiency|0.9|fraction|4|Calculation Result|Model input||
Unit heat loss|420|MJ/t hot metal|4|Calculation Result|Model input||
Hot-metal/slag temperature|1500|degrees C|4|Calculation Result|Model input||
Conventional pulverised-coal ratio|150|kg/t hot metal|4|Calculation Result|Model input||
Methane injection range|0–200|kg/t hot metal|4|Calculation Result|Model input|Recycling BF|
Hydrogen injection range|0–60|kg/t hot metal|4|Calculation Result|Model input|Hydrogen BF|
Theoretical flame temperature limits|2000–2300|degrees C|3|Operational limits|Model input||
Top-gas minimum temperature|100|degrees C|3|Operational limits|Model input||
Reduction in required heat|approximately 1000|MJ/t hot metal|7|Discussion|Calculated result|Recycling versus conventional|Not a capture-energy requirement
''')
block(3,'''
Reference CO2 capture fraction|95|%|5|Section 4|Model input|Hypothetical UK/Australia plants|Not measured
Natural-gas plant conversion efficiency|49|%|5|Case-study assumptions|Model input||
Coal plant conversion efficiency|35.8|%|5|Case-study assumptions|Model input||
Boiler efficiency|98|%|5|Case-study assumptions|Model input||
Natural-gas mass flow|36.05|kg/s|5|Case-study assumptions|Calculated input||
Coal mass flow|55.92|kg/s|5|Case-study assumptions|Calculated input||
CO2 capture heat range|3.2–5.5|MJ thermal/kg CO2|5|Table 3; Luis 2016|Secondary literature input||Underlying source not supplied
CO2 capture heat range|3.6–3.8|MJ thermal/kg CO2|5|Table 3; Biermann 2022|Secondary literature input||Underlying source not supplied
CO2 capture heat|0.89|MJ thermal/kg CO2|5|Table 3; Lee 2023|Secondary literature input|100% capture per table|Not comparable without technology boundary
CO2 capture heat|3.9|MJ thermal/kg CO2|5|Table 3|Secondary literature input||
CO2 compression electricity|0.288–0.432|MJ electrical/kg CO2|5|Table 3; Jackson/Brodal 2019|Secondary literature input||Separate from thermal duty
CO2 compression electricity|0.234|MJ electrical/kg CO2|5|Table 3; Bisinella 2021|Secondary literature input||
Short CO2 pipeline route|80|km|5|CO2 transport assumptions|Model input||One compressor station
Long CO2 pipeline route|440|km|5|CO2 transport assumptions|Model input||Five compressor stations
Fuel pipeline route|290|km|4|Fuel transportation assumptions|Model input||Fuel transport, not CO2 transport
NG total efficiency at 100% capture|30.79|%|7|Section 4|Simulated result|UK; lifecycle boundary|
Coal total efficiency at 100% capture|21.42|%|7|Section 4|Simulated result|UK; lifecycle boundary|
NG total efficiency at 100% capture|29.06|%|7|Section 4|Simulated result|Australia; lifecycle boundary|
Coal total efficiency at 100% capture|20.98|%|7|Section 4|Simulated result|Australia; lifecycle boundary|
NG relative efficiency drop at 100% capture|49.01|% relative decrease|7|Section 4|Simulated result|Australia|Contrasts with abstract over-50%-for-both summary
Coal relative efficiency drop at 100% capture|63.08|% relative decrease|7|Section 4|Simulated result|Australia|Do not interpret as percentage-point loss
Sensitivity perturbation|±15|%|9|Section 4.1|Model input||Not probability or confidence interval
''')
block(4,'''
Injection duration|25|years|10|Reservoir Simulations|Model input|Three deepwater sites|Conceptual scenario, not field operation
Post-injection simulation|225|years|10|Reservoir Simulations|Model input||
Total simulation horizon|250|years|10|Reservoir Simulations|Model input||Not empirically verified permanence
Injection rate per case|5000|tons/day as printed|10|Table 3|Model input|Each of three cases|Assumed rate, not demonstrated deliverability
Sediment model thickness|328|ft|10|Table 3|Model input|Each case|
Seafloor temperature|35|degrees F|10|Table 3|Model input|Each case|
Water depth|9281|ft|10|Table 3|Model input|Japan Sea|
Water depth|9850|ft|10|Table 3|Model input|Offshore Shikoku|
Water depth|18158|ft|10|Table 3|Model input|Pacific N40 E150|
Seabed pressure|4150|psi|10|Table 3|Model input|Japan Sea|Pressure datum not independently resolved
Seabed pressure|4405|psi|10|Table 3|Model input|Offshore Shikoku|
Seabed pressure|8120|psi|10|Table 3|Model input|Pacific N40 E150|
Porosity|60–80|%|10|Table 3|Model input|Japan Sea|
Porosity|42–66|%|10|Table 3|Model input|Offshore Shikoku|
Porosity|67–83|%|10|Table 3|Model input|Pacific N40 E150|
Permeability|0.1–40|mD|10|Table 3|Model input|Japan Sea|
Permeability|7.5–18.5|mD|10|Table 3|Model input|Offshore Shikoku|
Permeability|2 microdarcy–1.6 mD|mixed original units|10|Table 3|Model input|Pacific N40 E150|Do not read lower endpoint as 2 mD
Geothermal gradient|6|degrees F/100 ft|10|Table 3|Model input|Japan Sea and Shikoku|Temperature difference conversion required
Geothermal gradient|2|degrees F/100 ft|10|Table 3|Model input|Pacific N40 E150|
Injection casing conveyance estimate|3000|tons/day|6|Ultra-deepwater injection well|Engineering estimate|7-inch casing|Not reservoir acceptance rate
Perforation interval range|10–30|ft|6|Ultra-deepwater injection well|Conceptual design||
''')
block(5,'''
Design injection mass rate|150|kg/s|3|Gorgon overview|Secondary project report|Gorgon|Not identical to 4 Mt/year at continuous operation
Stated design annual injection|4|million tonnes/year|3|Gorgon overview|Secondary project report|Gorgon|Operating factor unspecified
CO2 injection start|August 2019|date|3|Gorgon overview|Secondary project report|Gorgon|
Sustained injection as printed|1.6|tonnes/year|3|Pressure-management discussion|Secondary project report|Gorgon|HOLD: apparent scale/unit error; do not silently change to Mt/year
Onshore CO2 pipeline length|7|km|3|Gorgon overview|Secondary project report|Barrow Island|Not cross-border sea route
Maximum injector count|9|wells|3|Gorgon overview|Secondary project report|Three drill centres|
Water-production wells|4|wells|3|Gorgon overview|Secondary project report||
Planned water-reinjection well expansion|2 to 4|wells|4|Mitigation discussion|Secondary plan||Not confirmed implemented
Expected production life|40|years|3|Gorgon overview|Secondary project report||
Estimated cumulative CO2 injection|120|million tonnes|3|Gorgon overview|Secondary project forecast||Not observed cumulative stored volume
''')
block(6,'''
First injection scenario year|2025|year|3|Figures 3–6|Model input|Injector I-3|Not observed start date
Intermediate scenario year|2030|year|4|Figures 7–8|Model input||
Final scenario year|2048|year|4|Figures 9–10|Model input||23 years after assumed start
Drilling mud weight|11.3|ppg|3|Figure 3|Model input|End drilling|Equivalent mud-weight basis; not absolute psi
Brine displacement density|12.3|ppg|3|Figure 4|Model input|Before injection|
Initial injection pressure gradient|13.8|ppg equivalent|3|Figure 5|Model input|2025|
Initial stoppage reservoir-pressure gradient|10.8|ppg equivalent|3|Stoppage discussion|Model input|2025|
Intermediate injection gradient|12.3|ppg equivalent|4|Figure 7|Model input|2030|
Intermediate stoppage reservoir gradient|11.75|ppg equivalent|4|Discussion|Model input|2030|
Final injection gradient|13.0|ppg equivalent|4|Figure 9|Model input|2048|
Final stoppage reservoir gradient|12.45|ppg equivalent|4|Discussion|Model input|2048|
Cooling after five years|approximately 78|degrees F temperature reduction|5|Discussion|Simulated result|2030|Difference, not absolute Fahrenheit temperature
Final cooling|139|degrees F temperature reduction|5|Discussion|Simulated result|2048|Difference, not absolute Fahrenheit temperature
''')
block(7,'''
Initial geological realisations|100|realisations|4|Model Overview|Model setup||Not probability sample of commissioned service
Selected history-matched realisations|10|realisations|4|Model Overview|Model setup||
Seal thickness|50–120|m|3|Seal suitability|Site description||
Model dimensions|9 x 11 x 1.8|km|4|Table 3|Model setup||Original vertical length 1800 m
Active grid cells|276410|cells|4|Table 3|Model setup||
Injectors per forecast case|3|wells|6|Table 8|Scenario input|A and B|
Pressure-relief wells|0|wells|6|Table 8|Scenario input|A|
Pressure-relief wells|3|wells|6|Table 8|Scenario input|B|
Assumed injection window|2029-01-01 to 2050-01-01|dates|6|Table 8|Scenario input||Do not treat as full calendar years 2029–2050 inclusive
Simulation window|2029-01-01 to 2130-01-01|dates|6|Table 8|Scenario input||
Pressure-limit onset|around 2040|year|7|Case A discussion|Simulated result|A|No absolute pressure value disclosed in readable text
Injection-volume increase|approximately 25–30|% relative to A|8|Case B discussion|Simulated result|B with relief wells|No absolute tonnage recoverable from graphs
Injection pressure limit|Initial reservoir pressure|relative threshold|6|Table 8|Model input||Absolute numerical value not supplied in visible table
''')
block(8,'''
System design injection|up to 2.0|MtCO2/year|1|Abstract|Design target|Sarawak depleted reservoirs|Not observed or contracted imported CO2 service
Offshore transport distance|40|km|2|Project Overview|Design input||
CO2 purity before pipeline|above 99|mol%|3|Fluid characterisation|Design specification||
Hydrocarbon carryover|below 1|mol%|3|Fluid characterisation|Design specification||
Water content|at most 40|ppmv|5|Hydrate assessment|Design specification||
Shallow reservoir depth|approximately 650|m TVD|3|Table 1|Design input||
Intermediate reservoir depth|approximately 1550|m TVD|3|Table 1|Design input||
Deep reservoir depth|approximately 1700|m TVD|3|Table 1|Design input||
Shallow reservoir start/end pressure|25 / 70|barg|3|Table 1|Scenario input||Gauge pressures
Intermediate reservoir start/end pressure|30 / 170|barg|3|Table 1|Scenario input||
Deep reservoir start/end pressure|50 / 190|barg|3|Table 1|Scenario input||
Minimum pipeline/platform operating pressure|above 80|barg|4|Fluid characterisation|Design requirement||
Downstream choke piping minimum temperature|-46|degrees C|5|Design constraints|Design input||
SCSSV minimum temperature|-7|degrees C|5|Design constraints|Design input||
Bottomhole hydrate-avoidance threshold|above 10|degrees C|5|Hydrate assessment|Design constraint||
Intermediate turndown SCSSV temperature|-12.7|degrees C|7|Flow assurance result|Simulated result|Before elevated injection temperature|
Selected upstream choke injection temperature|50|degrees C|7|Early-life operation|Design choice||Case-specific optimum
Intermediate BHT at selected temperature|17|degrees C|7|Early-life operation|Simulated result||
Alternative higher injection temperature|60|degrees C|7|Early-life sensitivity|Scenario input||
Flow reduction at higher temperature|approximately 20|%|7|Early-life sensitivity|Simulated result|60C versus selected case|
Shallow early-life flow limit|37.5|% of well design capacity|8|Figure 6 discussion|Simulated constraint||Not a universal site capacity factor
Deep early-life flow limit|80|% of well design capacity|8|Figure 6 discussion|Simulated constraint|80 barg supply|
Reservoir-pressure threshold for seabed-temperature injection|above 50|barg|9|Late-Life Operation|Simulated constraint||Case-specific
Late-life supply pressure change|80 to 100|barg|9|Late-Life Operation|Design input||
Insulated pipeline maximum inlet temperature|110|degrees C|9|Option 1|Design input||
Insulated pipeline U-value|1.5|W/m2/K|10|Option 1; Table 4|Design input||
Insulated/heated/gas pipeline diameters|14 / 12 / 24|inch|10|Table 4|Design input|Insulation / heater / gas phase|
Electric-heater energy increment|50|% versus insulation|10|Table 4|Design comparison||Not absolute kWh/t
Electric-heater CAPEX increment|40|% versus insulation|10|Table 4|Design comparison||
Electric-heater OPEX increment|40|% versus insulation|10|Table 4|Design comparison||
Electric-heater GHG increment|60000|tCO2/year|10|Table 4|Design comparison||System-specific difference, not full-chain intensity
Gas-phase energy increment|-10|% versus insulation|10|Table 4|Design comparison||Hydraulic constraints require extra wells/tubing
Gas-phase CAPEX increment|10|% versus insulation|10|Table 4|Design comparison||
Gas-phase OPEX increment|-10|% versus insulation|10|Table 4|Design comparison||
Initial-startup downstream choke temperature|-64.6|degrees C|11|Transient operations|Simulated result||Operating safeguard required
''')
block(9,'''
Recommended maximum injection reservoir pressure|4000|psi as printed|13|Conclusions; Figure 15 discussion|Recommended scenario limit|Field X|Site-specific; not a national pressure limit
Pressure safety margin|600|psi|13|Conclusions|Safety allowance||
Minimum horizontal stress during injection|4600–6200|psi|13|Figure 15|Simulated result||
Planned injection scenario start|2024|year|7|Stress-step discussion|Scenario input||Not observed commissioning
Injection scenario endpoint|2040|year|13|Conclusions|Scenario input||
Depletion-end subsidence|9.6|ft|7|Subsidence discussion|Simulated result|2003|
Maximum pre-injection subsidence|11.3|ft|7|Subsidence discussion|Simulated result|2013|
GPS subsidence|approximately 11.65|ft|7|Subsidence discussion|Reported field measurement|2014|Supports calibration at same site
Injection seabed uplift|approximately 1|ft|7|Subsidence discussion|Simulated result||
End-injection subsidence|10.6|ft|13|Conclusions|Simulated result||
End-injection reservoir compaction|16|ft|13|Conclusions|Simulated result||
Limited fault displacement|approximately 0.5|cm|13|Conclusions|Simulated result|Five bounding faults|Not a measured leakage rate
''')
block(10,'''
Hub supply limit|10|MtCO2/year|7|Case Study|Scenario input|Modified/anonymised inputs|Not named commercial reservoir service
Project life|20|years|7|Case Study|Scenario input||
Demand ramp duration|5|years|7|Case Study|Scenario input||
Candidate reservoirs|4|reservoirs|7|Case Study|Scenario input||
CAPEX multiplier|1.2|dimensionless|7|Cost model|Model input||
Far-only pipeline length|300|km|11|Routing comparison|Scenario input||
Maximum pipeline internal diameter comparison|0.50 to 0.55|m|11|Routing comparison|Simulated result||Annual optimum diameter is not necessarily a buildable changing pipe
Hub-and-spoke cumulative expenditure|approximately 230|million USD|11|Routing comparison|Simulated cost result||Cost base year not declared here
Far-only cumulative expenditure|approximately 148|million USD|11|Routing comparison|Simulated cost result||Not net GHG benefit; BHP feasibility not enforced
Wells per reservoir/pipeline|1|well|12|Limitations|Model input||BHP allowed above fracture limit
''')
block(11,'''
Offset wells for 1D models|8|wells|4|Model construction|Model setup||Rock properties generated from logs, not measured cores
Rock strength/Young modulus degradation|up to 26|% decrease|3|Section 3.3|Database-based sensitivity||Not a measured change at this field
Poisson-ratio change|up to 10|% increase|3|Section 3.3|Database-based sensitivity||
Thermal influence lateral scale|typically within 750|m|3|Thermal Effects|General workflow statement||Not a measured plume radius
Stress transfer ratio upper limit|0.33|dimensionless|5|Caprock integrity|Model input||
Delta-injection-pressure safety factor|1.5|dimensionless|5|Caprock integrity|Model input||Applied to delta pressure; not blanket pressure division
Assumed caprock cooling|50|degrees C reduction|5|Thermal sensitivity|Model input||
Reported maximum pressure reduction|up to 525|psi|5|Thermal sensitivity|Simulated result||Paired tables give 521–525 psi reductions
Mapped faults|26|faults|6|Fault stability|Model setup||Only relevant major faults analysed
Fault-friction reduction sensitivities|10 and 20|%|6|Fault stability|Scenario input||
''')
for seal,iso,cold,init,current in [('A',2153,1632,1847,450),('B',2731,2209,2050,1200),('C',3264,2739,2457,1100),('D',3701,3178,3015,1100)]:
 add(11,'Recommended maximum injection pressure',iso,'psi as table header',5,'Table 2 (visually checked)','Recommended scenario limit',f'Seal {seal}; isothermal','Do not relabel maximum column psia; source header says psi')
 add(11,'Recommended maximum injection pressure',cold,'psi as table header',6,'Table 3 (visually checked)','Recommended scenario limit',f'Seal {seal}; 50C cooling','Not transferable to other formations')
 add(11,'Initial reservoir pressure below seal',init,'psi as table header',5,'Table 2 (visually checked)','Model input',f'Seal {seal}')
 add(11,'Estimated current reservoir pressure below seal',current,'psia as table header',5,'Table 2 (visually checked)','Model input',f'Seal {seal}','Source distinguishes psi/psia column labels; clarify datum before combination')
 add(11,'Reduction in recommended pressure with cooling',iso-cold,'psi difference',6,'Tables 2–3','Derived comparison',f'Seal {seal}','Paired arithmetic only',iso-cold,'psi',f'{iso} - {cold}')
block(12,'''
Conceptual total injection rate|800000|tCO2/year|18|Coupling of models|Scenario input|South-West Hub/Harvey|Conceptual programme, not observed storage service
Injection period|30|years|18|Coupling of models|Scenario input||
Reference BHP limit|360|bar as printed|18|Reference Case|Model input||Pressure datum requires confirmation
BHP reference depth|2948|m|18|Reference Case|Model input||
Reference injection wells|9|wells|18|Reference Case|Model input||Do not divide equally without well allocation
Completion in lowest formation section|250|m|18|Reference Case|Model input|Wonnerup|
Plume-depth objective|below 800|m TVDss|18|Coupling of models|Model objective||Not observed containment guarantee
Containment simulation objective|1000|years|18|Coupling of models|Model objective||Separate from injection period
Vertical stress range|17–60|MPa|17|Stress modelling|Simulated result||
Maximum horizontal stress range|22–75|MPa|17|Stress modelling|Simulated result||
Minimum horizontal stress range|21–72|MPa|17|Stress modelling|Simulated result||
Sh at 1500 m|32|MPa|18|Boundary conditions|Simulated result||
SH at 1500 m|37|MPa|18|Boundary conditions|Simulated result||
Stated SH/Sh ratio|1.125|dimensionless|18|Boundary conditions|Source statement||HOLD: 37/32 = 1.15625; printed ratio inconsistent
Stated stress gradient|0.18|MPa as printed|18|Boundary conditions|Source statement||HOLD: length denominator missing; do not infer MPa/m
''')
block(13,'''
Injection simulation period|25|years|7|Dynamic modelling|Scenario input|2025–2050|Not operating history
Assumed source injection rate ceiling|60|MMscf/day|8|Base model conditions|Model input||Standard conditions/composition required for mass conversion
Injector BHP ceiling|5000|psi|8|Base model conditions|Model input||Geomechanical constraint
Water-production rate ceiling|30000|bbl/day|8|Base model conditions|Model input||Water treatment/disposal burden not quantified
Water-producer minimum BHP|800|psi|8|Base model conditions|Model input||
Producer CO2 breakthrough stop criterion|1|MMscf/day|8|Base model conditions|Model input||Termination criterion, not leakage to atmosphere
Theoretical storage volume|157.03|Bscf|13|Summary/Conclusion|Calculated resource|Z field|No conversion to mass without standard state
Effective storage; no producer|4.9|Bscf|8|Non-voidage case|Simulated result|1 injector; 0 producer|
Theoretical volume utilised; no producer|approximately 3|%|8|Non-voidage case|Simulated result||
No-producer injection shutdown|200|days after start|8|Non-voidage case|Simulated result||Pressure buildup, not commissioning delay
Effective storage; one producer|80.13|Bscf|10|Voidage case|Simulated result|1 injector; 1 producer|
Theoretical volume utilised; one producer|approximately 51|%|10|Voidage case|Simulated result||
Effective storage; two injectors|95.44|Bscf|12|Optimised case|Simulated result|2 injectors; 1 producer|Authors do not recommend proceeding with Z field
Theoretical volume utilised; two injectors|approximately 61|%|12|Optimised case|Simulated result||
K10 zone permeability|300|mD|10|Injection plateaux discussion|Model input||Other properties include analogue inputs
Optimised total water produced|approximately 40|Mbbl as printed|12|Optimised case|Simulated result||HOLD: verify M-unit convention before converting
''')
block(14,'''
Near-injector permeability|approximately 15|mD|4|Inversion results|Calibrated parameter|Ketzin|Near-well value, not whole-formation permeability
Near-injector permeability reduction|approximately factor 8|ratio|4|Inversion results|Calibrated parameter||Do not scale annual storage by this ratio
Equivalent injection skin|10|dimensionless|1|Abstract; model results|Calibrated parameter||Salt-precipitation interpretation
Overpressure increase|factor 2|ratio versus salt-free|1|Abstract|Calibrated model interpretation||Not total absolute reservoir pressure doubling
Observed CO2 arrival|21.7|days|6|Table 2|Reported observation|Ktzi200|Sensor detection threshold/completion affects timing
Simulated CO2 arrival|21.8|days|6|Table 2|Simulated result|Ktzi200|
Observed CO2 arrival|271|days|6|Table 2|Reported observation|Ktzi202|
Simulated CO2 arrival|283|days|6|Table 2|Simulated result|Ktzi202|
Arrival criterion gas saturation|3|%|2|Monitoring/inversion setup|Model input||Sensor-completion-specific threshold
Arrival relative deviation|0.5 / 4|%|6|Table 2|Simulated fit statistic|Ktzi200 / Ktzi202|Two data points, not independent validation of entire reservoir
''')
block(15,'''
Final injected CO2|approximately 67000|tonnes|1|Abstract|Reported field total|2008–2013 Ketzin|Same project as B1-14/17; different reporting dates
Salinity|0.2|kg salt/kg brine|4|Table 1|Model input||
Pore compressibility|7.2e-10|1/Pa|4|Table 1|Model input||
Vertical/horizontal permeability ratio|1/3|dimensionless|4|Table 1|Model input||
Initial pressure at 639.5 m|62|bar|4|Table 1|Model input||Datum as printed
Initial temperature at 639.5 m|34|degrees C|4|Table 1|Model input||
Temperature gradient|0.03|degrees C/m|4|Table 1|Model input||
Printed pressure gradient|1.14|Pa/m|4|Table 1 (visually checked)|Source statement||HOLD: implausible hydrostatic magnitude; do not invent missing exponent
Residual brine saturation|0.15|fraction|4|Table 1|Model input||
Residual CO2 saturation|0.05|fraction|4|Table 1|Model input||Not a site-scale retained fraction
Observed arrival Ktzi200/Ktzi202|21.7 / 271|days|5|Table 3|Reported observation||
Span-Wagner simulated arrival|18.9 / 272|days|5|Table 3|Simulated result|Ktzi200/Ktzi202|
Peneloux simulated arrival|20.3 / 256|days|5|Table 3|Simulated result|Ktzi200/Ktzi202|
Approach-I matching duration|1286|days|5|Results|Calibration setup||
Forecast comparison end|2193|days after start|5|Results|Prediction setup||Do not describe all as calibration
Approach-II initial calibration period|50|days|4|Model setup|Calibration setup||
Early maximum pressure deviation|2.5|bar|5|Results|Fit statistic||Approximately 3.2% stated
''')
block(16,'''
Project injection goal|1000000|tonnes CO2|2|Introduction|Project target|IBDP|Not observed total at publication
Goal duration|3|years|2|Introduction|Project target||
Injected mass as of 2014-09-01|approximately 925300|tonnes CO2|2|Introduction|Reported field total||Preserve reporting date
Primary Eau Claire seal thickness|approximately 152|m|2|Project Background|Site description||
Mt Simon formation thickness|approximately 453|m|2|Project Background|Site description||
Lower Mt Simon average porosity|20|%|2|Project Background|Reported site estimate||
Lower Mt Simon average permeability|185|mD|2|Project Background|Reported site estimate||Different averaging support from B1-18 injection-zone fit
Low-permeability units|less than 1|mD|2|Project Background|Reported site estimate||
Low-permeability streak depth|2092–2094|m|2|Project Background|Site description||Depth datum needs confirmation
VSP monitoring injected-mass milestones|74000 / 433000 / 730000|tonnes CO2|3|Monitoring results|Reported field milestones||Do not sum as separate injections
Monitoring levels|11|levels|3|Monitoring configuration|Field setup||
''')
block(17,'''
Cumulative injection by September 2012|61396|tCO2|1|Abstract|Reported field total|Ketzin|Different date from later 67 kt reports
Typical injection range|1–3|tCO2/hour|5|Figure 2 caption|Observed operating range||Do not assume 8760 full-load hours
Nominal plant injection capacity|3250|kgCO2/hour|3|Injection operation|Design rating||
Monthly injection range|700–2340|tCO2/month|3|Injection operation|Observed operating range||
Primary CO2 purity|greater than 99.9|%|1|Abstract|Reported specification|Food-grade CO2|
Oxyfuel CO2 purity|greater than 99.7|%|1|Abstract|Reported specification|Schwarze Pumpe supply|
Oxyfuel CO2 injected|1515|tCO2|1|Abstract|Reported field quantity|May–June 2011|
Initial reservoir BHP|approximately 62|bara|4|Pressure development|Reported observation|630 m reference|
BHP after five days|approximately 73|bara|4|Pressure development|Reported observation||
Established BHP range|73–79|bara|4|Pressure development|Observed range||
Pressure increase due to injection|11–17|bar difference|4|Pressure development|Observed range||Not absolute-pressure value
Mean monthly injection before March 2010|1690|tCO2/month|9|Discussion|Observed average||
Associated quasi-steady BHP|77–78|bara|9|Discussion|Observed range|Before March 2010|
Mean monthly injection March 2010–May 2012|1124|tCO2/month|9|Discussion|Observed average||
Associated quasi-steady BHP|73–74|bara|9|Discussion|Observed range|March 2010–May 2012|
Isochronal-test permeability|29.6|mD|6|Pressure-response test|Calibrated parameter||Not identical support to core-test permeability
Flow-meter accuracy|±0.35|% of measured value|3|Monitoring instruments|Instrument specification||Separate from operational flow uncertainty
Injection BHP sensor error|less than ±1|bar|3|Monitoring instruments|Instrument specification||
Isochronal step rates|900 / 1600 / 2400 / 3200|kgCO2/hour|6|Pressure-response test|Test operating conditions||
''')
block(18,'''
Approximate initial injection rate|1000|metric tonnes/day|1|Introduction|Reported operation|IBDP|Not a fossil-origin source
Verification-well separation|305|m|2|Configuration|Field setup||
Pressure sensor practical resolution|approximately 1000|Pa|2|Configuration|Instrument specification||
Model temperature|49|degrees C|5|Section 3.3|Model input||Isothermal assumption
Model vertical thickness|554|m|5|Section 3.3|Model input||
Log vertical alignment shift|13.1|m downward|5|Section 3.3|Calibration setup||Not a measured subsidence
Actual formation TDS|more than 200000|ppm|5|Section 3.3|Reported site context||Salinity neglected explicitly then permeability scaled
Pore compressibility|1e-10|1/Pa|5|Section 3.3|Calibrated parameter||
Relative-permeability residual liquid saturation|0.65|fraction|5|Section 3.3|Calibrated parameter||Not retention
Relative-permeability residual gas saturation|0|fraction|5|Section 3.3|Model input||Not zero site retention
Average injection-zone permeability|approximately 150|mD|8|Section 4.3|Calibrated parameter||Non-unique pressure history match
Injection-zone thickness|23–24|m|8|Section 4.3|Model description||
History-match duration|40|days|8|Section 4.3|Calibration setup||
Prediction comparison period|2|years|8|Section 4.3|Validation comparison||Increasing mismatch needs investigation
''')
block(19,'''
Individual tank volume|5000|m3|3|Table 2 and Section 3.1|Model input||Not total vessel volume
Number of cargo tanks|10|tanks|3|Section 3.1|Model input||
Total ship cargo tank volume|50000|m3|3|Section 3.1|Model input||Volume not mass
Laden tank filling|98|volume %|3|Table 2|Model input||
Ballast tank filling|5|volume %|3|Table 2|Model input||Heel not fleet utilisation
Boil-off generation|0.1|mass %/day|3|Table 2|Model input||BOG can be reliquefied; not automatically atmospheric loss
Liquid N2 impurity range|0.05 / 0.10 / 0.15|mol%|3|Table 2; Figure 2|Model input||Different from BOG nitrogen fraction
Low storage pressure|6.5|bar as printed|3|Table 2|Model input|Case 1|Absolute/gauge convention not explicitly tagged in table
Higher storage pressure|15|bar as printed|3|Table 2|Model input|Case 2|
BOG inlet temperature|-40|degrees C|3|Table 2|Model input|Case 1|
BOG inlet temperature|-20|degrees C|3|Table 2|Model input|Case 2|
Laden operating time|4000|h/year|4|Section 3.4|Model input||Not a measured Japan–Malaysia schedule
Ballast operating time|4000|h/year|4|Section 3.4|Model input||
Annual voyages|6|voyages/year|6|Cost method|Model input||Reconcile with 8000 operating hours when transferring
Generator specific fuel consumption|197.5|g fuel/kWh|4|Equations 5–6 discussion|Model input from literature|MGO|Direct generator fuel demand
Direct fuel CO2 factor|3.206|tCO2/t fuel|4|Equations 5–6 discussion|Model input from IMO|MGO|Excludes upstream fuel GHG and non-CO2 gases
MGO fuel price|825|USD/t fuel|4|Cost method|Model input||Source-specific cost assumption
Carbon-tax assumption|150|USD/tCO2|6|Equation 11 discussion|Model input||Economic, not a GHG emission factor
Equipment economic life|20|years|4|Cost method|Model input||Not retention horizon
Interest rate|10|%|4|Cost method|Model input||
CAPEX base year|2022|year|6|Table 5|Cost basis||Do not treat as universal price year for every cost assumption
Compressor adiabatic efficiency|75|%|6|Table 3|Model input||
Compressor maximum pressure ratio|3|dimensionless|6|Tables 3–4|Model input||
Cooling-water temperature|30|degrees C|6|Table 3|Model input||
Cooler minimum approach|5|degrees C|6|Table 3|Model input||
Heat-exchanger minimum approach|3|degrees C|6|Table 3|Model input||
Minimum CO2 process temperature|-55|degrees C|6|Table 4|Model constraint||Dry-ice avoidance in model
''')
add(19,'Derived direct auxiliary electricity CO2 factor',0.633185,'kgCO2/kWh',4,'SFOC and Cf following Eqs 5–6','Derived factor','MGO auxiliary generator','No upstream/non-CO2 coverage',0.633185,'kgCO2/kWh','197.5 / 1000 * 3.206')
block(20,'''
Nominal cargo tanks|3|tanks|1|Abstract|Model input||
Nominal volume per cargo tank|7300|m3|3|Table 1|Model input||Total nominal 21900 m3
Sensitivity volume per tank|5840 / 7300 / 8760|m3|3|Table 1|Model input||Do not interpret per-tank as whole-ship volume
LP ship pressure cases|7 / 8.5 / 10|bara|3|Table 1|Model input||Explicit absolute pressure
MP terminal pressure cases|12 / 16 / 20|bara|3|Table 1|Model input||
LP cargo liquid temperatures|-49 / -44 / -40|degrees C|3|Table 1|Model input|7 / 8.5 / 10 bara|
LP cargo liquid densities|1146 / 1123 / 1101|kg/m3|3|Table 1|Property input|7 / 8.5 / 10 bara|State-specific
MP liquid temperatures|-35 / -27 / -20|degrees C|3|Table 1|Model input|12 / 16 / 20 bara|
MP liquid densities|1079 / 1035 / 989|kg/m3|3|Table 1|Property input|12 / 16 / 20 bara|
Terminal tank volume|30000|m3|3|Table 1|Model input||
Transfer duration|12|hours|3|Table 1; defined as discharging duration|Model input||HOLD for loading conversion: 12-h loading basis is inferred from table arithmetic, not separately labelled
Filled volume fraction|96|%|3|Table 1 and operations|Model input||
Minimum retained heel|4|volume %|3|Operations description|Model input||Do not call this a CO2 loss
Loading rate at MP16/LP7|1724|m3/hour|3|Table 1|Model input|Three nominal 7300 m3 tanks|
Discharging rate at MP16/LP7|1679|m3/hour|3|Table 1|Model input||
Pump nominal efficiency|75|%|6|Simulation assumptions|Model input||
VR compressor isentropic efficiency|80|%|6|Simulation assumptions|Model input||
VR compressor electrical efficiency|96|%|6|Simulation assumptions|Model input||
Refrigeration COP|2.4|dimensionless|11|Loading energy calculation|Model input from literature||Not universal for every terminal cooling state
Electrical network losses|4|%|11|Loading energy calculation|Model input||Avoid applying twice
Electricity price|0.11|EUR/kWh|10|Discharge OPEX assessment|Model input|Greece example|Not a Japan/Malaysia/Australia emission or price factor
Cargo-pump power range per tank|100–750|kW|6|Table 2|Design range||
Cargo-pump capacity per tank|up to 600|m3/hour|6|Table 2|Design range||
Discharge cost|0.03–0.05|EUR/t discharged|14|Results and conclusions|Simulated cost range||Not full transport cost
Loading cost without subcooling including VR reliquefaction|0.07–0.76|EUR/t loaded|14|Results and conclusions; Table 6|Simulated cost range||Case-specific process boundary
Loading cost with subcooling|0.11–0.75|EUR/t loaded|14|Results and conclusions; Table 7|Simulated cost range||Not universally higher/lower across pressure pairs
''')

# Preserve all six process cases x three impurities from Table 6 and Appendix A.6.
bog=[]
cases=['1-1','1-2','1-3','2-1','2-2','2-3'];imp=[0.05,0.10,0.15]
annual=[[2412.4,4510.2,6755.5],[1068.9,1545.7,2005.3],[941.0,1418.6,1918.4],[479.2,675.2,818.7],[435.0,566.2,683.5],[377.0,455.1,527.0]]
laden=[[2385.1,4477.5,6717.7],[1042.6,1516.3,1973.6],[916.2,1392.8,1891.1],[467.2,662.3,804.9],[423.1,553.6,669.8],[365.5,442.7,513.3]]
ballast=[[27.3,32.7,37.8],[26.3,29.4,31.7],[24.8,25.8,27.3],[12.0,12.9,13.8],[11.9,12.6,13.7],[11.5,12.4,13.7]]
transport=[[320.4,319.2,317.9],[321.9,322.4,322.9],[321.9,322.4,322.9],[297.4,297.7,298.0],[297.4,297.7,298.1],[297.4,297.8,298.2]]
cpt=[[9.57,10.45,11.46],[9.25,9.40,9.56],[8.90,9.10,9.29],[11.63,11.77,11.91],[11.53,11.73,11.87],[11.31,11.38,11.45]]
tac=[[2.70,2.66,2.63],[2.82,2.80,2.79],[2.72,2.72,2.71],[3.39,3.40,3.43],[3.36,3.41,3.44],[3.31,3.32,3.34]]
for i,case in enumerate(cases):
 for j,n2 in enumerate(imp):
  sc=f'Case {case}; liquid N2 {n2:g} mol%';pressure=6.5 if i<3 else 15
  # A derived narrow-boundary intensity is useful, but is not whole-chain avoidance.
  intensity=annual[i][j]/transport[i][j]
  bog.append([case,pressure,n2,laden[i][j],ballast[i][j],annual[i][j],transport[i][j]*1000,cpt[i][j],tac[i][j],intensity,'pp7/13; Table 6 / A.6','Annual purge + auxiliary-generator CO2; excludes propulsion and rest of chain'])
  for par,v,u,p,loc in [('Laden-state annual CO2',laden[i][j],'tCO2/year',7,'Table 6'),('Ballast-state annual CO2',ballast[i][j],'tCO2/year',7,'Table 6'),('Total annual process CO2',annual[i][j],'tCO2/year',7,'Table 6'),('Annual transported CO2',transport[i][j],'10^3 tonnes/year',13,'Table A.6'),('Process cost per transported CO2',cpt[i][j],'USD/t transported',13,'Table A.6'),('Total annualised process cost excluding carbon tax',tac[i][j],'million USD/year',13,'Table A.6')]:add(19,par,v,u,p,loc,'Simulated process result',sc,'Includes reliquefaction/tank boundary, not full-chain transport')
  add(19,'Derived process CO2 intensity',round(intensity,6),'kgCO2/t transported',13,'Table 6 / Table A.6','Derived intensity',sc,'Purge plus auxiliary power; not a lifecycle marine propulsion factor',round(intensity,6),'kgCO2/t',f'{annual[i][j]} tCO2/y * 1000 / ({transport[i][j]} * 1000 t/y)')

# Nine pressure pairs; exact rows retained, including inconsistent specific-demand labels.
lp=[7]*3+[8.5]*3+[10]*3;mp=[12,16,20]*3
interface_specs={
'No subcooling; VR excess reliquefied':{
'vapor':[4051,6741,9303,2784,5317,7732,1732,4137,6427],
'mass':[26563,26077,28746,25584,26087,27364,24917,25059,26199],
'power':[5096,13603,16507,2956,7659,12381,1411,5052,8983],
'specific':[2.3,6.3,6.9,1.4,3.5,5.4,0.7,2.4,4.1],
'cost':[0.25,0.69,0.76,0.15,0.39,0.60,0.07,0.27,0.45],
'page':13,'loc':'Table 6'},
'With subcooling':{
'vapor':[203,271,360,190,259,346,190,260,343],
'mass':[24190,24919,25860,24425,23396,23620,23910,23057,23304],
'power':[6015,10495,14693,4031,7653,10790,2001,5557,8795],
'specific':[3.0,5.1,6.8,2.0,3.9,5.5,1.0,2.9,4.5],
'cost':[0.33,0.56,0.75,0.22,0.43,0.60,0.11,0.32,0.50],
'page':14,'loc':'Table 7'}}
interface=[]
for mode,d in interface_specs.items():
 for j in range(9):
  sc=f'LP {lp[j]} bara; MP {mp[j]} bara; {mode}';specific=d['power'][j]*12/d['mass'][j]
  interface.append([lp[j],mp[j],mode,d['vapor'][j],d['mass'][j],d['power'][j],d['specific'][j],d['cost'][j],round(specific,6),'kWh/t if loading lasts 12 h; do not silently relabel source kWel/ton',d['page'],d['loc']])
  for par,v,u in [('Vapor mass displaced',d['vapor'][j],'tonnes per loading'),('Liquid mass loaded',d['mass'][j],'tonnes per loading'),('Total power with stated vapor treatment',d['power'][j],'kW'),('Specific electrical demand AS PRINTED',d['specific'][j],'kWel/ton as printed'),('Operational cost per loaded mass',d['cost'][j],'EUR/t loaded')]:
   note='HOLD: source unit label ambiguous; duration basis must be reconciled' if par.startswith('Specific') else 'Simulation result; preserve mass boundary and pressure pair'
   add(20,par,v,u,d['page'],d['loc'],'Simulated process result',sc,note)
  add(20,'Conditional derived specific electricity',round(specific,6),'kWh/t loaded if 12-h loading',d['page'],d['loc'],'Derived conditional conversion',sc,'Not source-reported energy; 12-h loading duration inferred, requires confirmation',round(specific,6),'kWh/t',f'{d["power"][j]} kW * 12 h / {d["mass"][j]} t')

# Explicit conversion examples retained as new derived rows, never replacing originals.
add(6,'Cooling temperature difference',round(78*5/9,3),'degrees C difference',5,'Discussion','Derived conversion','2030','Convert differences without subtracting 32',round(78*5/9,3),'K','78 * 5/9')
add(6,'Cooling temperature difference',round(139*5/9,3),'degrees C difference',5,'Discussion','Derived conversion','2048','Convert differences without subtracting 32',round(139*5/9,3),'K','139 * 5/9')
add(12,'Nominal programme injection total',24,'MtCO2',18,'Rate and duration','Derived nominal total','Conceptual reference','800000 t/y * 30 y; no proof actual programme achieves this',24,'MtCO2','800000 * 30 / 1e6')

issues=[
['Q01','B1-07','pp7/9, Figures 11/17/19','Missing numerical vertical-axis scales','Absolute injection tonnes/pressure cannot be recovered reliably; relative 25–30% uplift remains usable as reported.','Request numerical time series; no fabricated or arbitrary graph scaling.'],
['Q02','B1-05','p3','Sustained injection printed as 1.6 tonnes/year','Apparent scale error in synopsis; original underlying technical paper not supplied.','HOLD quantitative rate; verify primary paper and dated project reports.'],
['Q03','B1-05','p3','150 kg/s described as equivalent to 4 Mt/year','Continuous annualisation is 4.7304 Mt for a 365-day year; an operating factor could reconcile.','Keep both source statements; do not infer measured utilisation.'],
['Q04','B1-10','pp7/10/12','Modified inputs; full MILP not reported; BHP can exceed fracture limit','Abstract and implementation scope differ; model does not establish wellbore-safe operation.','Use as screening prior art, not verified Malaysian sink data or adopted feasibility envelope.'],
['Q05','B1-11','pp5–6, Tables 2/3','Mixed pressure header conventions','Maximum injection column is psi; current reservoir pressure column is psia. Text extraction shifts labels.','Visual check performed; preserve originals and clarify pressure datums before arithmetic.'],
['Q06','B1-12','p18','SH/Sh ratio and stress-gradient units','37/32 = 1.15625, whereas printed ratio is 1.125; gradient printed 0.18 MPa lacks length basis.','HOLD ratio/gradient as calibrated inputs; request clarification.'],
['Q07','B1-12','p14, Figure 10 caption','Pore-pressure ranges at 2020/2050','Caption reports up to 500/5000 psi; datum or plotted quantity not reconciled.','Do not use as initial absolute site-pressure profile.'],
['Q08','B1-13','pp8/12/13','Volumetric gas units and unfavorable project conclusion','Bscf/MMscf need standard-state density; source does not recommend field progression.','No unqualified Bscf-to-Mt conversion; do not label Z field an available sink.'],
['Q09','B1-15','p4, Table 1','Printed pressure gradient 1.14 Pa/m','Visually checked; implausible hydrostatic magnitude.','HOLD; no guessed exponent or silent correction.'],
['Q10','B1-16','p3 versus other monitoring evidence','Zone 4 depth reported as 2128 m in one sentence','Other text places lower-permeability boundary around 2092–2094 m; exact port depth needs reconciliation.','Use original port table/monitoring dataset, not ambiguous prose.'],
['Q11','B1-17 / B1-15 / B1-14','Reported dates','Ketzin totals differ by reporting date','61396 t by September 2012 and approximately 67000 t by end-2013 are different time windows.','Do not treat as conflicting independent replications or sum totals.'],
['Q12','B1-19','p8','Power-emission reduction percentages versus stated kW','Constant SFOC*Cf makes emissions proportional to power at fixed hours; printed very large reductions do not match stated 177.7–187.5 versus 210.0–236.7 kW.','Use compatible primary case tables or recompute with declared power/hours; HOLD headline percentages.'],
['Q13','B1-19','pp4/6','4000 h laden + 4000 h ballast and 6 voyages/year','Generic annual assumptions may not match any Japanese export route.','Recalculate route calendar, port time, actual hours and delivered mass together.'],
['Q14','B1-20','pp6/13/14, Tables 6/7','Specific-demand units kWel/ton versus kWh/ton intent','Many values approximately equal total kW*12 h/loaded mass; duration must be explicit.','Original unit retained; conditional derived conversion kept separately.'],
['Q15','B1-20','p14 versus Tables 6/7','Subcooling cost advantage is not universal','E.g. LP7/MP12 cost rises 0.25 to 0.33 EUR/t; LP7/MP16 falls 0.69 to 0.56 EUR/t.','Compare full pressure-pair cases with mass/utility boundaries, not one blanket statement.'],
['Q16','B1-03','pp1/7/9/10','Efficiency summary and capture-case inconsistencies','Abstract >50% both; NG detailed max about49%. Body labels 3.6/8.43 Mt/y at90%; conclusion says95%. Energy metric MJ/MWnet needs explicit time basis.','Keep source values and context; do not use unresolved headline figures as harmonised GHG inputs.'],
['Q17','B1-18','pp5/8/10','Simplified salinity and non-unique history match','Calibrated parameters are model-dependent; long-term mismatch expressly unresolved.','Benchmark pressure behavior conditionally; do not call the two-year forecast fully validated.'],
['Q18','All site papers','Across batch','Capacity, injection, retention and commercial access differ','Named or simulated sink does not establish permission, contracted capacity, commissioning or imported-source access.','Keep site feasibility and actual storage service as separate database fields.']]

wb=load_workbook(B/'Paper_1_evidence_workbook.xlsx')
def sheet(name,head,rows):
 ws=wb.create_sheet(name);ws.append(head)
 for r in rows:ws.append(r)
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D')
 for col in ws.columns:
  ws.column_dimensions[col[0].column_letter].width=min(65,max(16,max(len(str(c.value or '')) for c in col[:25])+2))
 for row in ws.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(wrap_text=True,vertical='top')
  ws.row_dimensions[row[0].row].height=70
 return ws
heads=['Record ID','Study ID','Parameter / result','Reported value / range','Original unit','PDF page (1-based)','Table / figure / section','Evidence type','Scenario / conditions','Extraction status','Use restriction / issue','Derived / normalised value','Derived unit','Equation / conversion']
sheet('Batch1 studies',['Study ID','PDF title','Authors','Year','DOI / report ID','Publication / method','Paper 1 role','PDF pages','Review coverage','Digest','Use for Paper 1','Limitations / caution','Source local path','SHA256'],studies)
sheet('Batch1 values',heads,R)
sheet('BOG scenarios',['Case','Pressure (bar as printed)','Liquid N2 (mol%)','Laden annual CO2 (t/y)','Ballast annual CO2 (t/y)','Total annual CO2 (t/y)','Transported CO2 (t/y)','CPT (USD/t)','TAC ex carbon tax (million USD/y)','Derived process kgCO2/t transported','Source locator','Boundary'],bog)
sheet('Interface scenarios',['LP bara','MP bara','Loading treatment','Vapor displaced (t)','Liquid loaded (t)','Total electrical power (kW)','Specific demand as printed (kWel/ton)','Cost (EUR/t)','Conditional derived kWh/t','Conversion caveat','PDF page','Table'],interface)
sheet('Evidence issues',['Issue ID','Study ID','Source locator','Issue','Evidence / implication','Required handling'],issues)
read=wb['Read me'];read['B2']='Updated with 20 uploaded PDFs. Initial proposal-only sheets preserved; Batch1 sheets hold primary-PDF extractions, not independently validated field truth.'
read['B3']='Drive folder remains inaccessible. The 20 individually uploaded PDFs were downloaded and reviewed; this is not a complete Drive-folder inventory.'
read['B4']='14 original proposal references remain unverified. 20 additional supplied PDFs are registered in Batch1 studies; do not merge evidence statuses.'
read['B5']=f'{len(R)} batch-1 value records, including derived arithmetic and scenario-expanded table values; original 20 proposal claims remain separate.'
read['B6']='Pnnn remains a proposal paragraph locator. Batch1 values use physical PDF page numbers starting at 1; printed journal page numbers may differ.'
read['B7']='Primary extracted means located in the supplied paper, not that a simulated scenario or secondary input is empirical truth. Original units preserved; derivations separate.'
read['B8']='Named sink candidates now have literature support, but commercial access, verified annual series and source/route lifecycle data remain missing. See Evidence issues.'
read['B9']='Next: resolve flagged units/pressure datums; obtain Japanese absolute injection series and named source/route evidence; supply remaining transport/LCA benchmark papers.'
read['B10']='Source-PDF extracted / simulated / calibrated / observed / secondary / derived / HOLD are separate evidence categories. No model outcomes or net-benefit claims generated.'
wb.save(O/'Paper_1_evidence_workbook_batch1.xlsx')
for name,head,rows in [('batch1_values.csv',heads,R),('batch1_studies.csv',[c.value for c in wb['Batch1 studies'][1]],studies),('bog_scenarios.csv',[c.value for c in wb['BOG scenarios'][1]],bog),('interface_scenarios.csv',[c.value for c in wb['Interface scenarios'][1]],interface),('evidence_issues.csv',[c.value for c in wb['Evidence issues'][1]],issues)]:
 with (O/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.writer(f);w.writerow(head);w.writerows(rows)

# Numbered searchable page text retained as provenance, excluding watermarks/contact blocks.
T=O/'source_page_text';T.mkdir(exist_ok=True)
for m in manifest:
 text='\n\n'.join(f'===== {m["batch_id"]} | PHYSICAL PDF PAGE {i} =====\n{p}' for i,p in enumerate(pages[m['batch_id']],1))
 (T/f'{m["batch_id"]}.txt').write_text(text,encoding='utf-8')
(O/'source_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

total_pages=sum(x['pages'] for x in manifest)
brief=f'''# Paper 1 — literature batch 1 digest and preparation

## Coverage and evidence status
The 20 individually uploaded PDFs were downloaded, text-extracted ({total_pages} physical PDF pages), and reviewed for methods, relevant numerical inventories, results, and limitations. Selected graphics and tables were visually checked where text extraction omitted scales or shifted headers. This pack includes {len(R)} value records, 18 BOG process/impurity combinations, 18 ship–terminal interface combinations, 20 study digests and {len(issues)} evidence-quality issues. A record may hold a published range or grouped operating cases; this count is not a count of independent measurements. Derived arithmetic and reported model inputs/results are explicitly distinguished from observations.

This is a substantive first-batch review, not a claim that every plotted point or every secondary citation has been independently verified. Relevant curve-only quantities without readable scales are marked unresolved. Full numerical extraction of absolute Japanese injection profiles remains blocked by the supplied source's missing axis scales. Some image-only supplementary rock-property correlations are methodological context rather than inputs to the proposed screening model and were not exhaustively transcribed. The inaccessible Drive folder and oversized planetary-limit ZIP remain unread. The 14 references in the original proposal are still proposal-only evidence, preserved in separate workbook sheets. No net-mitigation simulation or numerical pathway recommendation has been produced.

## What the batch adds to Paper 1
The clearest contribution is evidence that usable injection service depends on pressure management and operating conditions, not resource size alone. Higashi-Niigata is a named Japanese candidate with history-matched forecasts and a reported 25–30% injection-volume increase with relief wells (B1-07, p8). The Malaysian Z-field study contrasts about 3%, 51% and 61% utilisation of theoretical volume across pressure-management cases (B1-13, pp8–13), but explicitly advises against further injection planning for that field. These studies support scenario structures; neither supplies contracted service for the proposed cross-border source.

Thermal effects also connect deliverability and energy. In a Malaysian caprock screen, estimated 50°C cooling lowers recommended Seal A–D pressure limits from 2153/2731/3264/3701 psi to 1632/2209/2739/3178 psi (B1-11, pp5–6). A separate Sarawak flow-assurance study reports early-life well-rate constraints and compares insulated transport with additional offshore heating (B1-08, pp7–10). These are different sites and studies: do not combine their pressure ceilings, injection fractions and energy increments into one purported Malaysian base case.

The supplied Australian South-West Hub study describes a conceptual 0.8 Mt/year, 30-year, nine-well reference configuration with a 360-bar BHP limit at 2948 m (B1-12, p18). Its no-fault-failure result applies to an isothermal model; it excludes near-well cooling stresses. The Gorgon synopsis illustrates auxiliary brine handling limiting realised CO2 delivery, but its apparent unit error prevents using the printed sustained rate as a numerical benchmark without checking the underlying study (B1-05, pp3–4).

At the transport end, the BOG study quantifies the trade-off between auxiliary electricity and CO2 purge for six process cases and three nitrogen levels (B1-19, pp3–7/13). The LP/MP interface study shows that terminal pressure mismatches add case-specific vapor handling and electricity demands (B1-20, pp3/13–14). These help replace an undifferentiated transport factor with explicit conditioning and handling, but neither supplies route-calibrated laden/return propulsion fuel use for Japan–Malaysia–Australia.

## Numerical comparisons that can be used now
1. Higashi-Niigata: three injectors with or without three pressure-relief wells; nominal injection period 2029-01-01 to 2050-01-01; pressure-limited decline around 2040; 25–30% volume gain with relief wells. Use the relative result and study design. Absolute annual mass series must be obtained, not invented from unscaled curves.
2. Malaysian pressure-managed aquifer: 4.9 / 80.13 / 95.44 Bscf across zero/one-producer cases and added injection well; BHP ceiling 5000 psi, nominal rate limit 60 MMscf/day and water limit 30000 bbl/day. Preserve gas-volume units until the standard state and density are known.
3. Malaysian thermal pressure limits: paired pressure reductions are 521 / 522 / 525 / 523 psi for Seals A–D, calculated from Tables 2–3. These are site-specific pressure differences, not directly annual injection-rate losses.
4. BOG reference: at liquid N2 = 0.10 mol%, annual process CO2 is 4510.2 t for conventional 6.5-bar case 1-1, 1418.6 t for mixed-refrigerant 6.5-bar case 1-3, and 455.1 t for mixed-refrigerant 15-bar case 2-3 (Table 6). Corresponding transported masses and costs remain paired in the workbook. Costs and emissions do not select the same pressure automatically.
5. Interface example: at LP7/MP16 bara, Table 6 reports 13603 kW total power including excess vapor reliquefaction with 26077 t liquid loaded; Table 7 reports 10495 kW with 24919 t loaded for subcooling. At an assumed 12-hour loading duration these imply approximately 6.26 and 5.05 kWh/t, respectively. This is a conditional arithmetic check, not a silently corrected source metric; loading duration and mass boundary must be confirmed.
6. Ketzin and Decatur provide observed pressure/rate histories and model-calibration examples. Use them for component checks at their own scale, with source-origin and reporting dates preserved. Do not treat several publications from the same project as independent sites.

## Changes recommended to the Paper 1 method
Preserve the matched industrial output, common no-CCS baseline, retained-mass accounting and B0–B3 comparison. Add a structured deliverability envelope that can depend on reservoir pressure, thermal constraints, available wells, water-handling capacity and interruption state. A first screening implementation can use externally specified annual profiles; pressure-resolved physics should only be claimed when supported by actual input data and calibration.

Add a pressure-management sensitivity alongside sink delay/ramp/decline: relief wells or brine production can raise cumulative injected mass but also require water treatment, disposal, pumping, wells and monitoring. Count these GHG burdens rather than crediting the extra tonnes without their enabling infrastructure. CO2 produced back through relief wells must have an explicit fate. Never apply a pressure limit from one formation to a different site.

Distinguish laden/ballast tank filling, cargo heel, voyage load fraction and annual fleet utilisation. Add BOG generation, reliquefaction, purge and auxiliary-generator emissions as separate material/energy terms. Recondensed CO2 remains cargo; retained heel is inventory, not atmospheric loss. Avoid double-counting auxiliary energy when a source process inventory already includes it.

Represent LP/MP loading and unloading conditioning at both terminals with explicit ship and terminal pressures, temperatures, liquid density, vapor return, cooling/reliquefaction and transfer time. Separate electrical power (kW), per-transfer energy (kWh), and per-tonne energy (kWh/t). Use location/year-specific grid factors on shore and a marine auxiliary generation factor onboard. The direct MGO generator factor derived from B1-19 is 0.633185 kgCO2/kWh and excludes upstream/non-CO2 effects.

For every B0–B3 comparison, retain the same source, baseline, end-inventory treatment, capture operating policy and physically feasible route. Define the static injection proxy and fixed transport factor before inspecting the comparison results. Report full contrast D3-D0 and interaction D3-D2-D1+D0 separately. These PDFs support the component mechanisms; they do not yet establish the claimed novelty or the sign of the carbon break-even outcome.

## Source-quality decisions before selecting a regional base case
Higashi-Niigata can remain a candidate Japanese sink, conditional on obtaining absolute injection/pressure series and actual accessible service dates. Do not promote ultra-deepwater sediment concepts, anonymised Malaysian Fields X/Z, or conceptual South-West Hub reference cases into a single validated commercial route. The Z-field paper's negative recommendation must remain visible. Named Malaysian and Australian export-accessible sinks with compatible reservoir and terminal evidence are still required.

Resolve the HOLD records before calibration: Gorgon sustained-rate units, Class et al.'s printed pressure gradient, pressure datums in the caprock tables, SWH stress ratio/gradient, BOG compression-power percentage discrepancies, and ship-interface specific-energy units. Preserve rather than silently repair published errors.

## Remaining evidence needed
- Named Japanese industrial source, source origin (fossil/biogenic), output and annual capture supply; no-CCS baseline and incremental capture utilities.
- Absolute site/year injection service and allocated cumulative capacity, commissioning/access evidence and pressure/thermal envelopes for each candidate sink.
- Actual maritime corridors and ports; laden/return fuel curves, speeds, voyage delays, fleet availability and buffer capacities. No supplied paper closes the route-specific propulsion inventory.
- Location/year electricity and full fuel lifecycle factors; injection/pressure-management energy; construction, wells, monitoring/decommissioning, and retention horizon.
- Original benchmark papers from the proposal, especially Fraga, Bjerketvedt, Budiarto, Becattini and Roussanaly. Their full texts/supplements have not been verified in this batch.

## Per-paper digest
'''
for s in studies:
 brief+=f'\n### {s[0]} — {s[1]}\n\n{s[2]} ({s[3]}). {s[4]}. {s[5]}.\n\n{s[9]}\n\nPaper 1 use: {s[10]}\n\nLimits: {s[11]}\n'
brief+='\n## Files and reproducibility\n\nThe workbook preserves the original proposal-only sheets and adds Batch1 studies, Batch1 values, BOG scenarios, Interface scenarios and Evidence issues. CSVs contain the same batch tables. The source manifest records uploaded filenames, source locations, page counts and SHA256 hashes. Numbered text files permit page-level auditing; original PDFs remain in the uploaded-file directory. build_batch1.py reproduces this pack from those files. No repository source or original proposal was modified.\n'
(O/'Paper_1_batch1_digest.md').write_text(brief,encoding='utf-8')
doc=Document()
for ln in brief.splitlines():
 if ln.startswith('# '):doc.add_heading(ln[2:],0)
 elif ln.startswith('## '):doc.add_heading(ln[3:],1)
 elif ln.startswith('### '):doc.add_heading(ln[4:],2)
 elif ln.startswith('- '):doc.add_paragraph(ln[2:],style='List Bullet')
 elif ln.strip():doc.add_paragraph(ln)
doc.save(O/'Paper_1_batch1_digest.docx')
(O/'README.md').write_text(f'Batch 1: 20 supplied PDFs, {total_pages} pages; {len(R)} located value records. Start with Paper_1_batch1_digest.docx and Paper_1_evidence_workbook_batch1.xlsx. Primary extraction is not independent scientific validation. Read Evidence issues before calibration. Original proposal-only evidence remains separate. PDFs are not duplicated in this lightweight ZIP.\n',encoding='utf-8')

# Integrity and arithmetic checks meaningful for transcribed scenario tables.
assert len(studies)==20 and len(bog)==18 and len(interface)==18
for i in range(6):
 for j in range(3):assert abs(annual[i][j]-laden[i][j]-ballast[i][j])<0.11
assert abs(197.5/1000*3.206-0.633185)<1e-10
assert {r[1] for r in R}==set(pages)
check=load_workbook(O/'Paper_1_evidence_workbook_batch1.xlsx',read_only=True)
assert check['Batch1 values'].max_row==len(R)+1
assert check['Provisional values'].max_row==21
check.close()
assert len(Document(O/'Paper_1_batch1_digest.docx').paragraphs)>100
with zipfile.ZipFile(O/'Paper_1_batch1_pack.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(O.rglob('*')):
  if f.is_file() and f.suffix!='.zip':z.write(f,str(f.relative_to(O)))
 z.write(__file__,'build_batch1.py')
with zipfile.ZipFile(O/'Paper_1_batch1_pack.zip') as z:assert z.testzip() is None
print(json.dumps({'studies':20,'pdf_pages':total_pages,'value_records':len(R),'bog_cases':18,'interface_cases':18,'issues':len(issues),'zip_bytes':(O/'Paper_1_batch1_pack.zip').stat().st_size,'files':[f.name for f in O.iterdir()]},indent=2))
