from pathlib import Path
import json,re,csv,zipfile,collections
from openpyxl import load_workbook
from openpyxl.styles import Font,PatternFill,Alignment
from docx import Document

B=Path(__file__).parent;O=B/'master_outputs';O.mkdir(exist_ok=True)
M=sum([json.loads((B/f'batch{i}_manifest.json').read_text()) for i in (1,2,3)],[])
P={m['batch_id']:json.loads((B/f'batch{int(m["batch_id"][1])}'/m['batch_id']/'pages.json').read_text()) for m in M}
MD={m['batch_id']:m for m in M}
profiles={}
def profile(text):
 for line in text.strip().splitlines():
  sid,role,digest,limit=line.split('|');profiles[sid]=(role,digest,limit)
profile('''
B2-01|Core: distance/injectivity economic control|Two-sink pipeline screening explicitly compares injectivity, distance and cumulative capacity. A more distant, better-injectivity site may reduce cost. Flow supply is static.|Economic prior art, not a matched climate-benefit result; 15–35 Mt/year trunk-line scale is not an individual ship route.
B2-02|Context: prospective TEA/LCA|Distinguishes evolving foreground technologies from changing socioeconomic/energy backgrounds and proposes integration with IAM scenarios.|Review-level recommendations, not an empirical energy coefficient or future grid trajectory for the proposed countries.
B2-03|Context: stochastic phased infrastructure|Multi-period stochastic Illinois Basin CCUS planning uses rolling horizons and period budgets with uncertain geological volumes and recourse pipeline investment.|Cost and EOR revenue objectives; do not import EOR credits or scenario probabilities into permanent-storage comparisons.
B2-04|Core: physical reservoir integration novelty|POD/trajectory-piecewise-linear reduced reservoir dynamics are embedded in a CCS MILP. Pressure prediction is reported within ±5%, with 500–1800-fold speedup versus tested full simulations.|Already integrates dynamic physics and infrastructure; accuracy is case/training-region dependent, not a universal reservoir error bound.
B2-05|Core: deployment-limited multimodality|Swiss pipeline diffusion constraints cause a modelled 9% sequestration deficit; other transport modes close it at a 5% cost increase.|Transport-enabled additional sequestration already established. Scenario results are not Japanese operational evidence.
B2-06|Core context: temporal multimodal planning|Canadian strategic MILP includes ships, trains, trucks, pipelines, buffers, transshipment, fleet sizing and offshore injection, and tests temporal-resolution effects.|Integration of these components alone is not new. Heuristic cost improvements depend on the computational comparison and instance.
B2-07|Context: network review|PRISMA review directly synthesises 17 studies; emphasises auditable feasibility and optimality reporting, utilisation, phased access and governance.|Review summaries are secondary evidence; do not use them to certify a global absence of the proposed method.
B2-08|Core: shipping stochastic benchmark|Brevik–Kollsnes case transports 0.4 Mt/year over 715 km; stochastic sailing, buffers and speed/power responses affect transport completion and cost.|Buffer ratios depend on 99% versus 100% transport case and denominator. Table 2 labels design power W for 1500–2500 values; clarify before using as physical watts.
B2-09|Context: injectivity/capacity risk|Synthetic network compares deterministic, Gamma-robust and CVaR designs; equal nominal derating can cause very different well/pipeline cost increments.|Entire dataset is explicitly synthetic; no country-specific capacities, empirical probabilities or real sink availability.
B2-10|Core: international shipping timing|Fraga GHGT-17 assesses 15 what-if scenarios including six-year source/sink delays and network interconnection over 30 years.|Implemented analysis minimises cost after capture. Model name includes multi-objective but this paper is not a whole-chain baseline climate assessment.
B2-11|Supporting: source capture utilisation|110 Swedish CHP plants yield a modelled potential up to 19.3 Mt/year, with capture plus trucking to nearest harbour costing 45–125 EUR/t.|Boundary excludes onward shipping and final geological storage; biogenic/waste mixture needs a different reference than a fossil-only source.
B2-12|Core: closest cost/GHG network model|Multi-period cost/GHG optimisation incorporates conditioning, ships, pipelines, hubs and injection. Six best-solution cases yield 32.8–142.1 kgCO2e per tonne stored.|Post-capture gate-to-gate boundary; no capture penalty or matched industrial no-CCS service. Maintenance/decommissioning exclusions and location-specific factors matter.
B2-13|Core: transport carbon payback and prospective LCA|European prospective LCA uses transport-only and conditioning-inclusive boundaries, time-varying energy backgrounds and an explicit cumulative carbon-payback equation.|Already models cumulative carbon payback. ISO-container ship concept and regional future inventories cannot be substituted for dedicated Asian CO2-carrier data.
B2-14|Context: geospatial capacity and cost|China 1 km-grid source–sink framework reports theoretical/effective capacity and onshore/offshore cost differences and shared regional corridors.|Theoretical and P50 effective resource totals are not annual injectable commercial service. Full-chain costs differ from storage-only costs.
B2-15|Core: pressure-limited global resource|Global basin pressure model contrasts maximum physical injection patterns with hydrocarbon-exploration and storage-readiness restrictions.|Global scenario stock/rates are upper-bound model results, not a regional contract; deployment and data coverage constrain applicability.
B2-16|Context: global matching|Global clustered source–sink matching selects 3093 clusters and 432 sinks for a 92 Gt mitigation scenario, including saline storage and EOR.|Includes EOR and economic oil-price assumptions; not a uniform permanent-retention or avoided-GHG inventory.
B2-17|Context: source–sink review|Reviews source, sink and matching methods and identifies data-scale mismatches, rigid networks and weak links to physical dynamic evolution.|Same publication uploaded again as B3-46; count once. Review claims do not replace primary benchmark extraction.
B2-18|Context: prudent finite storage resource|Risk-based geospatial screening estimates a central prudent planetary storage limit of 1460 GtCO2 with sensitivity 1290–2710 GtCO2.|This is a precautionary scenario-dependent estimate, not a legal universal quota or site injection rate. Exclusions and conversion assumptions must accompany it.
B3-01|Context: cross-border accounting/permanence|Discusses responsibility for leakage and cross-border CCS under the UNFCCC and historical Kyoto mechanisms.|2006 legal analysis; no claim that its description is the current Japan/Malaysia/Australia legal regime. Liability is not a physical retention factor.
B3-02|Context: liability stewardship|US-focused discussion combines existing tort/environmental liability with bonding, insurance and long-term stewardship funding.|Historical policy proposal, not present applicable law or a quantified leakage probability.
B3-03|Context: port feasibility|Identifies UK port health/safety regulatory gaps for large-scale CO2 handling and recommends guidance and legislative changes.|Jurisdiction- and publication-date-specific; does not establish Asian terminal permission or physical operating limits.
B3-04|Supporting: cluster formation|Croatian assessment identifies three onshore clusters and prioritises eastern/central options while noting storage-characterisation gaps.|Regional early economic screening; large theoretical resource does not prove storage deliverability.
B3-05|Context: cost/emissions cluster optimisation|Kazakhstan Python MILP compares full/partial redirection and clustering radii. Claimed cost and emissions outcomes depend on cluster geometry.|Abstract ambiguously calls a quantity both net abated and emissions; reconcile definitions and units before numerical transfer.
B3-06|Supporting: shared-infrastructure costs|Three Guangdong coal plants are compared as standalone versus a 9 Mt/year cluster, with reported 15.92% unit-cost saving.|Abstract says 300 million tonnes per plant while cluster totals 9 million; apparent scale error needs body/table reconciliation.
B3-07|Core: mode/scale benchmark|At 1 Mt/year, route-specific pipeline/ship costs are about USD33/28 per tonne; at 3 Mt/year they are USD21/23.|Pipeline 530 km and shipping 724 km are unequal routes. Printed 2800 kg/s as 1 Mt/year on p11 is inconsistent; hold injection rate.
B3-08|Core: BOG economics|Optimises reliquefied fraction against energy costs, CO2 sale value and venting penalty; economic optimum reported 95.7–98.2%.|This is a fraction of BOG in the studied process, not voyage load fraction, capture rate or geological retention.
B3-09|Novelty context: P-graph timing|P-graph planning already matches fixed-life source flows to capacity-limited sinks with earliest availability and capture retrofit penalties.|Illustrative cases, not site data or marine operational energy model.
B3-10|Core: conditioning inventory|Pipeline-to-ship liquefaction/purification compares open, closed and hybrid cycles; impurities change recovery and energy.|Reported 21.8–40.9 kWh/t refers to specified pipeline-feed states, not compression from an atmospheric captured stream.
B3-11|Novelty context: temporal pinch|Graphical pinch approach matches source flows against sink availability, injection-rate and cumulative-capacity constraints.|Hypothetical examples show these temporal constraints predate current optimisation models; no shipping/GHG model.
B3-12|Context: early European networks|Source–sink mapping anticipates extensive international transport corridors and timely aquifer characterisation.|Historical projections to 2050 are scenarios, not a report of infrastructure now installed.
B3-13|Context: network rollout|InfraCCS estimates a 2015–2050 least-cost European pipeline network, with clustering and candidate-route preselection.|Historical scenario costs and excluded-sink assumptions cannot be transferred directly to Asia.
B3-14|Core novelty: unified baseline/capture-energy planning|Unified model already includes variable source rates, finite injection/capacity, sink readiness and compensatory power for capture energy losses.|Matched output and capture-energy adjustment are established. Marine operational utilisation and dynamic reservoir profiles still need a distinct test.
B3-15|Context: multiperiod European investment|CCTS-Mod chooses capture, pipeline and storage investments and operating quantities given carbon prices/costs and capacity.|Price thresholds are model outcomes conditional on assumptions, not current universal deployment prices.
B3-16|Supporting: pressure management|Constrained differential evolution selects brine-extraction locations/rates under fault-pressure limits in a hypothetical California reservoir.|Water volume, treatment and disposal burdens must accompany extra storage; no transferable universal improvement ratio.
B3-17|Context: saline trapping mechanisms|Reviews hydrodynamic, residual, solubility and mineral trapping and uncertainty in saline capacity estimates.|Older review; timescales and uncertainty preclude assigning a single permanent-retention fraction.
B3-18|Context: site HSE screening|Spreadsheet framework ranks primary/secondary containment and attenuation using scores and uncertainty.|Expert scores are not calibrated probabilities or numerical retained-mass factors.
B3-19|Supporting: capacity methodology uncertainty|Six estimation methods applied to 13 saline datasets often give statistically indistinguishable prospective estimates relative to geological uncertainty.|Prospective capacity comparison is not annual usable injection or proof methods are interchangeable at detailed site scale.
B3-20|Supporting: enhanced injectivity|Simulations report 13–71% capacity increases from fractures/horizontal configurations relative to an unfractured vertical base case.|Do not confuse earlier-study 10–35% with this study's range; benefits include footprint/permitting risks, not free extra capacity.
B3-21|Context: offshore governance|Compares EU legal and Chinese policy governance pathways and argues for a balanced portfolio of legal/policy tools.|Doctrinal comparison, not proof of route permission or current treaty status in proposed countries.
B3-22|Context: legal scales|Examines four European cross-border scenarios at international, national and local law levels.|Use to structure a route-feasibility register; historical European analysis is not applicable Asian legal advice.
B3-23|Supporting: proxy-based well optimisation|ANN plus genetic algorithm approximates Pohang injection/extraction placement with fewer simulator runs.|Reported computational saving is case-specific, not an injection-rate gain or reservoir model accuracy guarantee.
B3-24|Context: regional versus national storage|Energy-system comparison finds substantial projected use of shared Utsira storage; annual injection constraints may limit those flows.|Regional market and climate-policy assumptions; annual flows and cumulative storage must not be conflated.
B3-25|Context: shared cost allocation|Component-based equal cost-sharing rule addresses heterogeneous users, scaling and coalitional rationality.|Financial cost allocation does not by itself allocate physical flows, embodied GHG or avoided-emission credits.
B3-26|Supporting: reuse and phasing|Scottish Feeder 10 reuse case connects coastal/industrial sources with staged 2–8 Mt/year capture scenarios.|Reuse suitability, available capacity and material compatibility need separate evidence at a new route.
B3-27|Core: LCA boundaries|Systematic review of 33 articles finds low comparability and omissions of transport, storage and monitoring; advocates clearer capture/conditioning inventories.|Review literature values remain secondary until original sources checked. Abstract and body use different electricity-projection prevalence wording; do not infer exact counts.
B3-28|Supporting: marine process review|Synthesises liquefaction, alternative physical states, BOG management and energy integration and identifies demonstration-data gaps.|Do not transfer broad review ranges without feed state, process boundary, operating case and primary reference.
B3-29|Core: dynamic cargo handling/GHG|Coupled tank/CHS model compares venting, continuous and periodic reliquefaction with well-to-wake transport-work intensity; crossover depends on voyage duration and BOR.|Already links dynamic tank operations, losses and GHG. The approximately 13-day result is case-specific, not a generic safe venting rule.
B3-30|Core: baseline/system boundary|LPG-tanker and linked-power-system comparison shows changing system boundaries affects costs, emissions and break-even carbon price.|Carbon-price break-even is economic; distinguish from Paper 1's net-mitigation break-even. LPG co-service requires an explicit counterfactual.
B3-31|Context: shared capture/network optimisation|Louisiana cluster integrates process-based capture costs with pipeline routing and evaluates shared capture versus transport.|Cost savings and capture-stream concentrations do not establish climate benefit or cross-border deliverability.
B3-32|Supporting: real options|Ships/pipelines are compared with abandonment, temporary shutdown and alternate-sink options under uncertainty.|Flexibility changes project value but did not reverse preferred mode in the studied cases; do not assume flexibility always changes decisions.
B3-33|Core context: Nordic injectivity/logistics|Small coastal sources and long routes favour ships; better western injectivity may justify 800–1300 km additional transport economically.|Closely related to Johnsson 2017; not independent proof of longer routes delivering more lifecycle net mitigation.
B3-34|Supporting: early maritime chain|30,000 m3 carrier logistics compare approximately 7/15-bar storage regimes and shore/offshore terminals.|Older conceptual transport-cost thresholds depend on flow, route and assumptions, not universal climate thresholds.
B3-35|Core: energy/exergy inventory|2006 chain concept reports 142 kWh/t energy, 60 kWh/t minimum work and 1.4% direct CO2 burden under its particular electricity assumptions.|142 combines electrical and fuel energy; 1.4% assumes nearly zero-emission liquefaction power. Do not combine with modern grid factors twice.
B3-36|Core: offshore benchmark and avoided cost|Compares offshore pipeline and shipping technically, economically and in climate impact across 200–2000 km and 2–20 Mt/year.|CO2-avoided transport costing already exists; input pressure, geography, electricity and financial bases must match before using outputs.
B3-37|Core: evidence for simpler models|Bunter simulations find large multi-year injection-rate oscillations and ramp direction have little effect on long-horizon reservoir response for tested cases.|Direct counter-evidence to assuming dynamics always matter. Injection sites can represent multiple wells; do not interpret 12 sites as 12 single wells.
B3-38|Core: pressure/ship design inventory|7 versus 15 barg shipping comparison provides compatible density, liquefaction, ship fuel, fleet and port-time data over a range of capacities/distances.|7 barg is not 7 bara. Baseline capacity limits 50/10 kt; larger extrapolated designs are sensitivity assumptions. Boil-off is neglected.
B3-39|Core: injectivity/distance benchmark|Nordic analysis links transport volume/distance and reservoir injectivity; longer shipping to better western reservoirs can be cheaper.|Economic comparison, not a whole-chain climate ranking. Related B3-33 case evidence should not be double-counted.
B3-40|Core context: physical/exclusion-limited resource|US assessment accounts for pressure interference and exclusion buffers around hydrocarbon reservoirs when computing saline injection/storage potential.|Pre-brine-extraction resource scenario, not developed service. Avoid regional capacity figures as project injection constraints.
B3-41|Core: North Sea pressure/resource methods|441 candidate sites are assessed with pressure-limited well models; Table 5 reports about 440 Gt capacity and country-level rates.|Table 5 total rate 22620 Mt/year does not equal country-row sum 14664; scope also includes oil/gas fields. HOLD aggregate annual total pending clarification.
B3-42|Core: closest deployment/counterfactual prior art|Swiss yearly 25-year optimisation models emissions relative to business-as-usual, overseas storage and a delayed hypothetical domestic sink.|Already covers yearly baseline emissions and domestic/foreign rollout. Fixed transport coefficients and simplified storage differ from detailed coupled operational deliverability tests.
B3-43|Context: policy uncertainty|Two-stage stochastic MILP studies carbon-tax uncertainty and financial risk measures with cost/risk trade-offs.|Tax scenarios and financial-risk probabilities are not physical reservoir uncertainty distributions.
B3-44|Novelty context: SimCCS|Integrated source, sink, capacity and pipeline routing minimises annualised capture/transport/storage cost in a California example.|Foundational network planning; not a dynamic shipping LCA or matched-country net-mitigation experiment.
B3-45|Supporting: industrial regional networks|European industrial CCS MILP includes capture, pipe/ship transport and on/offshore storage; national versus common targets affect costs.|Cost per tonne and source selection differ from a fixed common-source climate comparison; geographic restrictions are scenario-specific.
B3-46|Duplicate of B2-17|Same title, authors and DOI as B2-17; files differ in byte hash but represent the same publication.|Register both uploaded files and count one unique study; source version differences not assumed scientifically meaningful.
''')

readpages={'B2-01':[1,3,4,5],'B2-04':[1,4,5,9,10],'B2-08':[1,6,7,8,12],'B2-10':[1,3,4,5,6], 'B2-12':[1,5,7,8,9,10,11,12,13,15,16,18,20,21], 'B2-13':[1,3,4,5,6,8],'B2-15':[1,4,5],'B2-16':[1],'B2-18':[1,2,3,4,5,8,10], 'B3-07':[1,6,10,11,18],'B3-27':[1,8,9,10],'B3-29':[1,4,5,6,7,8,9,10], 'B3-35':[1,7,8,9],'B3-36':[1,3,4,5], 'B3-37':[1,3,4,5,7], 'B3-38':[1,3,4,7,8,9,10], 'B3-39':[1], 'B3-41':[1,9,11,12], 'B3-42':[1,2,3,5,6,7,10,11,15,16,17]}
rows=[];N=[]
def add(s,param,value,unit,p,loc='Abstract / first-page summary',kind='Reported model result',scenario='',note=''):
 assert s in P and 1<=p<=len(P[s]),(s,p)
 status='Located in supplied primary PDF; not independently validated'
 if 'HOLD' in note:status='HOLD — ambiguity or inconsistency'
 N.append([f'N{len(N)+1:04}',s,param,str(value),unit,p,loc,kind,scenario,status,note,'','',''])
def block(s,text):
 for ln in text.strip().splitlines():
  a=ln.split('|');a+=['']*(8-len(a));param,val,u,p,loc,kind,sc,note=a[:8]
  add(s,param,val,u,int(p),loc or 'Abstract / first page',kind or 'Reported model result',sc,note)

block('B2-01','''
Trunk flow range|15–35|MtCO2/year|3|Table 1 / input discussion|Scenario input||Static supply
Per-well injectivity range|0.3–1.5|MtCO2/year/well|4|Storage assumptions|Scenario input||Not assumed available at new site
Operating duration|25|years|3|Input discussion|Scenario input||
Initial/outlet CO2 pressure|8|MPa|4|Pipeline assumptions|Scenario input||
CO2 transport temperature|25|degrees C|4|Pipeline assumptions|Scenario input||
Maximum working pressure|15|MPa|4|Pipeline assumptions|Scenario input||
Real discount rate|7|%|4|Economic assumptions|Scenario input||
Example two-sink distances|300 / 450|km|5|Figure 4 discussion|Scenario input||Different injectivity/distance
''')
block('B2-04','''
Pressure accuracy relative to tested full model|±5|%|1|Abstract|Model validation statistic||Training/domain-dependent
Computational speedup|500–1800|factor|1|Abstract|Computational result||Not a physical capacity increase
Injection-pump electricity|1–1.5|kWh/tCO2|9|Full-chain example|Simulated energy||Limited boundary; not full injection infrastructure
Pump energy increase over studied period|20–40|%|9|Full-chain example|Simulated result||Pressure evolves
Safety pressure constraint|90|% of caprock fracture pressure|10|Figure caption|Model constraint||Site-specific physics
''')
block('B2-05','''
Sequestration shortfall with pipeline diffusion constraints|9|%|1||Scenario result|Swiss case|Relative to climate target
Cost increment to close gap via multimodal transport|5|%|1||Scenario result|Swiss case|Not a climate penalty
''')
block('B2-06','''
Illustrated heuristic cost improvement|approximately 10|%|1||Computational comparison||Instance-specific, not physical savings guarantee
''')
block('B2-07','''
Studies in direct review synthesis|17|studies|1||Review count||Not global complete literature census
''')
block('B2-08','''
Annual available CO2|0.4|MtCO2/year|1||Case input|Brevik–Kollsnes|
Route distance|715|km|1||Case input||
Minimum-unit-cost transport completion|99|% of available CO2|7|Section 5.1.1|Optimised result||Not reservoir retention
Average cost at 99%|33.8|EUR/t transported|7|Section 5.1.1|Optimised result||Full stated transport-chain boundary
Final percentage-point average incremental cost|41.9|EUR/t for last 1%|8|Section 5.1.2|Incremental cost result|100 versus 99%|Average cost of incremental tranche; not marginal derivative or overall average
Weather-neglect expected extra unit cost|1.9|EUR/t transported|8|Section 5.2|Scenario comparison||Body states 5.6%; abstract rounds about5%
Optimal buffer at 99%|5120|tonnes CO2|7|Section 5.1.1|Optimised result||102% of ship; 118% of average-cycle captured CO2
Optimal buffer at 100%|5890|tonnes CO2|8|Section 5.1.2|Optimised result||118% of ship; 136% of average-cycle captured CO2
Deterministic buffer|4330|tonnes CO2|8|Section 5.2|Optimised result||Do not mix with stochastic 99/100% cases
Selected ship capacity|5000|tonnes CO2|7|Section 5.1.1|Optimised result||
Design sailing speed|12|knots|6|Section 4.2.3|Model input||
Port time|12|hours|6|Table 1|Model input||Clarify per-port application in model
Fuel price|325|EUR/t fuel|6|Table 1|Model input||Worldwide2017 basis in appendix
Summer mean sailing duration|34.68|hours|7|Table 3|Weather-simulation statistic||Route-specific
Winter mean sailing duration|37.69|hours|7|Table 3|Weather-simulation statistic||
Summer sailing-time standard deviation|2.61|hours|7|Table 3|Weather-simulation statistic||Not transfer-ready distribution
Winter sailing-time standard deviation|4.63|hours|7|Table 3|Weather-simulation statistic||
Calm-water travel duration|32.5|hours|7|Section 4.2.4|Model result||12-knot route
Additional fuel versus calm water|9.9|%|7|Section 4.2.4|Model result||Specific wave scenarios
Seasonal shift selecting larger vessel|20 and above|%|8|Section 5.3|Scenario result||7500-ton ship preferred
''')
for cap,width,length,fconst,ffast,cost in [(3750,15,90,0.5,0.8,23.0),(5000,16,95,0.6,0.9,23.9),(7500,17,100,0.7,1.1,25.7)]:
 for param,v,u in [('Width',width,'m'),('Length',length,'m'),('Constant-power fuel rate',fconst,'t fuel/hour'),('Full-speed fuel rate',ffast,'t fuel/hour'),('Ship investment',cost,'million EUR')]:
  add('B2-08',param,v,u,6,'Table 2','Design/model input',f'{cap} t ship','Generic candidate ship, not route-validated fuel/load curve')
block('B2-09','''
Pipeline/well capacity derating tested|40|%|1||Synthetic scenario input||Not empirical uncertainty range
Pipeline-only robust cost increase|18|%|1||Synthetic scenario result||
Injectivity-only robust cost increase|52|%|1||Synthetic scenario result||
Joint robust cost increase|72|%|1||Synthetic scenario result||
Discounted tail shortfall comparison|200 to 100|MtCO2|1||Synthetic risk outcome||Not a physical stored amount
Expected cost increase for halved tail shortfall|52|%|1||Synthetic scenario result||
''')
block('B2-10','''
What-if scenario count|15|scenarios|1||Model design||
Planning duration|30|years|3|Model description|Scenario input||Annual temporal resolution
Source/storage delay tested|6|years|4|Table 1|Scenario input||Delay cases distinguished
Interconnection availability|after 10|years|4|Table 1|Scenario input|UK access to NL+SM|
Discount rate for levelised costs|10|%|5|Metric description|Economic assumption||
Aggregate network CO2|333.8|MtCO2|4|Emission-profile description|Scenario input||Not net avoided GHG
''')
block('B2-11','''
Number of CHP plants|110|plants|1||Study sample||
Capture potential|up to 19.3|MtCO2/year|1||Model result|Swedish CHP|Capture potential, not permanent retained tonnes
Capture plus nearest-harbour trucking cost|45–125|EUR/tCO2|1||Model result||Excludes ship and storage
''')
block('B2-12','''
Project horizon|30|years|5|LCI boundary|Model input||Distinct from GWP100
LCI reference flow|1|tonne CO2 transported|5|LCI boundary|Functional reference||Do not substitute stored mass denominator
Pressure configurations|0.7 / 1.5|MPa as printed|7|Tables 2–3|Model input||Datum must be preserved
LNG engine well-to-wake GWP|629|gCO2e/kWh|10|Ship operation LCI|Literature-based model factor||Includes upstream component
LNG engine combustion GWP|488|gCO2e/kWh|10|Ship operation LCI|Literature-based model factor||Do not add to629 again
LNG upstream GWP|141|gCO2e/kWh|10|Ship operation LCI|Literature-based model factor||629=488+141
Loading/unloading energy|0.2|kWh/tCO2 moved|12|Loading LCI|Literature-based model input||Clarify each event boundary before doubling
Norwegian grid factor|0.03|kgCO2e/kWh|12|Loading LCI|Database-based input||Not Japanese/Malaysian grid factor
Site fugitive emissions|0.00286|tCO2e/hour/site|8|Storage-site LCI|Literature-based model input||Captured-stream CO2 versus incremental burden requires reconciliation
Initial cargo filling|98|%|12|Boil-off management|Model input||
Venting onset assumption|longer than 46|days|12|Boil-off management|Model input||Do not transfer to different tank/impurity scenario
Post-onset venting|0.2|cargo volume %/day|12|Boil-off management|Model input||Volume-based, not necessarily mass fraction
GHG impact horizon|100|years|16|GWP description|Impact metric||Not geological retention horizon
Cost reference year|2022|year|16|Cost treatment|Cost basis||
Total combined supplied CO2|296.3|MtCO2|15|Emission profiles|Scenario input||Five periods over30years
Initial aggregate storage capacity|6051|MtCO2|15|Table14 discussion|Scenario input||Not developed storage service
NL lower-pressure best-case intensity|32.8|kgCO2e/tCO2 stored|18|Results|Optimised result|0.7 MPa|Post-capture boundary
NL higher-pressure best-case intensity|46.3|kgCO2e/tCO2 stored|18|Results|Optimised result|1.5 MPa|Post-capture boundary
SM lower-pressure best-case intensity|142.1|kgCO2e/tCO2 stored|20|Results|Optimised result|0.7 MPa|Post-capture boundary
SM higher-pressure best-case intensity|139.0|kgCO2e/tCO2 stored|20|Results|Optimised result|1.5 MPa|Post-capture boundary
Combined lower-pressure best-case intensity|41.5|kgCO2e/tCO2 stored|20|Results|Optimised result|0.7 MPa|Post-capture boundary
Combined higher-pressure best-case intensity|39.2|kgCO2e/tCO2 stored|20|Results|Optimised result|1.5 MPa|Post-capture boundary
''')
for press,factors in [(0.7,[0.9,1.0,4.3,1.8,9.4]),(1.5,[0.7,0.8,3.4,1.4,7.5])]:
 for country,v in zip(['Norway','Sweden','Belgium','France','Ireland'],factors):add('B2-12','Liquefaction GHG',v,'kgCO2e/tCO2 transported',7,'Table 2','LCI model result',f'{press} MPa; {country}','Regional background inventory; not energy input kWh/t')
block('B2-13','''
Prospective horizon endpoint|2100|year|1||Scenario horizon||
Environmental impact categories|16|categories|1||Study design||
Dense-pipeline baseline transport impact|approximately 4|gCO2e/t-km|5|Section3.1|LCA result|2020; transport-only|Excludes conditioning; capacity and scenario dependent
Pipeline lengths modelled|200|km|4|Foreground pipeline model|Model input||
Pipeline throughput cases|0.3 / 10|MtCO2/year|4|Foreground pipeline model|Model input||
ISO tank tare mass|9.2|tonnes|3|Tank model|Model input||
ISO tank liquid cargo mass|20.7|tonnes CO2|3|Tank model|Model input|16bar|Not ship capacity
Return-trip retained CO2|4|%|3|Tank model|Model input||Inventory heel, not atmospheric emission
Capture-exit feed pressure|1|bar|4|Conditioning boundary|Model input||Pure CO2 assumed
Capture-exit feed temperature|30|degrees C|4|Conditioning boundary|Model input||
Annual illustrative transport work|70|Gt-km/year|5|Planetary-boundary method|Scenario input||0.7Gt/year times100km
Allocated European population share|7.9|%|5|Planetary-boundary method|Allocation assumption||Not universal environmental allowance
Carbon payback for switching to dense pipeline|less than3|years|1||Model result||Transport-infrastructure investment payback, not geological break-even
''')
block('B2-14','''
Spatial grid size|1 x 1|km|1||Model resolution||
Theoretical storage resource|2.5|trillion tons CO2|1||Resource estimate|China|Not annual deliverability
P50 effective storage resource|1.5|trillion tons CO2|1||Resource estimate|China|Model P50, not site measurement
Onshore storage cost|3–10|USD/t|1||Model result||Storage-only cost
Offshore storage cost|10–60|USD/t|1||Model result||Storage-only cost
Coal captured CO2 below USD90/t levelised chain cost|60–75|%|1||Model result||Do not mix cost boundaries
''')
block('B2-15','''
Maximum pressure-limited resource at30years|3640|GtCO2|1||Global scenario result||Not contracted site service
Corresponding stated mid-century rate|121|GtCO2/year|1||Global scenario result||Do not apply as constant site flow
Maximum end-century resource|5630|GtCO2|1||Global scenario result||80year injection case
Corresponding stated end-century rate|70|GtCO2/year|1||Global scenario result||
Top-ten-readiness mid-century resource|780|GtCO2|1||Restricted-deployment result||
Top-ten-readiness mid-century rate|26|GtCO2/year|1||Restricted-deployment result||
Top-ten-readiness end-century resource|1177|GtCO2|1||Restricted-deployment result||
Top-ten-readiness end-century rate|15|GtCO2/year|1||Restricted-deployment result||
Maximum site flow in tested patterns|5|MtCO2/year/site|5|Scenario description|Scenario input||Not field-measured injectivity
Basins with sufficient analysis data|265|basins|5|Scenario description|Dataset count||
''')
block('B2-16','''
Selected source clusters|3093|clusters|1||Model output||
Selected sinks|432|sinks|1||Model output||
Countries/regions|85|regions|1||Model scope||
Mitigation scenario|92|GtCO2 cumulative|1||Model scenario||Includes EOR
Saline storage share|64|%|1||Model result||
EOR share|36|%|1||Model result||Do not equate EOR injection with full net mitigation
Matches within300km|80|%|1||Model result||
''')
block('B2-18','''
Central prudent planetary storage limit|1460|GtCO2|1||Risk-screened estimate||Not a regulatory cap or site injection rate
Prudent storage sensitivity range|1290–2710|GtCO2|1||Scenario sensitivity||Not labelled a statistical confidence interval
Initial physical storage potential|11800|GtCO2|4|Holistic assessment|Resource estimate||Different boundary from prudent estimate
Central onshore/offshore split|70 / 30|%|4|Holistic assessment|Scenario result||Approximate
Reservoir depth window|1–2.5|km|2|Risk exclusions|Screening assumption||Normative cautionary limits; not universal physical feasibility
Maximum offshore water depth central case|300|m|2|Risk exclusions|Screening assumption||Not evidence deeper sites cannot work
Population-area buffer|25|km|2|Risk exclusions|Screening assumption||Central case
Seismic threshold|0.115|g PGA|3|Figure1|Screening assumption||Scenario mask, not site pressure limit
Storage conversion intensity|0.037|GtCO2 per1000km3 sedimentary volume|10|Methods|Screening assumption||Pressure-limited lower-end literature basis
Conversion injection period|50|years|10|Methods|Screening assumption||Do not turn global volume into available annual project service
Max cooling if entire resource used for removals|0.7|degrees C|1||Climate response estimate||Not mitigation achievable by fossil CCS
Cooling sensitivity including climate uncertainty|0.35–1.2|degrees C|1||Scenario/model uncertainty||
''')

block('B3-05','''
Identified storage sites|17|sites|1|Highlights|Model inventory||Not verified contracted service
Identified storage capacity|5784|MtCO2|1|Highlights|Model inventory||
Low-cost clustering radius|100|km|1||Model result||
Full-redirection cost at100km|23.30|billion USD|1||Model result||Project horizon/basis need body extraction
Partial-redirection cost at100km|24.02|billion USD|1||Model result||
Balanced radius range|240–300|km|1||Model result||Case-specific
''')
block('B3-06','''
Total cluster capture capacity|9|million tonnes/year|1||Model input|Three Guangdong plants|
Average standalone unit cost|354.45|CNY/tCO2|1||Model result||
Cluster unit-cost saving|56.43|CNY/tCO2|1||Model result||
Cluster relative unit-cost saving|15.92|%|1||Model result||Not GHG saving
Printed per-plant capacity|300|million tonnes/year as printed|1||Source statement||HOLD: inconsistent scale versus9Mt/year total cluster; inspect source tables
''')
block('B3-07','''
Pipeline route distance|530|km|6|Table2|Case input|Boryeong to Ulleung|Unequal marine route
Ship route distance|724|km|6|Table2|Case input|Boryeong to Ulleung|
Pipeline cost at1Mt/year|33|USD/tCO2|18|Conclusions|Model result||Currency base year needs checking
Ship cost at1Mt/year|28|USD/tCO2|18|Conclusions|Model result||
Pipeline cost at3Mt/year|21|USD/tCO2|18|Conclusions|Model result||
Ship cost at3Mt/year|23|USD/tCO2|18|Conclusions|Model result||
Ship speed|15|knots|10|Ship design|Model input||
Loading/unloading durations|20 each|hours|10|Ship design|Model input||
Entering/leaving port durations|2 each|hours|11|Ship design|Model input||
Direct-injection fleet size|3|ships|11|Ship design|Model input|Scenarios1/2|
Injection rate as printed|approximately2800|kg/s|11|Ship design|Source statement||HOLD: described as1Mt/year; continuous2800kg/s is88.3Mt/year
''')
block('B3-08','''
Economically optimal BOG reliquefaction fraction|95.7–98.2|% of BOG|1||Optimised process result||Not retained fraction or capture rate
''')
block('B3-10','''
Liquefaction specific energy cited comparison|21.8–40.9|kWh/tCO2|1||Process result|Different impurity/feed cases|Pipeline-feed conditioning, not universal from1bar
Reported high CO2 recovery|98.1|%|1||Process result||Case mapping requires original process table
''')
block('B3-13','''
Scenario time window|2015–2050|years|1||Planning scenario||Historical prospective assumption
Network length by2050|11000–17000|km|1||Optimised network result||Onshore aquifer inclusion differs
Required investment|16–36|billion EUR|1||Optimised network result||Cost basis/horizon conditional
''')
block('B3-15','''
Industrial CCTS viability price|above50|EUR/tCO2|1||Model threshold||Conditional on storage capacity and costs
Power-sector CCTS viability price|above75|EUR/tCO2|1||Model threshold||Not carbon break-even GHG condition
''')
block('B3-19','''
Storage-estimation methods compared|6|methods|1||Study scope||
Saline datasets compared|13|datasets|1||Study scope||Prospective geological property uncertainty
''')
block('B3-20','''
Earlier literature capacity improvement|10–35|%|1||Secondary literature range||Different from this study
This-study fracture/horizontal capacity gain|13–71|% versus unfractured vertical well|1||Simulated result||Not universal or risk-free
''')
block('B3-23','''
Full-simulator optimisation runs|622|simulations|1||Computational result||Not injected mass
Proxy-assisted optimisation runs|120|simulations|1||Computational result||
Simulator-run reduction|80.7|%|1||Computational result||Not injectivity improvement
''')
block('B3-24','''
CCS contribution in modelled decarbonisation portfolio|32–40|%|1||Energy-system model result||Regional/national scenarios
Total stated2050 CO2 captured/stored|475–570|MtCO2 as abstract|1||Model result||Annual flow versus cumulative basis requires body reconciliation
Stated2050 Utsira stored portion|110–120|MtCO2 as abstract|1||Model result||Do not mix with cumulative capacity
''')
block('B3-26','''
Large sources within40km ofFeeder10|approximately80|%|1||Regional inventory result||Scotland, not transferable network proximity
Capture rollout range|2–8|MtCO2/year|1||Scenario result||Reuse/expansion assumed
Selected emitters|13|sources|1||Case scope||
''')
block('B3-27','''
Articles reviewed|33|articles|1||Systematic review count||2013–2024publication search
Full-value-chain coverage|less than half|share of33 articles|1||Review result||Exact count not inferred
Electricity-intensity projection coverage|below one quarter|share of33 articles|1||Review result|Abstract|Body uses different wording; no invented exact count
''')
block('B3-29','''
Total ship tank volume|100000|m3|6|Section3.3|Model input||20tanks of5000m3
Initial filling fraction|95|volume%|6|Section3.3|Model input||Different from Jeong2025model
Initial pressure|7.5|bar as printed|6|Table4|Model input||
Initial temperature|-50.9|degrees C|6|Table4|Model input||
Cargo N2 fraction|0.2|mol%|6|Section3.3|Model input||Do not combine with pureCO2property values
Operating pressure range|6.5–8.5|bar as printed|6|Section3.3|Model input||
Baseline BOR specification|0.15|%/day|6|Section3.3|Model input||Generation specification, not fixed vent loss
LNG specific fuel consumption|136|g fuel/kWh|5|Table2|Model input||Not same SFOC as MGO study
LNG upstream GHG factor|18.5|gCO2e/MJ|5|Table2|Database input||WtT factor; no double count withWtW
Reference vessel speed|17.99|knots|5|Table2|Calculated design input||About18knots
Main-engine MCR|21455|kW|5|Table2|Calculated design input||
Voyage comparison|25|days|9|MGIanalysis|Model input||Not a Japan route
Travel distance in25day comparison|10797|nautical miles|9|MGIanalysis|Model input||Check reference-speed/calendar basis before transfer
Venting/reliquefaction crossover|approximately13|days|10|MGIanalysis|Simulated result|BaselineBOR0.15%/day|Not universal threshold
No-CHS maximum pressure reached|3|days|8|Self-pressurisation|Simulated result|Baselinecase|Not safe uncontrolled operation beyond rated pressure
CO2 vented over25days|25642|kgmoleCO2|8|BOGventing|Simulated result||1.03%initialCO2; do not confuse with printedtonne inconsistencies later
Vented initialCO2 fraction|1.03|%|8|BOGventing|Simulated result||
Steady-state reliquefaction optimum power|541.7|kW|8|Table7|Optimised result||Distinguish time-dependent average
Compressor adiabatic efficiency|85|%|7|Table5|Model input||
Minimum stream temperature|-55|degrees C|7|Table5|Model constraint||Dryiceavoidance
''')
block('B3-30','''
Levelised shipping cost|31.65–47.05|USD/t|1||LCA/economic scenario result|ReferenceLPGtanker|Boundary-dependent
Break-even carbon price|22.32–39.37|USD/tCO2|1||Economic threshold||Not a carbon-mitigation break-even mass threshold
''')
block('B3-31','''
CO2 source concentrations modelled|5 /10 /15 /94|mol%|1||Process input||Different capture energy/cost
Cluster facilities|22|facilities|1||Case scope||
Combined source emissions|8.1|million tCO2/year|1||Case inventory||Not captured/retainedmass
Average transport cost reduction withsharing|up to two-thirds|fraction|1||Model result||Not full-chain cost or GHG reduction
''')
block('B3-32','''
Illustrative transport capacity|2.5|MtCO2/year|1||Scenario input||
Pipeline-preferred example distance|250|km|1||Cost/option model result||Not universal threshold
Ship-preferred example distance|500|km|1||Cost/option model result||
Abandonment option value ratio ship/pipeline|2–4|factor|1||Financial option result||
Temporary shutdown option value ratio|5|factor|1||Financial option result||
''')
block('B3-33','''
Typical Nordic source size|0.1–1.0|MtCO2/year|1||Regional inventory context||Not a sourceprofile
Typical minimum storage distance|300 or more|km|1||Regional context||
Extra western route justified economically|800–1300|km|1||Cost comparison||No proof of netGHGbenefit
''')
block('B3-34','''
Carrier capacity|30000|m3|1||Concept input||
Comparedcargo states|7bar/-50C and15bar/-30C|pairedconditions|1||Concept input||Pressure gauge/absolute not tagged in abstract
Designannualquantity|2.5|MtCO2/year|1||Concept input||
Designroute|1000|km|1||Concept input||
Ship autonomy|6|days|1||Concept input||
Transportcostrange|24–32|EUR/tCO2|1||Costresult||Ageandcostbasisneedharmonisation
Offshorepipeline cost-switch example|350|km|1||Economic threshold||Not universalclimatethreshold
Onshorepipeline cost-switch example|1100|km|1||Economic threshold||
''')
block('B3-35','''
Chain specific energy|142|kWh/tCO2 energy equivalent|7|Table2|Modelled inventory||117electricityplus25fuel-energy, not142kWhe
Liquefaction specific energy|110|kWh/tCO2|7|Table2|Modelled inventory|Lowpressurefeed|Boundary/pressuredependent
Loading energy|0.2|kWh/tCO2|7|Table2|Modelled inventory||
Ship energy equivalent|25|kWh fuel-energy/tCO2|7|Table2|Modelled inventory||Not shoreelectricity
Unloading energy|6.5|kWh/tCO2|7|Table2|Modelled inventory||
Minimum exergy/work|60|kWh/tCO2|7|Table2|Thermodynamic estimate||Not achievable operational demand
Chain rational efficiency|42|%|7|Table2|Model result||Exergy efficiency, notCO2retention
TotaldirectCO2burden|1.4|%ofinletCO2|7|Table2|Model result||Near-zero-carbonliquefactionpowerassumption; notmodernfullLCA
ShipdirectCO2burden|0.65|%ofinletCO2|7|Table2|Model result||Specificroute/schedule
Fuel-oilmeanconsumption|0.6|t fuel/hour|7|Energyanalysis|Modelinput||
Fuel lower heating value|41|MJ/kgfuel|7|Energyanalysis|Modelinput||
Annual transport time|7000|hours|7|Energyanalysis|Modelinput||
Transportchain cost|25|2003USD/tCO2|7|Table2|Costresult||Mustretain2003costbasis
CO2liquefaction at1/2/5/20bar inlet|110 /89 /67 /40|kWh/tCO2|7|Energyanalysis|Processsensitivity||Do not mixfeedpressures
Alternativeelectricityemissionsfactor|0.35|kgCO2/kWh|7|CO2emissionsdiscussion|Sensitivityassumption||Adds3.85%for110kWh/t
''')
block('B3-36','''
Distanceassessmentrange|200–2000|km|3|Comparisonmethod|Scenarioinput||
Annualvolumeassessmentrange|2–20|MtCO2/year|3|Comparisonmethod|Scenarioinput||
Pipelineinletpressure|200|bar|4|Pipelineconditioning|Modelinput||
Offshoredeliveryminimumpressure|60|bar|4|Boundary|Modelinput||Notgeologicalfracturelimit
Shippingcargo liquefactionpressure|6.5|bar|4|Shippingconditioning|Modelinput||
Shippingcargo liquefactiontemperature|-50|degreesC|4|Shippingconditioning|Modelinput||
''')
block('B3-37','''
Basefieldtargetinjection|24|MtCO2/year|3|Table2|Scenarioinput||Notactualeveryyearachievedflow
Injectionduration|50|years|3|Table2|Scenarioinput||
Injectionsites|12|sites|3|Simulationparameters|Modelinput||A site mayrepresentmultiplewells
Minimumsitespacing|30|km|3|Simulationparameters|Modelinput||
BHPconstraintfraction|75|%oflithostaticpressure|3|Simulationconstraints|Modelinput||Not75%offracturepressure
Lithostaticgradient|22.5|kPa/m|3|Simulationconstraints|Modelinput||
Rateoscillationamplitude|±80|%ofmean|3|Table2|Scenarioinput||
Fieldhigh/lowrate|43.2 /4.8|MtCO2/year|3|Table2|Scenarioinput||
Oscillationperiodicchangetimes|2.5 /5|years|3|Table2|Scenarioinput||Longtimescale, nothourlyflow
Salinity|130000|ppm|3|Reservoirmodel|Modelinput||
Rockcompressibility|4.5e-10|1/Pa|3|Reservoirmodel|Modelinput||
''')
for site,depth,bhp in [(1,1751,29.54),(2,2007,33.87),(3,1742,29.39),(4,1743,29.42),(5,2564,43.26),(6,2020,34.09),(7,1971,33.26),(8,2311,39.00),(9,1517,25.60),(10,1729,29.18),(11,1738,29.33),(12,1795,30.30)]:
 add('B3-37','Injection site depth',depth,'m',3,'Table1','Reservoirmodelinput',f'Site{site}','Site may comprise multiplewells')
 add('B3-37','SiteBHPceiling',bhp,'MPa',3,'Table1','Modelconstraint',f'Site{site}','Bunter case only')
block('B3-38','''
Shippingpressurescompared|7 /15|barg|1||Modelinput||Gaugepressures, notbara
Volumerange|0.5–20|MtCO2/year|3|Studyscope|Scenarioinput||
Distancerange|50–2000|km|3|Studyscope|Scenarioinput||
Bufferateachharbour|1.2|timesshipcapacity|7|Logisticsassumptions|Modelinput||Simplifiedvalue, notuniversaloptimalratio
Exportportduration|12|hours|7|Logisticsassumptions|Modelinput||Moor/load/departcombined
Receivingharbourduration|12|hours|7|Logisticsassumptions|Modelinput||Moor/unload/departcombined
Offshorefloatingfacilityduration|36|hours|7|Logisticsassumptions|Modelinput||Differentreceivingconfiguration
Meanshipspeed|26|km/hour|7|Logisticsassumptions|Modelinput||Reportedapproximately14knots
Annualoperatingtime|8400|hours|7|Logisticsassumptions|Modelinput||360hmaintenance
Baseline7bargmaximumshipcapacity|50|ktCO2/ship|7|Logisticsassumptions|Modelconstraint||Beyond50ktsensitivityextrapolation
Baseline15bargmaximumshipcapacity|10|ktCO2/ship|7|Logisticsassumptions|Modelconstraint||Beyond10ktsensitivityextrapolation
Reconditionedtemperature|above5|degreesC|8|Receivingfacility|Modelinput||
Onshorereconditionedpressure|200|bara|8|Receivingfacility|Modelinput||
Offshorereconditionedpressure|90|bara|8|Receivingfacility|Modelinput||
Costreferenceyear|2017|year|8|Costmethod|Costbasis|NorthwesternEurope|
Liquefactionelectricityprice|80|EUR/MWh|7|Table3note|Modelinput||NotgridGHGfactor
''')
shiprows=[]
shipdata=[(2.5,16.2,35.4,.81,1.77,7.07),(5,23.5,50,1.18,2.5,6.97),(7.5,29.2,61.2,1.46,3.06,6.87),(10,34.1,70.6,1.71,3.53,6.77),(12.5,38.4,78.9,1.92,3.95,6.67),(15,42.4,86.4,2.12,4.32,6.58),(20,49.4,99.7,2.47,4.99,6.38),(25,55.7,111.5,2.79,5.58,6.18),(30,61.5,122.1,3.08,6.11,5.98),(35,66.8,131.8,3.34,6.59,5.78),(40,71.7,140.9,3.59,7.05,5.59),(45,76.4,149.4,3.82,7.47,5.39),(50,80.9,157.5,4.05,7.88,5.19),(60,89.2,172.4,4.46,8.62,4.79),(70,96.9,186.2,4.85,9.31,4.40),(80,104.1,199,5.21,9.95,4),(90,110.9,211,5.55,10.6,3.61),(100,117.3,222.4,5.87,11.1,3.21)]
for cap,c7,c15,o7,o15,fuel in shipdata:
 caution='15barg above10kt and7barg above50kt are extrapolated sensitivity designs; originalfuel-factor accounting must be checked before adding returntrip factor.'
 shiprows.append([cap,c7,c15,o7,o15,fuel,'2017EUR; B3-38p8Table4',caution])
 for par,v,u in [('7bargshipCAPEX',c7,'millionEUR2017'),('15bargshipCAPEX',c15,'millionEUR2017'),('7bargfixedOPEX',o7,'millionEUR2017/year'),('15bargfixedOPEX',o15,'millionEUR2017/year'),('Specificfuelconsumption',fuel,'g fuel/tCO2/km')]:add('B3-38',par,v,u,8,'Table4','Literature-baseddesigninput',f'{cap}ktship',caution)
liqrows=[]
liqdata=[('Purebase',7,100,100,1150,96.3,14.9),('Purebase',15,100,100,1060,90.4,14),('Inland',7,100,100,1150,17.4,4),('Inland',15,100,100,1060,9,3),('Impurity1',7,99.92,97.9,1189,103.4,16.5),('Impurity1',15,99.85,98.4,1094,94.6,14.9),('Impurity2',7,99.74,96.1,1204,121.8,19.7),('Impurity2',15,99,97.4,1143,112.4,18.3),('Impurity3',7,99.30,97.4,1158,112.6,18.1),('Impurity3',15,99,98,1093,105,17.2),('Purity1',7,99.74,96.1,1204,121.8,19.7),('Purity1',15,99,97.4,1143,112.4,18.3),('Purity2',7,99.93,99.6,1190,103.7,22.8),('Purity2',15,99.91,99.6,1091,93.7,21.4)]
for case,pressure,purity,recovery,density,energy,cost in liqdata:
 liqrows.append([case,pressure,purity,recovery,density,energy,cost,'B3-38p7Table3; 1MtCO2/year','Feedstate/compositiondiffer; see originalTable2'])
 for par,v,u in [('LiquefiedCO2purity',purity,'%'),('CO2recovery',recovery,'%'),('LiquidCO2density',density,'kg/m3'),('Liquefactionspecificelectricity',energy,'kWh/tCO2'),('Liquefactiontotalcost',cost,'EUR2017/tCO2')]:add('B3-38',par,v,u,7,'Table3','Processmodelresult',f'{case};{pressure}barg','1Mt/year basis; do not average over feed/composition cases')
block('B3-39','''
Typicalsourceannualquantity|less than1|MtCO2/year|1||Regionalcontext||
Typicallongdistance|300ormore|km|1||Regionalcontext||
Extraeconomicshippingdistance|800–1300|km|1||Costcomparison||NotnetGHGthreshold
''')
block('B3-40','''
USsalineassessmentunits|192|units|1||Datasetscope||
USonshorebasins|33|basins|1||Datasetscope||Notstorage servicecount
''')
block('B3-41','''
Candidatesitesassessed|441|sites|1||Studyinventory||Includes oil/gas fields despite saline-title framing
Totalestimatedresource|440|GtCO2|11|Table5|Pressure-limitedmodelresult||Notcommercialavailability
Printedtotalannualrate|22620|MtCO2/year|11|Table5|Sourceaggregate||HOLD: countryrows sum14664 not22620; subtotaldoublecounting possible
''')
for country,cap,rate in [('UK',238,7954),('Denmark',3.8,127),('Norway',48,1603),('Netherlands',147,4925),('Germany',1.64,55)]:
 add('B3-41','Countryresource',cap,'GtCO2',11,'Table5','Pressure-limitedmodelresult',country,'Not available injectionservice')
 add('B3-41','Countryannualrate',rate,'MtCO2/year',11,'Table5','Pressure-limitedmodelresult',country,'Do not use printedtotalwithoutreconciliation')
block('B3-42','''
Planninghorizon|25|years|1||Modelinput||Yearlydecisions
SwissWtEplants|30|plants|2|Casescope|Studyinventory||
AnnualBAUemissions|approximately4.5|MtCO2/year|2|Casescope|Sourceinventory||About halfbiogenic; counterfactualmustmatch
Maximumcapturefraction|90|%|15|AppendixB|Modelinput||
Captureelectricaldemand|25|kWh/tCO2|2|Captureassumptions|Modelinput||Heat assumed internally supplied; notfullcaptureenergy
Capturecost|50|EUR/tCO2|2|Captureassumptions|Modelinput||Representativeassumption
Electricityprice|100|EUR/MWh|15|AppendixB|Modelinput||
Swissgridcarbonintensity|104|gCO2/kWh|15|AppendixB|Modelinput||Staticbackgroundnotfuturecountryforecast
Other-nodegridcarbonintensity|414|gCO2/kWh|15|AppendixB|Modelinput||
Domesticstorageavailabilityinscenario|afteryear15|timecondition|7|Rolloutdiscussion|Scenarioinput||Hypotheticalunlimitedcapacity
NominalCO2storedminimumemissionscase|approximately4.0|MtCO2/year|6|Rolloutresults|Optimisedresult||Notnetavoidedemissions
Minimumsystememissions|0.54|MtCO2/year|5|Staticdesignresults|Optimisedresult||AccountsforCCSchain; commonBAUreferencealreadyused
''')
for mode,v in [('Truck',6.83e-5),('TrainCH',6.64e-7),('TrainEU',1.98e-5),('Barge',9.60e-7),('Ship',9.60e-7),('Pipeline',1.55e-6)]:add('B3-42','Directtransportemissionscoefficientgamma1',v,'tCO2/tCO2/km',16,'TableB.3','Modelcoefficient',mode,'Additional constructioncoefficient and electricity/conditioning terms separate; notwholechainfactor')
block('B3-43','''
Suggestedcarbontaxinmodel|atleast50|USD/tCO2|1||Policymodelresult||Notclimatebreak-even
''')
block('B3-44','''
Californiasources|37|sources|1||Casescope||
Californiareservoirs|14|reservoirs|1||Casescope||
''')
block('B3-45','''
Industrialreductiontarget|50|%|1||Scenarioconstraint||Per-country target
Nationaltargetchaincost|60.5|EUR/tCO2|1||Optimisedcost||
Chaincostwithoffshore-onlystorage|81.4|EUR/tCO2|1||Optimisedcost||NotGHGintensity
''')

wb=load_workbook(B/'batch1_outputs/Paper_1_evidence_workbook_batch1.xlsx')
def sheet(name,heads,data):
 ws=wb.create_sheet(name);ws.append(heads)
 for r in data:ws.append(r)
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D')
 for co in ws.columns:ws.column_dimensions[co[0].column_letter].width=min(68,max(16,max(len(str(c.value or '')) for c in co[:20])+2))
 for row in ws.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(wrap_text=True,vertical='top')
  ws.row_dimensions[row[0].row].height=65
 return ws
heads=[c.value for c in wb['Batch1 values'][1]]
old=list(wb['Batch1 values'].values)[1:]
sheet('New located values',heads,N)
sheet('Roussanaly ship designs',['Ship capacitykt','7bargCAPEX millionEUR','15bargCAPEX millionEUR','7bargOPEX millionEUR/year','15bargOPEX millionEUR/year','Fuel g/tCO2/km','Source','Applicability'],shiprows)
sheet('Liquefaction pressure cases',['Case','barg','Purity%','Recovery%','Densitykg/m3','ElectricitykWh/t','TotalcostEUR/t','Source','Caution'],liqrows)
master=[];seen={};firstbatch={r[0]:r for r in list(wb['Batch1 studies'].values)[1:]}
for m in M:
 sid=m['batch_id'];doi=''
 if sid.startswith('B1'):
  s=firstbatch[sid];doi=s[4];role=s[6];summary=s[9];limits=s[11];status='Targeted methods/results extraction';loc='See Batch1 studies/values'
 else:
  raw=json.loads((B/f'batch{sid[1]}'/sid/'raw_pages.json').read_text())
  header=' '.join(raw[:2]);cand=re.findall(r'10\.\d{4,9}/[^\s]+',header)
  doi=(cand[0].rstrip('.,;)') if cand else 'Report identifier in source')
  if sid=='B2-10':doi='SSRN5070419 / GHGT-17'
  role,summary,limits=profiles[sid]
  status='Targeted sections and quantitative extraction' if sid in readpages else 'Abstract/relevance screening; detailed inventory extraction pending'
  if sid=='B3-46':status='Duplicate publication; canonical B2-17'
  loc='PDF pages '+', '.join(map(str,readpages.get(sid,[1])))
 identity=doi.lower()
 duplicate=seen.get(identity,'') if identity not in ['report identifier in source'] else ''
 if sid=='B3-46':duplicate='B2-17'
 if not duplicate:seen[identity]=sid
 master.append([sid,Path(m['result']['path']).stem,doi,role,status,loc,summary,limits,m['pages'],duplicate,m['result']['path'],m['sha256']])
sheet('Master library',['UploadID','Title','DOI/reportID','Paper1 relevance','Reading stage','Checked source sections','Digest / contribution','Transferability / limitations','PDF pages','Duplicate of','Source PDF','SHA256'],master)
assert len(master)==84 and [r[9] for r in master if r[9]]==['B2-17']
unique=83

claimmap=[('S01','B3-42','25-year yearly rollout, delayed hypothetical domestic sink and foreign transport confirmed. Also includes system emissions and BAU comparison; gap must be narrower.'),('S02','B2-11','110-plant count confirmed; boundary capture plus truck-to-port, excludes onward shipping/storage.'),('S03','B2-08','0.4Mt/year,715km,99%,33.8EUR/t,41.9EUR/t last1%,1.9EUR/t difference located. Describe41.9 as average incremental tranche cost, not instantaneous marginal cost.'),('S04','','Budiarto2025 full paper not supplied in the84 PDFs; original claims remain unverified.'),('S05','B2-05','9% target shortfall and5% cost increase support established multimodal additional-storage mechanism.'),('S06','B3-27','33articles, fewer-than-half full-chain coverage confirmed. Review evidence not primary technology inputs.'),('S07','B2-12','30years, post-capture boundary,1ttransported reference and3.3–14.2% burden confirmed; results actually span32.8–142.1kgCO2e/tstored.'),('S08','B2-10','15what-if scenarios,30years and6year delays confirmed. Implemented results focus oncost.'),('S09','B3-39','Injectivity can favour a longer economic shipping route; does not establish netGHG benefit.'),('S10','B3-07','Cost ranking reversal and unequal route lengths confirmed; printed injection-rate conversion requires correction.'),('S11','B3-41','Pressure-limited assessment confirmed; printedaggregateannualrate has a reconciliation issue.'),('S12','B3-37','Small long-horizon effect of time-varying injection confirmed for studiedBuntercases; essential null-effect benchmark.'),('S13','B3-38','7/15barg cases now verified with detailed fleet and conditioning tables.'),('S14','B3-30','Boundary sensitivity confirmed; reportedbreak-even price is economic, notPaper1netGHGbreak-even.')]
sheet('Proposal claim audit',['OriginalstudyID','SuppliedprimaryID','Verification / correction'],claimmap)
extraissues=[
['Q19','B2-08','pp7–8','Buffer denominator and completion case','5120t at99% is102%of5000tship;5890t at100% is118%.118%in99%case refersaverage-cycleCO2.','Use case-specific absolute numbers and named denominators.'],
['Q20','B2-08','p6Table2','Designpower printedW with1500/2000/2500','Do not assume these mean actualwatts for these vessel sizes.','HOLD power units; fuel-rate rows retained separately.'],
['Q21','B3-07','p11','2800kg/s described as1Mt/year','365-day annualisation gives88.3008Mt/year; a duty-cycle explanation or source correction is required.','Do not substitute28or31.7kg/s withoutprimaryclarification.'],
['Q22','B3-41','p11Table5','Totalrate22620Mt/year vs countryrows','7954+127+1603+4925+55=14664Mt/year; printedUKsubtotals mayhavebeencountedtwice.','HOLDaggregate; keep countryrows and site-method limitations.'],
['Q23','B3-29','p10versusp8','Printedventedtonneamounts scale ambiguity','p8reports25642kgmole atbaselineand1.03%initialCO2; p10says1.126ton.','HOLDmassbasedp10numbers; use originalmolarquantitywithconditions.'],
['Q24','B3-35','p7','Lowemissionsdependonelectricityassumption','1.4%chainresultassumes100%CO2captureatliquefactionpowersupply;alternative0.35kg/kWh adds3.85%for110kWh/t.','No unqualifiedmodernfullLCAfactor or electricity/fuel-energy mixing.'],
['Q25','B3-42 / B3-14 / B2-13','Methods/results','Priorartcloserthanproposalpositioning','YearlyBAUemissions, temporal sinkconstraints, compensationpower and cumulativecarbonpayback already exist across suppliedpapers.','Claimincrementalvalueofjointdeliverability/operationsresolution; do notclaimfirstdynamicormatchedcounterfactualmethod.'],
['Q26','B2-18','Methods p10','Planetarylimitinterpretation','Risk-screenedcentral/sensitivityresourcewithnormativeexclusionsand50yearconversionperiod.','Not a literallegalcap, confidenceinterval, orannualinjectionservice.'],
['Q27','B3-06','p1','300Mt/year perplant vs9Mt/yearcluster','Apparentabstractscaleerror.','HOLDperplantcapacity; reconcileoriginaltables.'],
['Q28','B2-17 / B3-46','p1DOI','Duplicatepublication','Sameauthors/title/DOI; differentfilehash.','Countonepublicationandretainbothuploadpaths.'],
['Q29','B3-27','p1versusp9','Electricity-projectioncoveragewording','Abstractbelowonequarter;bodylessthanhalf forforecast/variableelectricity discussion.','No inferred exactcount; distinguishdefinitionsbeforeciting.']]
iss=wb['Evidence issues']
for r in extraissues:iss.append(r)
read=wb['Read me'];read['B2']=f'Master intake:84PDFuploads,83unique publications (one duplicate);20first-batch targeted reviews plus later targeted readings and relevance screens. Stage explicit for every source.'
read['B3']='Drive not accessed; individually uploaded PDFs supply current evidence. OversizedZIP not read, but standaloneplanetary-limitPDF now reviewed.'
read['B4']='13of14 originalproposal references now located in uploadedprimaryPDFs;Budiarto2025not supplied. SeeProposalclaim audit.'
read['B5']=f'{len(old)+len(N)} located/derived records; original20proposal-onlyvalues keptseparate. Ranges and groupedcases are single records; records are not independent measurements.'
read['B8']='Evidence is sufficient for a sourced methods/manuscript scaffold, not a calibrated Japan–Malaysia–Australia result. Per-source detailed-extraction status and critical gaps remain explicit.'
read['B9']='Complete pending detailed inventories and supplements; reconcile HOLD records; select named common source and accessible sinks; then calibrate/verify model.'
wb.save(O/'Paper_1_master_evidence.xlsx')
for name,heads_,data in [('master_library.csv',[c.value for c in wb['Master library'][1]],master),('new_values.csv',heads,N),('all_located_values.csv',heads,list(old)+N),('proposal_claim_audit.csv',[c.value for c in wb['Proposal claim audit'][1]],claimmap)]:
 with (O/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.writer(f);w.writerow(heads_);w.writerows(data)
(O/'source_manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2))
T=O/'source_page_text';T.mkdir(exist_ok=True)
for sid,ps in P.items():
 (T/f'{sid}.txt').write_text('\n\n'.join(f'===== {sid} | PHYSICAL PDF PAGE {i} =====\n{p}' for i,p in enumerate(ps,1)),encoding='utf-8')

summary=f'''# Paper 1 — consolidated literature digest and research decisions

## Coverage
84 uploaded PDFs ({sum(m['pages'] for m in M)} physical pages) were successfully downloaded and text-extracted. They represent 83 unique publications: B2-17 and B3-46 share the same DOI. File hashes differ, so both upload records are retained. The workbook records the depth of reading explicitly: the initial20 have targeted methods/results extraction;19 later papers have selected sections checked; the remaining papers have abstract/relevance screening rather than a completed numerical inventory. Several selected later papers were also read in their abstracts; screening is not labelled a full review.

There are {len(old)+len(N)} located or explicitly derived parameter/result records, plus the original20 proposal-only claims kept in separate sheets. Record counts include ranges, operating cases, conversion checks, and multiple scenarios from the same study; they are not independent measurements. Physical PDF page numbering starts at1. Primary extraction establishes what a PDF reports, not scientific truth or transferability to the proposed route. No plot-only value was fabricated. Detailed extraction of all inventories, digitisation of eligible plots and unsupplied supplements remains outstanding for some sources. The standalone planetary-limit PDF is now reviewed; the oversizedZIP and Drive folder were not accessed.

## Main decision: tighten the contribution
Becattini et al.2022 (B3-42) already compares yearly system emissions against business-as-usual in a25-year rollout, including overseas storage and a delayed hypothetical domestic sink. Lee et al.2014 (B3-14) already includes time-dependent source/sink constraints and compensatory power for capture losses. Nöhl et al.2025 (B2-13) already defines cumulative carbon payback for transport-infrastructure switching. Fraga et al.2024 (B2-12) already integrates multi-period cost/GHG optimisation, ships, conditioning, hubs and injection; Bertoni et al.2025 (B2-04) embeds physical reservoir dynamics in infrastructure optimisation. Jeon et al.2026 (B3-29) already couples dynamic cargo-tank/BOG operation to a well-to-wake transport GHG metric.

The defensible question is consequently empirical and comparative: for a common industrial source and consistent boundaries, does jointly resolving usable storage delivery and voyage/terminal operations materially move the domestic-versus-foreign carbon break-even region or route ranking beyond these established approaches? A first-integration, first-dynamic-model, first-matched-baseline or first-carbon-payback claim is not supported. This review does not prove that the exact proposed comparison is absent from all literature. Budiarto2025, cited in the proposal, remains unsupplied.

## Strongest numerical anchors
- Shipping uncertainty: Bjerketvedt et al.2020 (B2-08, pp6–8) uses0.4Mt/year over715km,12knots and candidate3750/5000/7500tships. Fuel rates are0.5/0.6/0.7t/hour at constant power and0.8/0.9/1.1t/hour at the alternative full-speed setting. At99%completion, average cost isEUR33.8/t and buffer5120t; at100%, buffer5890t and the average cost of the extra1%isEUR41.9/t. The last number is not an instantaneous marginal derivative or the overall100%average cost.
- Conditioning and fleet states: Roussanaly et al.2021 (B3-38, pp7–8) assumes26km/hour,12hexporthandling,12hharbouror36hoffshore receiving,8400operatinghours/year and1.2-times-ship buffers. Pure-feed liquefaction energy is96.3/90.4kWh/t at7/15barg; already-pressurised inland-feed cases are17.4/9.0kWh/t. These values are different feed boundaries, not an uncertainty interval. Detailed14liquefaction cases and18vessel-design rows are transcribed.
- Post-capture GHG: Fraga et al.2024 (B2-12, pp18/20) reports32.8/46.3kgCO2e/tstored forNL,142.1/139.0forSM and41.5/39.2forcombined bestsolutions, respectively for0.7/1.5MPa. Capture is excluded. Their LNG propulsion inventory is629gCO2e/kWh, split488combustion+141upstream (p10); do not add an upstream factor again.
- Domestic Japanese delivery: Higashi-Niigata (B1-07, pp6–9) provides three-injector cases with/without three relief wells and25–30%greater injection in the latter. Absolute mass/pressure scales are unavailable in the supplied plots. Do not invent site annualMt/y from those figures.
- Reservoir-dynamics null control: Kolster et al.2018 (B3-37, pp3–7) tests24Mt/year field targets,12sites and±80%rate oscillations changing every2.5or5years over50years, finding limited long-horizon influence for the studiedBuntercases. Added model complexity is not automatically valuable.
- Planetary context: Gidden et al.2025 (B2-18, pp1/2/10) estimates a prudent1460GtCO2, sensitivity1290–2710Gt, using risk-based exclusions and a pressure-limited conversion for a50year injection period. This supports treating storage as finite; it supplies neither an annual Japanese/Malaysian/Australian service nor a regulatory quota.

## Corrections and holds
The master workbook adds a proposal-claim audit and29quality issues. Material corrections include the Bjerketvedt buffer denominator, Kang's printed2800kg/s-to-1Mt/year mismatch, and Karvounis/Blunt's Table5 annual-rate total: the five country rows sum14664Mt/year rather than printed22620. These source statements are retained and flagged, not silently repaired. Also retain the earlier holds on Gorgon sustained-rate units, Ketzin pressure-gradient units, thermal pressure datums, BOG power-percentage statements and interface power/energy labels.

Other boundaries requiring care are Aspelund2006's1.4%CO2 burden, which assumes effectively zero-emission liquefaction electricity, and different BOG-voyage models. Fraga's46day venting-onset assumption and Jeon's approximately13day GHG crossover arise from different tank, impurity and operating assumptions; they are not interchangeable universal thresholds.

## What can be drafted and what remains
A working manuscript scaffold accompanies this pack: title, cautious abstract, sourced introduction, retained research objectives, model equations, B0–B3comparison, scenario/validation plan and results placeholders. It includes no invented results. The method should represent pressure management, thermal operating limits, cargo inventories/BOG and terminal conditioning where supported, and should keep operational feasibility separate from commercial/legal access.

Before computing regional conclusions, obtain a named Japanese industrial source and its matched no-CCS baseline; numerical site/year injection service and allocated storage capacity; feasible ports/routes, loading windows and ship fuel curves; country/year electricity and upstream fuel factors; pressure-management energy and water-disposal feasibility; asset construction and retention data. Governance papers structure feasibility and liability checks but do not establish current route permissions. Complete the detailed inventories/supplements listed as pending in the library. Economic break-even prices and cost-optimal distances must never be reported as carbon-mitigation break-even conditions.

## Later-batch per-paper digest
'''
for r in master[20:]:summary+=f'\n### {r[0]} — {r[1]}\n\nIdentifier: {r[2]}. Reading stage: {r[4]}. Checked: {r[5]}.\n\n{r[6]}\n\nPaper1role: {r[3]}. Limit: {r[7]}\n'
(O/'Paper_1_master_digest.md').write_text(summary,encoding='utf-8')
def docx(text,path):
 d=Document()
 for l in text.splitlines():
  if l.startswith('### '):d.add_heading(l[4:],2)
  elif l.startswith('## '):d.add_heading(l[3:],1)
  elif l.startswith('# '):d.add_heading(l[2:],0)
  elif l.startswith('- '):d.add_paragraph(l[2:],style='List Bullet')
  elif l.strip():d.add_paragraph(l)
 d.save(path)
docx(summary,O/'Paper_1_master_digest.docx')

print(json.dumps({'uploads':84,'unique_publications':unique,'physical_pages':sum(m['pages'] for m in M),'new_records':len(N),'total_located_records':len(N)+len(old),'later_targeted_sources':len(readpages),'proposal_references_located':13},indent=2))
