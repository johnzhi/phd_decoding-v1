# Outstanding work

- Complete detailed inventories for the 44 unique publications currently marked as abstract/relevance screened.
- Obtain unsupplied supplements and the Budiarto (2025) paper; verify its claimed annual injectivity profiles.
- Resolve the 29 source/data issues, particularly rate units, pressure gradients/datums, aggregate annual rates and power-versus-energy labels.
- Obtain numerical annual injection series for Higashi-Niigata; vertical scales cannot be reliably recovered from the supplied PDF.
- Select a common Japanese industrial source and accessible named sinks, with route-specific fuel, terminal and lifecycle inputs.
- Build and verify B0–B3 only after traceable input selection. Numerical research results remain ungenerated.
