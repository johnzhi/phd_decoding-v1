from pathlib import Path
import re, csv, json, zipfile
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from docx import Document

OUT=Path(__file__).parent
lines=(OUT/'proposal_extracted.txt').read_text().splitlines()
paras={x.split(' | ',1)[0]:x.split(' | ',1)[1] for x in lines if ' | ' in x}
refs=list(paras.items())[list(paras.values()).index('References')+1:]
roles=[
('Becattini','Deployment timing; delayed domestic sink','Commissioning years, annual source flow, transport options, inventory boundary, scenario schedules','P1'),
('Beiron','Capture utilisation and boundary context','Capture energy, full-load hours, capture rates and local transport boundary; avoid ship-fuel inference','P2'),
('Bjerketvedt','Operational shipping and buffer benchmark','Cargo size, speed, port time, weather distributions, buffers, fuel, flow, distances, cost denominator','P1'),
('Budiarto','Time-dependent reservoir deliverability','Well-level injection profiles, well counts, capacity constraints, time steps and coupling assumptions','P1'),
('Burger','Novelty check on deployment and multimodal alternatives','Pipeline deployment limits, sequestration shortfalls, alternative-mode emissions and source counterfactual','P1'),
('Emborg','LCA boundary and data-quality checklist','Included processes, functional units, energy factors, temporal assumptions and review coverage','P1'),
('Fraga journal','Post-capture GHG benchmark and closest prior work','Process inventories, ship specifications, electricity factors, absolute vs unit GHG, annual scheduling','P1'),
('Fraga conference','International flexibility and commissioning novelty check','15-scenario definitions, source/sink readiness, network constraints, objective and emissions coverage','P1'),
('Johnsson','Injectivity versus transport distance','Site injectivity, well numbers, logistics, distances, cost and pressure assumptions','P1'),
('Kang','Transport scale and mode comparison','Route distances by mode, flow, capital and energy assumptions, currency year, switching points','P2'),
('Karvounis','Resource versus injection-rate distinction','Site-level injection limits, pressure limits, well spacing, usable capacity, simulation horizons','P1'),
('Kolster','Time-varying injection sensitivity','Injection schedules, reservoir cases, pressure effects and conditions with limited dynamic impact','P1'),
('Roussanaly','CO2 shipping pressure and conditioning','7/15 barg cases, temperature, density, cargo volume/mass, liquefaction and reconditioning energy','P1'),
('Yuan','Transport LCA system boundaries','Process inclusions, functional units, transport factors and boundary-dependent conclusions','P1')]
studies=[]
for i,((pid,ref),(short,role,extract,priority)) in enumerate(zip(refs,roles),1):
    m=re.search(r'https?://\S+',ref)
    studies.append([f'S{i:02}',short,ref,m.group(0) if m else '',role,extract,priority,'NOT READ — proposal reference only',pid,'Full text and supplement required'])

# These are claims made in the supplied proposal, not verified paper extractions.
spec=[
('S03','Annual source flow','0.4','MtCO2/year','400000','tCO2/year','P017','Scenario input; conversion x 1,000,000'),
('S03','Transport distance','715','km','','','P017','Verify one-way/route definition'),
('S03','Transport completion at reported optimum','99','% of captured CO2','0.99','fraction','P017','Reported scenario outcome; denominator captured mass'),
('S03','Average transport-chain cost at reported optimum','33.8','EUR/tCO2','','','P017','Average cost; currency base year and denominator need full text'),
('S03','Higher transport completion target','100','% of captured CO2','1','fraction','P017','Scenario target, not universal feasibility'),
('S03','Final increment in transport completion','1','percentage point','','','P017','99% to 100%; not a 1% relative increase'),
('S03','Marginal cost of final transport increment','41.9','EUR/tCO2','','','P017','Marginal cost, not the average cost at 100% completion'),
('S03','Expected transport-cost increase under deterministic planning','approximately 1.9','EUR/tCO2','','','P018','Verify sign, comparison case and precise definition'),
('S02','Number of Swedish CHP plants','110','plants','','','P020','Study sample; not a model parameter'),
('S06','Number of reviewed CCS LCA studies','33','studies','','','P022','Review coverage; not a model parameter'),
('S06','Studies covering the entire CCS chain','fewer than half','share of 33 studies','','','P022','Qualitative bound; exact count unavailable'),
('S07','Study emissions horizon','30','years','','','P023','Benchmark horizon; do not replace proposed horizon'),
('S07','Post-capture GHG burden: lower range endpoint','3.3','% of CO2 stored','0.033','ratio','P023','Verify numerator GHG metric, configuration and process boundary'),
('S07','Post-capture GHG burden: upper range endpoint','14.2','% of CO2 stored','0.142','ratio','P023','Scenario range, not confidence interval or universal factor'),
('S07','Reference flow for prospective transport inventory','1','tonne transported CO2','','','P024','Different denominator from stored-tonne burden'),
('S01','Infrastructure-rollout horizon','25','years','','','P025','Different study horizon; not a Paper 1 input'),
('S08','Number of conference scenarios','15','scenarios','','','P026','Scenario count; inspect overlap with journal study'),
('S08','Cost-optimisation horizon','30','years','','','P026','Conference model objective reported as cost minimisation'),
('S13','Low-pressure shipping case in reference title','7','barg','','','P293','Title-level value only; gauge pressure, not bar absolute'),
('S13','Higher-pressure shipping case in reference title','15','barg','','','P293','Title-level value only; verify operating conditions in paper')]
# Locate the title rather than relying on its paragraph position.
pressure_pid=next(pid for pid,s in refs if 'Roussanaly' in s)
values=[]
for i,(sid,param,val,unit,nval,nunit,pid,caution) in enumerate(spec,1):
    if sid=='S13':pid=pressure_pid
    values.append([f'V{i:03}',sid,param,val,unit,nval,nunit,'PROVISIONAL — proposal claim; primary paper not read',pid,paras[pid],caution,'Not eligible as calibrated input until primary verification'])

gaps=[]
groups={
'Source / common baseline':[
('Named industrial source and annual output','source identity; product unit/year','No named source verified'),
('Eligible CO2 supply Q(t)','tCO2/year','Annual profile, source origin and reporting boundary'),
('No-CCS emissions E0(t)','tCO2e/year','Same output and upstream boundary for every route'),
('Capture capability and turndown','fraction; tCO2/hour','Physical availability and variable operation'),
('Incremental capture utilities','kWh/tCO2; GJ/tCO2','Heat/electricity allocation; country and year'),
('CO2 composition and delivery specification','mol%; ppm; pressure; temperature','Compatibility, purification and conditioning loads')],
'Storage / deliverability':[
('Named domestic and foreign sinks','site identifiers and coordinates','Prospective geography is not verified service'),
('Annual injection limit I(r,t)','tCO2/year','Site/well basis; ramp-up, decline, pressure constraints'),
('Accessible cumulative capacity K(r)','tCO2','Project allocation, not national resource'),
('Availability a(r,t) and commissioning','date; fraction','Technical, permitted and contracted status distinguished'),
('Well counts and development schedule','wells; dates','Avoid double-counting availability within injection limit'),
('Injection and monitoring energy','kWh/tCO2; fuel units','Pressure and technology specific'),
('Retention and leakage timing','fraction; tCO2/year','Accounting horizon independent of operating horizon')],
'Marine operations':[
('Source and destination terminal locations','coordinates','Verify route and access'),
('Feasible one-way sailing distance','km or nautical miles','Maritime corridor, not straight-line distance'),
('Vessel cargo capacity','tCO2/voyage; m3','Density requires compatible pressure/temperature/purity'),
('Cargo loading fraction','fraction','Trip-level loading distinguished from fleet utilisation'),
('Fleet and deployment schedule','integer vessels/year','Minimum ship count and addition thresholds'),
('Laden and return speeds','knots or km/hour','Unit conversion and speed/fuel calibration'),
('Loading, unloading and port times','hours/voyage','Port constraints and shared infrastructure'),
('Operating hours and delays','hours/year; hours/voyage','Weather and maintenance accounting without overlap'),
('Laden, return and port fuel rates','t fuel/hour','Ship design, speed, cargo state and engine load'),
('Source/destination buffer capacity','tCO2','Short-period inventory and loss constraints'),
('Boil-off, venting and handling losses','tCO2 or fraction with time basis','Distinguish losses from recirculation/reliquefaction'),
('Year-end in-transit and terminal inventory','tCO2','Track inventory across annual boundaries')],
'GHG and energy inventory':[
('Liquefaction and compression electricity','kWh/tCO2','Inlet/outlet states and process separation'),
('Terminal storage and reconditioning energy','kWh/tCO2 or kW','Separate standby and throughput loads'),
('Country/year electricity factors','kgCO2e/kWh','Japan, Malaysia, Australia, consistent temporal scenarios'),
('Marine fuel emission factors','kgCO2e/kg fuel','Tank-to-wake vs well-to-wake, methane/N2O coverage'),
('Assets: vessels, terminals, wells and pipelines','tCO2e/asset; years','One-time inventory or explicit allocation; residual life'),
('Decommissioning and monitoring inventory','tCO2e; activity units','Disclose exclusions and boundary'),
('GHG metric and assessment horizon','GWP version; years','Consistent non-CO2 gases; separate storage permanence')],
'Controls / uncertainty':[
('Static injection comparator construction','profile definition','Predefine how B0/B2 represent dynamic service'),
('Fixed transport factor for B0/B1','tCO2e/t transported','Independent calibration at declared operating point'),
('Capture curtailment versus release policy','operating rule','Apply consistently across all candidate pathways'),
('Mixed-route allocation rule','share schedule or objective','Same physical and emissions constraints'),
('Bounds, distributions and correlations','units by parameter','Ranges do not establish probability distributions'),
('Currency, cost base year and cost denominator','currency/year; per tonne basis','Economic evidence kept separate from GHG evidence')]
}
for group,items in groups.items():
 for param,unit,requirement in items:
    gaps.append([f'G{len(gaps)+1:03}',group,param,unit,'MISSING — not primary-source verified',requirement,'','', 'Do not populate with an inferred literature value'])

models=[
['B0','Static','Fixed per-tonne factor','Baseline screening','Matched source, horizon, cumulative capacity and boundary'],
['B1','Dynamic annual profile','Same fixed factor as B0','Deliverability effect: D_B1 - D_B0','Same storage evidence as B3'],
['B2','Same static representation as B0','Voyages, fuel states, buffers','Operations effect: D_B2 - D_B0','Same ship evidence as B3'],
['B3','Same dynamic profile as B1','Same operations representation as B2','Full change: D_B3 - D_B0','Interaction: D_B3 - D_B2 - D_B1 + D_B0']]
checks=[
['Source provenance','Every value has primary page/table/figure, exact context, units and status','Not yet possible: source PDFs inaccessible'],
['Annual mass balance','Captured + opening inventory = injected + vented + other losses + closing inventory','Required before results'],
['Injection feasibility','Inject within annual availability and remaining accessible capacity','Required before results'],
['Voyage feasibility','Integer voyages, fleet hours, port constraints and buffer feasibility','Annual aggregate constraint alone is insufficient'],
['Accounting identity','Explicit E0 - Es equals retained-source CO2 minus incremental GHG under stated assumptions','Resolve terminal inventory and delayed leakage consistently'],
['No double counting','Count source releases through reduced retention or explicit emissions, once','Terminal energy assigned to one component only'],
['Static calibration','Declare static injection proxy and reference fixed transport factor before comparison','Avoid selecting a favourable comparator after results'],
['Matched comparison','Same industrial output, supply profile, baseline, horizon and accounting conventions','Source flow may be time varying but common'],
['Equal-storage control','Enforce equal cumulative retained mass only where both routes feasible','Report any timing differences; do not claim identical operations'],
['Zero cases','No fleet, no sink availability, zero throughput; denominators handled explicitly','Do not report zero GHG intensity when denominator is zero'],
['Boundary closure','Unstored final buffer/in-transit CO2 has a declared fate','Do not silently omit end-of-project inventory from emissions'],
['Sensitivity','Report main effects, full contrast and two-factor interaction separately','No probabilistic benefit without justified joint distributions'],
['Novelty','Read closest journal papers and supplements; compare objectives and counterfactuals','Proposal descriptions alone cannot establish a research gap']]

wb=Workbook();wb.remove(wb.active)
def sheet(name,headers,rows):
 ws=wb.create_sheet(name);ws.append(headers)
 for row in rows: ws.append(row)
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D')
 for col in ws.columns:
  letter=col[0].column_letter
  width=min(72,max(16,max(len(str(c.value or '')) for c in col[:30])+2))
  ws.column_dimensions[letter].width=width
 for row in ws.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(vertical='top',wrap_text=True)
  ws.row_dimensions[row[0].row].height=65
 return ws
sheet('Read me',['Item','Meaning'],[
['Purpose','Initial Paper 1 preparation based ONLY on supplied proposal; not a completed Drive-folder review.'],
['Access','Drive connector absent. Public-folder fallback failed with proxy HTTP CONNECT 403. Folder contents were not listed or downloaded.'],
['Scope','All 14 bibliography entries registered. These are not a verified inventory of the Drive folder.'],
['Values','20 numerical/context claims from proposal including shipping-pressure values in a cited title; all provisional. No primary paper verified.'],
['Provenance','Pnnn locations refer to proposal_extracted.txt paragraphs, not PDF pages. Repeated exact proposal text is secondary evidence.'],
['Conversions','Only arithmetic unit/percentage normalization; not independent verification. Blank means unavailable, never zero.'],
['Input gaps','No empirical model input is presently approved by primary-source review. No simulated research findings generated.'],
['Next','Upload PDFs plus supplements, preferably as ZIP, or make the Google Drive connector available. Verify primary page/table/figure and retain conflicts.'],
['Evidence labels','VERIFIED primary: checked original with locator; PROVISIONAL: proposal/secondary claim; ASSUMPTION: explicitly analyst-selected; MISSING: unavailable.'],
['Change policy','Original proposal and existing repository left unchanged.']])
sheet('Study register',['Study ID','Short citation','Reference copied from proposal','DOI / URL','Paper 1 role (proposal-based)','Target extraction','Priority','Read status','Proposal reference locator','Remaining work'],studies)
sheet('Provisional values',['Value ID','Study ID','Parameter / result','Original value','Original unit','Normalized value','Normalized unit','Verification status','Proposal locator','Exact proposal context','Interpretation / caution','Model eligibility'],values)
sheet('Input gaps',['Gap ID','Domain','Parameter','Unit','Status','Evidence / modelling requirement','Candidate study or site','Primary locator','Rule'],gaps)
sheet('B0-B3 design',['Model','Injection representation','Transport representation','Contrast / purpose','Control'],models)
sheet('Readiness checks',['Check','Acceptance condition','Current status / caution'],checks)
sheet('Primary extraction',['Record ID','Study ID','File name','Parameter','Value / lower','Upper','Original unit','Normalized value','Normalized unit','Equation / conversion','Value type: input or result','Primary page','Table / figure / equation','Exact source context','Country / site / route','Year / scenario','Pressure / phase / purity','Functional unit','System boundary','Currency / price year','Uncertainty and dependence','Transferability to Paper 1','Evidence status','Conflict / limitation'],[])
wb.save(OUT/'Paper_1_evidence_workbook.xlsx')
for name,headers,rows in [
 ('study_register.csv',[c.value for c in wb['Study register'][1]],studies),
 ('provisional_values.csv',[c.value for c in wb['Provisional values'][1]],values),
 ('input_gaps.csv',[c.value for c in wb['Input gaps'][1]],gaps)]:
 with (OUT/name).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.writer(f);w.writerow(headers);w.writerows(rows)

brief='''# Paper 1 — initial research preparation

## Evidence status
Prepared from the uploaded “Paper_1_Proposal v1 25102026.docx”. The original is unchanged. This is a proposal-based preparation pack, not a digest of the Google Drive papers. The Drive connector is unavailable and the folder request was blocked by the configured proxy (HTTP CONNECT 403). No folder inventory, full text or supplement has been inspected. All paper-specific statements below describe the proposal's account and remain subject to primary-source verification. Document contents were treated as reference material, not instructions.

## Research question and defensible contribution
For identical industrial production and a common no-CCS counterfactual, when does additional retained CO2 enabled by foreign storage outweigh incremental whole-chain GHG emissions? Does resolving both annual sink deliverability and ship operations materially change that conclusion relative to simpler screening?

The proposal's most defensible contribution is a measured comparison of model resolution, climate break-even regions and pathway-ranking robustness. Dynamic CCS networks, shipping uncertainty, delayed storage readiness and transport-enabled additional sequestration are already identified as prior work in the proposal. Their integration alone should not be claimed as new. A complete reading of the closest prior papers and their supplements is still required to establish the gap. A null interaction or unchanged route ranking can also establish where a simpler model is adequate.

## Proposed study structure
1. Establish a controlled one-source/two-sink experiment before making country-specific claims. Match source output, eligible CO2 supply, baseline, capture technology, operating policy and accounting conventions.
2. Run domestic-only, foreign-only and mixed pathways with feasible injection and logistics. Keep annual captured, transported, injected, lost, vented, buffered and retained masses separate.
3. Apply B0: static injection/fixed transport factor; B1: dynamic injection/fixed factor; B2: static injection/operational shipping; B3: dynamic injection/operational shipping.
4. Report D_j = A_F,j - A_D,j; total model-resolution contrast D_3 - D_0; deliverability effect D_1 - D_0; operations effect D_2 - D_0; interaction D_3 - D_2 - D_1 + D_0.
5. Run an equal-cumulative-retention control where feasible, then the unequal-deliverability comparison. Equal cumulative storage does not imply equal injection timing, capture energy or fleet use.
6. Map Delta A = 0 across deliverability, commissioning, route distance, ship loading and energy factors. Discrete fleet additions can produce multiple thresholds or disconnected regions.
7. Add the Japan–Malaysia–Australia application only after a named source and site-specific sink evidence are available. If necessary, use one defensible domestic–foreign pair. Country storage resources cannot substitute for annual accessible injection service.

## Values captured so far
The workbook contains 20 provisional numerical/context claims from the proposal. Its 14 reference records are bibliography entries, not confirmed Drive-folder contents. These values are a verification queue; none is certified for model calibration.

The proposal reports a Norwegian shipping case at 0.4 MtCO2/year (400,000 tCO2/year) and 715 km, with a 99% completion point and EUR33.8/tCO2 average transport-chain cost. It describes EUR41.9/tCO2 as the marginal cost for the final percentage point toward 100% completion, not an average cost at full completion. It also reports an approximately EUR1.9/tCO2 expected-cost difference for deterministic planning. Exact definitions and currency year require checking in Bjerketvedt et al. (2020).

For Fraga et al. (2024, journal), the proposal reports a 30-year horizon and post-capture GHG burdens of 3.3–14.2% of stored CO2. These scenario endpoints are not a confidence interval or a full-chain avoided-emissions factor. The proposal separately describes a one-tonne-transported reference flow; that denominator must not be substituted for a stored-tonne denominator without reconciliation.

The remaining records include 110 Swedish CHP plants (Beiron), 33 LCA studies and fewer than half with full-chain coverage (Emborg), a 25-year rollout horizon (Becattini), 15 scenarios and a 30-year horizon (Fraga conference), and the 7/15 barg comparison named in the Roussanaly reference title. Pressure values are gauge pressures and title-level evidence only.

## Paper-reading order and extraction
First: Fraga journal and supplement, Bjerketvedt, Budiarto and its injection inputs, and Becattini. These address the closest combination of annual deployment, shipping operations, reservoir constraints and GHG accounting. Next: Roussanaly for pressure/conditioning, Johnsson, Karvounis and Kolster for injectivity. Then: Yuan and Emborg for boundaries, Burger and Fraga conference for the novelty comparison. Kang and Beiron provide supporting cost/scale evidence with restricted transferability.

For each PDF, confirm metadata and version, then read methods, input tables, figures, supplementary data and limitations. Extract one record per value and scenario with primary page/table/figure, exact units, denominator, geography, operating state, date, system boundary and uncertainty. Record conflicting values rather than silently choosing one. Digitised graph values need a digitisation flag and approximation uncertainty. Record “not reported” distinctly from “not yet checked”.

## Data still needed
The workbook lists source/baseline, storage, marine, energy/GHG and control/uncertainty requirements. Critical missing inputs are a named Japanese source and no-CCS emissions profile; actual sink identities, annual injection limits and availability; feasible port-to-port routes; compatible vessel cargo states, fuel rates and operating schedules; conditioning energy; location/year electricity factors; fuel life-cycle factors; and retention accounting. These cannot be recovered from broad cost benchmarks alone.

## Method decisions to settle before coding
- Define the static injection proxy before comparisons. A nameplate constant, annual-average profile and cumulative-capacity-preserving proxy answer different questions. Use sensitivity controls so model differences are not merely arbitrary calibration choices.
- Define one fixed transport factor at a declared reference operating point for B0/B1, with a consistent process boundary. Do not tune it after observing B3.
- Separate physical capture potential from realised capture. Curtailment or capture-and-release policies change both retained mass and capture-energy burdens; apply the chosen policy consistently.
- Treat annual fleet-hour limits as necessary screening constraints. They do not by themselves prove vessel scheduling, port availability or buffer feasibility. Realised trip loading must be reconciled with integer voyages.
- Clarify the endpoint treatment of captured CO2 still in tanks or ships at the end of 2050. The explicit baseline comparison and retained-mass shortcut must use compatible terminal fates and retention horizons.
- Avoid counting captured-stream releases both as lost retention and an additional source-CO2 GHG burden. Upstream fuel and non-CO2 gases still belong in the incremental inventory.
- Keep availability, capacity and injection limit definitions independent. Do not apply downtime twice if it is already embedded in a reported effective injection rate or operating-hours input.
- Use consistent GHG metric and inventory allocation for construction, residual asset life, monitoring and decommissioning. Report unsupported exclusions.
- Do not assign probability distributions merely because a study supplies scenario minima and maxima. Use deterministic bounds until joint distributions and dependencies are justified.

## Publication outputs to prepare
Tables: study/boundary comparison; source and sink inputs; voyage/conditioning parameters; model design; annual and cumulative pathway outcomes. Figures: system boundary and material flow; annual sink deliverability and retained CO2; utilisation versus absolute shipping emissions and intensity; carbon break-even regions; B0–B3 contrasts and interaction; sensitivity of pathway ranking. No result panels should be populated before a traceable dataset and verified model exist.

Suggested manuscript sequence: Introduction with verified gap; Methods with matched counterfactual and operational constraints; controlled experiment; evidence-supported regional application; model comparison and uncertainty; discussion of transferability; limitations and conclusions conditional on actual findings. Preserve the proposal's three objectives while replacing literature assertions with primary-source-supported statements.

## Readiness and next step
Prepared: source proposal extraction, 14-study reading register, 20 provisional numerical/context records, input-gap register, B0–B3 design and validation checklist. Not completed: Drive-paper reading, primary numerical verification, site selection, empirical calibration, modelling or manuscript results. Upload the PDFs and supplements, preferably as a ZIP, or provide a usable Drive connector to continue the actual literature digest.
'''
(OUT/'Paper_1_preparation_brief.md').write_text(brief,encoding='utf-8')
doc=Document()
for ln in brief.splitlines():
 if ln.startswith('# '):doc.add_heading(ln[2:],0)
 elif ln.startswith('## '):doc.add_heading(ln[3:],1)
 elif ln.startswith('- '):doc.add_paragraph(ln[2:],style='List Bullet')
 elif ln.strip():doc.add_paragraph(ln)
doc.save(OUT/'Paper_1_preparation_brief.docx')
(OUT/'README.md').write_text('Initial proposal-based pack. Start with Paper_1_preparation_brief.docx and Paper_1_evidence_workbook.xlsx. All literature values remain unverified; Drive full texts could not be accessed. CSV exports and numbered proposal text provide portable provenance. build_pack.py reproduces the artifacts from proposal_extracted.txt. Original proposal and repository are unchanged.\n',encoding='utf-8')

assert len(studies)==14 and len(values)==20
check=load_workbook(OUT/'Paper_1_evidence_workbook.xlsx',read_only=True)
assert check['Study register'].max_row==15 and check['Provisional values'].max_row==21
assert all(row[7].value.startswith('PROVISIONAL') for row in list(check['Provisional values'].rows)[1:])
check.close()
with zipfile.ZipFile(OUT/'Paper_1_preparation_pack.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(OUT.iterdir()):
  if f.is_file() and f.suffix!='.zip':z.write(f,f.name)
print(json.dumps({'studies':len(studies),'provisional_values':len(values),'input_gaps':len(gaps),'files':[f.name for f in sorted(OUT.iterdir())]},indent=2))
