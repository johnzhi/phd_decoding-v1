# Paper 1 — literature batch 1 digest and preparation

## Coverage and evidence status
The 20 individually uploaded PDFs were downloaded, text-extracted (248 physical PDF pages), and reviewed for methods, relevant numerical inventories, results, and limitations. Selected graphics and tables were visually checked where text extraction omitted scales or shifted headers. This pack includes 588 value records, 18 BOG process/impurity combinations, 18 ship–terminal interface combinations, 20 study digests and 18 evidence-quality issues. A record may hold a published range or grouped operating cases; this count is not a count of independent measurements. Derived arithmetic and reported model inputs/results are explicitly distinguished from observations.

This is a substantive first-batch review, not a claim that every plotted point or every secondary citation has been independently verified. Relevant curve-only quantities without readable scales are marked unresolved. Full numerical extraction of absolute Japanese injection profiles remains blocked by the supplied source's missing axis scales. Some image-only supplementary rock-property correlations are methodological context rather than inputs to the proposed screening model and were not exhaustively transcribed. The inaccessible Drive folder and oversized planetary-limit ZIP remain unread. The 14 references in the original proposal are still proposal-only evidence, preserved in separate workbook sheets. No net-mitigation simulation or numerical pathway recommendation has been produced.

## What the batch adds to Paper 1
The clearest contribution is evidence that usable injection service depends on pressure management and operating conditions, not resource size alone. Higashi-Niigata is a named Japanese candidate with history-matched forecasts and a reported 25–30% injection-volume increase with relief wells (B1-07, p8). The Malaysian Z-field study contrasts about 3%, 51% and 61% utilisation of theoretical volume across pressure-management cases (B1-13, pp8–13), but explicitly advises against further injection planning for that field. These studies support scenario structures; neither supplies contracted service for the proposed cross-border source.

Thermal effects also connect deliverability and energy. In a Malaysian caprock screen, estimated 50°C cooling lowers recommended Seal A–D pressure limits from 2153/2731/3264/3701 psi to 1632/2209/2739/3178 psi (B1-11, pp5–6). A separate Sarawak flow-assurance study reports early-life well-rate constraints and compares insulated transport with additional offshore heating (B1-08, pp7–10). These are different sites and studies: do not combine their pressure ceilings, injection fractions and energy increments into one purported Malaysian base case.

The supplied Australian South-West Hub study describes a conceptual 0.8 Mt/year, 30-year, nine-well reference configuration with a 360-bar BHP limit at 2948 m (B1-12, p18). Its no-fault-failure result applies to an isothermal model; it excludes near-well cooling stresses. The Gorgon synopsis illustrates auxiliary brine handling limiting realised CO2 delivery, but its apparent unit error prevents using the printed sustained rate as a numerical benchmark without checking the underlying study (B1-05, pp3–4).

At the transport end, the BOG study quantifies the trade-off between auxiliary electricity and CO2 purge for six process cases and three nitrogen levels (B1-19, pp3–7/13). The LP/MP interface study shows that terminal pressure mismatches add case-specific vapor handling and electricity demands (B1-20, pp3/13–14). These help replace an undifferentiated transport factor with explicit conditioning and handling, but neither supplies route-calibrated laden/return propulsion fuel use for Japan–Malaysia–Australia.

## Numerical comparisons that can be used now
1. Higashi-Niigata: three injectors with or without three pressure-relief wells; nominal injection period 2029-01-01 to 2050-01-01; pressure-limited decline around 2040; 25–30% volume gain with relief wells. Use the relative result and study design. Absolute annual mass series must be obtained, not invented from unscaled curves.
2. Malaysian pressure-managed aquifer: 4.9 / 80.13 / 95.44 Bscf across zero/one-producer cases and added injection well; BHP ceiling 5000 psi, nominal rate limit 60 MMscf/day and water limit 30000 bbl/day. Preserve gas-volume units until the standard state and density are known.
3. Malaysian thermal pressure limits: paired pressure reductions are 521 / 522 / 525 / 523 psi for Seals A–D, calculated from Tables 2–3. These are site-specific pressure differences, not directly annual injection-rate losses.
4. BOG reference: at liquid N2 = 0.10 mol%, annual process CO2 is 4510.2 t for conventional 6.5-bar case 1-1, 1418.6 t for mixed-refrigerant 6.5-bar case 1-3, and 455.1 t for mixed-refrigerant 15-bar case 2-3 (Table 6). Corresponding transported masses and costs remain paired in the workbook. Costs and emissions do not select the same pressure automatically.
5. Interface example: at LP7/MP16 bara, Table 6 reports 13603 kW total power including excess vapor reliquefaction with 26077 t liquid loaded; Table 7 reports 10495 kW with 24919 t loaded for subcooling. At an assumed 12-hour loading duration these imply approximately 6.26 and 5.05 kWh/t, respectively. This is a conditional arithmetic check, not a silently corrected source metric; loading duration and mass boundary must be confirmed.
6. Ketzin and Decatur provide observed pressure/rate histories and model-calibration examples. Use them for component checks at their own scale, with source-origin and reporting dates preserved. Do not treat several publications from the same project as independent sites.

## Changes recommended to the Paper 1 method
Preserve the matched industrial output, common no-CCS baseline, retained-mass accounting and B0–B3 comparison. Add a structured deliverability envelope that can depend on reservoir pressure, thermal constraints, available wells, water-handling capacity and interruption state. A first screening implementation can use externally specified annual profiles; pressure-resolved physics should only be claimed when supported by actual input data and calibration.

Add a pressure-management sensitivity alongside sink delay/ramp/decline: relief wells or brine production can raise cumulative injected mass but also require water treatment, disposal, pumping, wells and monitoring. Count these GHG burdens rather than crediting the extra tonnes without their enabling infrastructure. CO2 produced back through relief wells must have an explicit fate. Never apply a pressure limit from one formation to a different site.

Distinguish laden/ballast tank filling, cargo heel, voyage load fraction and annual fleet utilisation. Add BOG generation, reliquefaction, purge and auxiliary-generator emissions as separate material/energy terms. Recondensed CO2 remains cargo; retained heel is inventory, not atmospheric loss. Avoid double-counting auxiliary energy when a source process inventory already includes it.

Represent LP/MP loading and unloading conditioning at both terminals with explicit ship and terminal pressures, temperatures, liquid density, vapor return, cooling/reliquefaction and transfer time. Separate electrical power (kW), per-transfer energy (kWh), and per-tonne energy (kWh/t). Use location/year-specific grid factors on shore and a marine auxiliary generation factor onboard. The direct MGO generator factor derived from B1-19 is 0.633185 kgCO2/kWh and excludes upstream/non-CO2 effects.

For every B0–B3 comparison, retain the same source, baseline, end-inventory treatment, capture operating policy and physically feasible route. Define the static injection proxy and fixed transport factor before inspecting the comparison results. Report full contrast D3-D0 and interaction D3-D2-D1+D0 separately. These PDFs support the component mechanisms; they do not yet establish the claimed novelty or the sign of the carbon break-even outcome.

## Source-quality decisions before selecting a regional base case
Higashi-Niigata can remain a candidate Japanese sink, conditional on obtaining absolute injection/pressure series and actual accessible service dates. Do not promote ultra-deepwater sediment concepts, anonymised Malaysian Fields X/Z, or conceptual South-West Hub reference cases into a single validated commercial route. The Z-field paper's negative recommendation must remain visible. Named Malaysian and Australian export-accessible sinks with compatible reservoir and terminal evidence are still required.

Resolve the HOLD records before calibration: Gorgon sustained-rate units, Class et al.'s printed pressure gradient, pressure datums in the caprock tables, SWH stress ratio/gradient, BOG compression-power percentage discrepancies, and ship-interface specific-energy units. Preserve rather than silently repair published errors.

## Remaining evidence needed
- Named Japanese industrial source, source origin (fossil/biogenic), output and annual capture supply; no-CCS baseline and incremental capture utilities.
- Absolute site/year injection service and allocated cumulative capacity, commissioning/access evidence and pressure/thermal envelopes for each candidate sink.
- Actual maritime corridors and ports; laden/return fuel curves, speeds, voyage delays, fleet availability and buffer capacities. No supplied paper closes the route-specific propulsion inventory.
- Location/year electricity and full fuel lifecycle factors; injection/pressure-management energy; construction, wells, monitoring/decommissioning, and retention horizon.
- Original benchmark papers from the proposal, especially Fraga, Bjerketvedt, Budiarto, Becattini and Roussanaly. Their full texts/supplements have not been verified in this batch.

## Per-paper digest

### B1-01 — Onboard carbon capture and storage (OCCS) for fossil fuel-based shipping A sustainability assessment

Zanobetti et al. (2024). 10.1016/j.jclepro.2024.143343. Journal article; conceptual process/sustainability model.

A 36 MW LNG cruise-ship case compares amine scrubbing, advanced cryogenic capture, membranes and adsorption using technical, economic, environmental and social indicators. Only amine scrubbing and advanced cryogenic capture meet the case-specific onboard integration constraints. At 95% capture, reported CO2 avoidance is 85.7% and 77.5%, respectively (p8, Table 7).

Paper 1 use: Use to explain why capture fraction is not avoided-emissions fraction. Thermal and electrical demands are per kg CO2 AVOIDED, not per kg captured. The reported sustainability footprint is an aggregated index, not a CO2 emission factor.

Limits: Cruise-ship exhaust capture is not bulk CO2 cargo transport; LNG cold integration and waste-heat assumptions are not transferable to an ordinary CO2 carrier. Supplementary process inputs were not supplied.

### B1-02 — CO2 Reduction by Combining Methanation With the Blast Furnace

Kawashiri, Kashihara & Fukada (2023). 10.33313/387/045. AISTech proceedings; Rist-diagram calculation.

A carbon-recycling blast-furnace calculation compares methane recycling with direct hydrogen injection. Table 1 (p6) reports carbon consumption of 425, 324 and 293 kg/t hot metal for conventional, hydrogen and recycling cases; corresponding reported reductions are 24% and 31%.

Paper 1 use: Use only if choosing a Japanese steel source or discussing alternative decarbonisation. Keep hot-metal output constant and include hydrogen/methanation utilities when constructing a full-system comparison.

Limits: Recycled methane carbon is excluded from the paper's specific carbon-consumption accounting (p2). This is not geological storage or a whole-chain CCS LCA; the 31% cannot be used as a storage-retention or capture factor.

### B1-03 — Evaluating the impact of CO2 capture and storage on total efficiency A lifecycle analysis

García-Tenorio Corcuera & Petrakopoulou (2025). 10.1016/j.clet.2025.101002. Journal article; hypothetical power-plant lifecycle-energy model.

Hypothetical UK and Australian natural-gas and coal cases account for fuel preparation, conversion and CCS. The reference capture fraction is 95%. Table 3 (p5) assembles capture, compression and injection energy data from other publications. Results show strong dependence on fuel preparation and capture assumptions.

Paper 1 use: Use the process inventory structure and sensitivity logic. Literature inputs in its Table 3 remain secondary evidence for the underlying technologies. Reported total efficiency is an energy-accounting metric, not net GHG mitigation.

Limits: Several unit/summary problems require resolution before calibration: MJ/MWnet lacks an explicit time basis in the reported energy metric; abstract says losses exceed 50% in both fuels whereas detailed NG results reach about 49%; body p9 labels the 3.6/8.43 Mt/year comparison at 90% capture but conclusion p10 says 95%. Do not quote these as harmonised measured penalties.

### B1-04 — CO2 Sequestration in Deepwater Sediments Offshore Japan

Pilisi, Ghorbani & Vasantharajan (2012). CMTC-151756. Conference paper; conceptual offshore feasibility/simulation.

Three ultra-deepwater Japanese sediment cases model shallow subseabed injection under high-pressure, low-temperature gravitational trapping. Table 3 (p10) specifies 5,000 tons/day for each case; injection lasts 25 years, followed by 225 years of migration simulation. Deeper/hotter injection can reverse the density advantage.

Paper 1 use: Use as an alternative Japanese storage concept and to demonstrate conditional retention and the importance of injection depth/temperature. Preserve the paper's original mass unit and speculative technology boundary.

Limits: A 2012 feasibility concept with unavailable offshore storage/injection vessels at the time of publication is not evidence of present service availability. Large assumed injection rates are not tested deliverability. Simulated immobility is not a measured permanent-retention fraction or proof of greater safety across sites.

### B1-05 — Independent Study Addresses Causes of Challenges in Asia Pacific Flagship CCS Project

Carpenter; synopsis of Sabzabadi, Gladman & Billingsley (2025). SPE-1225-0011-JPT; synopsis of SPE-225882. JPT technical-paper synopsis; underlying paper not supplied.

The synopsis attributes Gorgon constraints to water treatment/reinjection and pressure management rather than failure of CO2 containment. It reports August 2019 injection start, a design rate described as 150 kg/s or 4 Mt/year, and four water-production wells. More brine cannot be extracted if its receiving formation cannot accept treated water.

Paper 1 use: Use as secondary operational context: effective CO2 delivery depends on auxiliary water-disposal systems, not just CO2 well injectivity. Track source chronology and independent verification.

Limits: Do not present the synopsis as the underlying full technical paper or an audited current operational dataset. It prints sustained injection as “1.6 tonnes per year” (p3); retain the text and flag the apparent scale/unit error. Do not silently replace it with 1.6 Mt/year. Continuous annualisation of 150 kg/s also differs from 4 Mt/year unless an operating factor is assumed.

### B1-06 — Openhole completion integrity analysis for life of CO2 injector well

Rashidi et al. (2024). ARMA-IGS-2024-0222. Conference paper; coupled-model-informed wellbore stability.

An offshore Sarawak injector is assessed during drilling, brine displacement, injection and stoppages using stress, pressure and temperature outputs from a thermal/dynamic/geomechanical model. Cooling and changing wellbore support cause different shear/tensile failures over time. A perforated liner is selected instead of an unsupported openhole.

Paper 1 use: Use to justify interruption/restart constraints and time-dependent usable injection service. Temperature reductions of 78 and 139 degrees Fahrenheit at later stages are differences, not absolute temperatures.

Limits: Pressure-gradient equivalents in ppg and failure intervals are well-specific simulated conditions. They do not establish a general outage probability, annual rate reduction or universal completion design.

### B1-07 — Leveraging Oil and Gas Legacy for Advanced CCS in Japan Realistic CO2 Storage Simulation in the Higashi-Niigata Gas Field

Kukuu et al. (2025). 10.2118/225812-MS. Conference paper; history-matched reservoir forecast.

Higashi-Niigata models 100 geological realisations, selecting 10 after history matching. Case A uses three CO2 injectors; Case B adds three pressure-relief wells. Injection is assumed from 1 January 2029 to 1 January 2050. Case A reaches its pressure limit around 2040; pressure relief increases injection volume by approximately 25–30% (p8).

Paper 1 use: Best supplied Japanese evidence for a pressure-limited domestic profile and a pressure-management sensitivity. The forecast provides a shape and relative improvement, not a confirmed commercial injection service.

Limits: Figures 11/17/19 lack visible numerical vertical-axis scales in the supplied PDF (visually checked pp7/9). Absolute injected tonnes and pressure values cannot be reliably digitised. Obtain numerical annual series, initial pressure and well/service access before calibration. Do not invent a Mt/year profile from the relative uplift.

### B1-08 — Unlocking CO2 Injection in Depleted Reservoirs A Flow Assurance Modeling Approach for Carbon Capture and Storage

Charoensuk et al. (2025). 10.4043/35887-MS. Conference paper; steady-state and transient flow assurance/design.

A Sarawak development targets up to 2.0 Mt/year through a 40 km offshore pipeline into shallow/intermediate/deep depleted reservoirs. Early-life thermal/hydraulic limits constrain the shallow case to 37.5% and deep case to 80% of well design capacity under specified conditions. An insulated pipeline is selected over offshore heating and gas-phase transport.

Paper 1 use: Use to represent injection limits as functions of reservoir pressure, arrival temperature, flow and startup state. Table 4 (p10) gives relative energy/cost differences and 60,000 tCO2/year extra GHG for the electric-heater alternative relative to insulation.

Limits: Design/forecast, not measured storage performance or access for imported Japanese CO2. The system handles CO2 separated from sour-gas production, so its industrial counterfactual differs. The paper labels a critical pressure as 73 barg (p3); retain as printed and do not confuse this with absolute-pressure property data.

### B1-09 — 4-D Geomechanics Modelling for Potential CO2 Storage Site in Malaysia – Fault Reactivation and Maximum Pressure Injection Limit

Nik Kamaruddin et al. (2019). IPTC-19491-MS. Conference paper; calibrated 4-D reservoir geomechanics.

A Malaysian carbonate Field X model uses field subsidence and laboratory-derived compaction/creep properties. It recommends maximum injection reservoir pressure of 4,000 psi with a 600 psi safety margin, while minimum horizontal stress during injection is 4,600–6,200 psi (p13).

Paper 1 use: Use to justify a pressure-constrained deliverability envelope and explicit geological uncertainty. Modelled compaction, seabed movement and fault displacement are conditional outcomes, not annual capacities.

Limits: An anonymised field is not a named storage service. The pressure ceiling cannot be transferred to another Malaysian sink or converted directly into tonnes/year without injectivity and well data. Planned 2024 injection start is a 2019 scenario assumption, not evidence it occurred.

### B1-10 — A Decision Framework for CO2 Storage Site Selection in Depleted Reservoirs

Hamid (2026). 10.4043/36331-MS. Conference paper; exploratory pressure-aware economic dispatch.

A four-reservoir hub example supplies up to 10 Mt/year over 20 years with a five-year ramp. Transport distance, reservoir pressure evolution and injectivity influence annual allocation. A far-only route is reported at about USD148 million versus USD230 million in the compared configuration (p11).

Paper 1 use: Use as prior art for dynamic pressure/distance allocation, with emphasis on its screening scope. The paper's body describes economic dispatch rather than an implemented and reported full MILP comparison.

Limits: Inputs are explicitly modified/anonymised (p7). Average reservoir pressure is constrained but flowing bottomhole pressure is allowed above the fracture limit (pp10/12); such cases are not demonstrated injection-feasible. Do not inherit this as a safety constraint for Paper 1. Annual pipeline sizing also needs a fixed-design feasibility check.

### B1-11 — Systematic Feasibility Assessment of Geomechanical Risks for CO2 Injection and Long-Term Storage Incorporating Rock Properties Degradation and Thermal Effects

Tan, Musa & Nik Kamaruddin (2024). ARMA-IGS-2024-0183. Conference paper; analytical geomechanical screening.

An offshore Peninsular Malaysia Field X assessment uses eight offset wells and an analytical caprock/fault workflow. With estimated 50°C cooling, recommended pressures for Seals A–D fall from 2153/2731/3264/3701 psi to 1632/2209/2739/3178 psi (pp5–6, Tables 2–3).

Paper 1 use: Use paired isothermal/cooled pressure limits to motivate thermal sensitivity in deliverability, not fixed universal pressure. Distinguish screen-level correlations, assumed degradation and field calibration.

Limits: No measured rock properties were available for the selected field (p4). The up-to-26% stiffness/strength reduction and up-to-10% Poisson-ratio increase are database-based sensitivity evidence (p3), not directly measured at this site. The text extraction displaces psi/psia headers; values were visually checked and original header labels preserved.

### B1-12 — Geomechanical Evolution of the South-West Hub Carbon Capture and Storage Reservoir in Western Australia

Hosseinzadeh et al. (2026). 10.2118/234571-MS. Conference paper; isothermal coupled reservoir/geomechanics model.

South-West Hub/Harvey modelling describes a conceptual 800,000 tCO2/year, 30-year plan, nine injection wells and a reference BHP constraint of 360 bar at 2948 m (p18). No significant fault failure is predicted for the modelled isothermal pressure-driven response.

Paper 1 use: Use the published reference-case configuration as a scenario, not operational supply. Explicitly retain the omitted thermal stresses and the difference between the 30-year injection programme and 1,000-year containment objective.

Limits: Conference modelling does not establish present commercial availability or shipping access. Some text requires author/data clarification: 37/32 is not 1.125 (p18), a stress gradient is printed only in MPa, and Figure 10's pore-pressure range needs datum/quantity reconciliation. These do not justify silently changing reported numbers.

### B1-13 — Optimising the CO2 Storage Potential in Deep Saline Aquifer by Creating Pressure Sink

Razali et al. (2024). 10.4043/34777-MS. Conference paper; compositional aquifer simulation.

A Malaysian restricted aquifer (K reservoirs, Z field) is simulated with and without brine production. Cumulative effective gas volumes are 4.9 Bscf without production, 80.13 Bscf with one injector/one producer, and 95.44 Bscf with two injectors/one producer. These are about 3%, 51% and 61% of theoretical volume (pp8–13).

Paper 1 use: Direct evidence that nominal pore-volume resource does not equal delivered storage. Model pressure-management cases together with water production, CO2 breakthrough termination and its energy/disposal burden.

Limits: The authors ultimately do not recommend proceeding with Z-field injection planning because volume is small and inputs uncertain (p13). Do not select it as a proven Malaysian sink. Bscf/MMscf cannot be turned into tonnes without declared standard conditions/composition and conversion. PVT/SCAL and permeability include analogue-based inputs.

### B1-14 — Fully coupled inversion on a multi-physical reservoir model – Part II The Ketzin CO2 storage reservoir

Wagner & Wiese (2018). 10.1016/j.ijggc.2018.04.009. Journal article; multi-physical inverse model with field observations.

Ketzin inversion jointly uses hydraulic/CO2 pressure, arrival times and geoelectric observations. A near-injector permeability reduction to about 15 mD (roughly eightfold) and equivalent skin of 10 explain pressure overburden attributed to salt precipitation. Observed/modelled arrivals are 21.7/21.8 days and 271/283 days (p6).

Paper 1 use: Use as evidence for near-well injectivity changes and multi-observation validation. Distinguish calibrated skin/permeability from independent field measurements.

Limits: The earlier hydraulic-barrier hypothesis is not substantiated after suspect data are removed, but non-uniqueness means a barrier is not excluded (p8). Do not turn the eightfold local permeability change into an eightfold annual site-capacity decline.

### B1-15 — Matching Pressure Measurements and Observed CO2 Arrival Times with Static and Dynamic Modelling at the Ketzin Storage site

Class et al. (2015). 10.1016/j.egypro.2015.07.883. Proceedings article; field history matching with two simulators.

Ketzin models match pressure and CO2 arrival despite strong porosity/permeability correlations. Table 3 (p5) compares observed arrival times of 21.7 and 271 days with alternative simulated arrivals; pressure-only fit does not uniquely identify spatial geology.

Paper 1 use: Use separate calibration and prediction periods, record observation timing uncertainty and test alternative parameter sets. The 2018 inversion paper refines some earlier interpretations; these are related studies of one site, not independent replications.

Limits: Table 1 prints a pressure gradient of 1.14 Pa/m (p4, visually confirmed). This is implausible as a normal brine hydrostatic gradient; hold this value pending correction, rather than insert a presumed exponent. Arrival dates depend on sensor location and completion, not merely plume contact.

### B1-16 — Integrated reservoir monitoring at the Illinois Basin – Decatur Project

Couëslan et al. (2014). 10.1016/j.egypro.2014.11.306. Proceedings article; integrated field monitoring.

Decatur couples time-lapse saturation logs, multilevel pressure, fluid chemistry, seismic and microseismic data. Approximately 925,300 tonnes had been injected by 1 September 2014 (p2), against a one-million-tonne three-year goal. Low-permeability layers restrict upward CO2 migration in the monitored interval.

Paper 1 use: Use monitoring-based calibration, separation of pressure front and CO2 plume, and interruptions as operational factors. Retain as-of dates for cumulative injected mass.

Limits: This is a US ethanol-fermentation source, not a fossil Japanese industrial baseline. Monitoring evidence of no detected migration is not a numerical permanence guarantee. The Zone 4 depth is inconsistent between p3 text and the other monitoring evidence; do not use that single text depth uncritically.

### B1-17 — Injection operation and operational pressure–temperature monitoring at the CO2 storage pilot site Ketzin, Germany—Design, results, recommendations

Liebscher et al. (2013). 10.1016/j.ijggc.2013.02.019. Journal article; observed pilot operation and monitoring.

Ketzin recorded 61,396 t by September 2012. Typical injection was 1–3 t/hour, with 3,250 kg/hour nominal plant capacity. BHP rose from about 62 bara initially to 73 bara after five days, then stabilised around 73–79 bara (pp3–5). Downhole monitoring is needed because wellhead signals alone can mislead.

Paper 1 use: Use actual operation as a small-scale validation benchmark, preserving measurement uncertainty and stop/restart behaviour. Monthly rates and pressure can test a simplified pressure-response implementation.

Limits: Pilot rates and reservoir data are not commercial Japanese/Malaysian/Australian service. The 61,396 t as-of-2012 and later approximately 67,000 t final injection in other Ketzin papers refer to different dates, not contradictory estimates. Correct for gauge/absolute pressure before comparison.

### B1-18 — CO2 Plume Tracking and History Matching Using Multilevel Pressure Monitoring at the Illinois Basin – Decatur Project

Strandli, Mehnert & Benson (2014). 10.1016/j.egypro.2014.11.483. Proceedings article; pressure-based field history matching.

A layered radially symmetric Decatur model is calibrated over 40 days and compared against two years of pressure data. It uses an approximately 150 mD, 23–24 m injection interval and predicts mainly lateral migration below low-permeability layers (p8).

Paper 1 use: Use multilevel pressure and held-out time periods for validation. The larger-time mismatch is expressly unresolved; a successful short fit is not proof of long-term prediction.

Limits: Isothermal 49°C model neglects salinity explicitly, then rescales permeability for viscosity; several parameters are calibrated. US biogenic source and pressure-history fit do not define international route lifecycle emissions or a universal retained fraction.

### B1-19 — Optimization and economic evaluation of carbon dioxide BOG Re-liquefaction process considering storage pressure and nitrogen impurity

Jeong et al. (2025). 10.1016/j.energy.2025.135837. Journal article; HYSYS/PSO process optimisation.

Six reliquefaction process/pressure cases are compared at 0.05/0.10/0.15 mol% liquid nitrogen impurity. A 50,000 m3 carrier is assumed with 98% laden and 5% ballast filling, 0.1%/day mass-based boil-off, and 4000 operating hours/year for each voyage state. Annual CO2 includes purge plus auxiliary-generator emissions. Table 6 and Appendix A.6 have been transcribed into structured scenario data.

Paper 1 use: Use process-specific BOG and power trade-offs to avoid treating all boil-off as a cargo loss. Derived generator factor is 0.633185 kgCO2/kWh from 197.5 g fuel/kWh and 3.206 tCO2/t fuel, excluding upstream fuel impacts. The annual-case comparison is not propulsion or full-chain LCA.

Limits: Preserve the case/impurity combinations. Text on p8 claiming 79.2–84.6% and 89.8–95.6% reductions in compression-power emissions appears inconsistent with its much smaller stated power reductions and constant generator factor. Annual schedule (6 voyages/year and 8000 operating hours) is a modelling assumption, not a route-calibrated schedule.

### B1-20 — Interoperability and energy optimization in low pressure ship to medium pressure terminal interfacing

Deligiannis et al. (2026). 10.1016/j.ijggc.2025.104544. Journal article; COSSMOS thermodynamic interface simulation.

LP ships (7–10 bara) interface with MP terminals (12–20 bara). Case specifications use three 7300 m3 tanks (sensitivity 5840–8760 m3 each), 96% filling and 4% heel. Tables 6–7 (pp13–14) give nine pressure-pair cases with and without loading-stream subcooling. Tables are transcribed with mass, power, cost and original specific-demand labels.

Paper 1 use: Use for explicit loading/unloading and vapor-return conditioning. Avoid a route-independent fixed terminal factor and avoid double-counting power already included in an integrated process result. Pressure units here are explicitly absolute.

Limits: Specific-demand labels kWel/ton are dimensionally inconsistent with the stated kWh/ton intent; several values are consistent with a 12-hour transfer. Derived conversions are separate and conditional. Some textual claims of lower subcooler cost are case dependent; the full nine-case table must govern. These are process energy/cost results, not route-wide GHG factors.

## Files and reproducibility

The workbook preserves the original proposal-only sheets and adds Batch1 studies, Batch1 values, BOG scenarios, Interface scenarios and Evidence issues. CSVs contain the same batch tables. The source manifest records uploaded filenames, source locations, page counts and SHA256 hashes. Numbered text files permit page-level auditing; original PDFs remain in the uploaded-file directory. build_batch1.py reproduces this pack from those files. No repository source or original proposal was modified.
