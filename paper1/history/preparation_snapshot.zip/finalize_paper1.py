from pathlib import Path
from collections import Counter
import re,math,json,csv,zipfile,shutil
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from docx import Document

B=Path(__file__).parent;O=B/'master_outputs'
w=load_workbook(O/'Paper_1_master_evidence.xlsx')
# Display-only repairs for concatenated labels. Original numerical fields stay unchanged.
c=Counter()
for p in B.glob('batch*/B*/full.txt'):c.update(v.lower() for v in re.findall(r'[A-Za-z]{2,}',p.read_text(errors='replace')))
for s in ['BAU','BHP','CO','CO2','GHG','GWP','Mt','Gt','USD','EUR','CAPEX','OPEX','WtE','LCA','ANN','MCR','PGA','MPa','barg','bara','gamma','min','max','printed']:c[s.lower()]+=1000
total=sum(c.values())
def split(t):
 if len(t)<9:return t
 lo=t.lower();dp=[None]*(len(t)+1);dp[0]=(0,[])
 for end in range(1,len(t)+1):
  best=None
  for start in range(max(0,end-30),end):
   word=lo[start:end]
   if dp[start] is None or c[word]<3 or len(word)<2:continue
   cand=(dp[start][0]+math.log(total/c[word])+1,dp[start][1]+[t[start:end]])
   if best is None or cand[0]<best[0]:best=cand
  dp[end]=best
 return ' '.join(dp[-1][1]) if dp[-1] else t
overrides={'Printedtotalannualrate':'Printed total annual rate','Directtransportemissionscoefficientgamma1':'Direct transport emissions coefficient gamma1','Other-nodegridcarbonintensity':'Other-node grid carbon intensity','Chaincostwithoffshore-onlystorage':'Chain cost with offshore-only storage'}
sheet=w['New located values']
numeric_before=[(row[3].value,row[5].value) for row in list(sheet.rows)[1:]]
for row in list(sheet.rows)[1:]:
 cell=row[2]
 if ' ' not in str(cell.value):cell.value=overrides.get(cell.value,split(cell.value))
 cell=row[4];txt=str(cell.value)
 for a,b in [('degreesC','degrees C'),('barg','barg'),('millionEUR2017','million EUR (2017)'),('ofmean','of mean'),('oflithostaticpressure','of lithostatic pressure')]:txt=txt.replace(a,b)
 cell.value=txt
assert numeric_before==[(row[3].value,row[5].value) for row in list(sheet.rows)[1:]]
for sheetname in ['Master library','New located values','Evidence issues','Proposal claim audit']:
 s=w[sheetname]
 for row in s.iter_rows(min_row=2):
  for cell in row:cell.alignment=Alignment(wrap_text=True,vertical='top')
 s.auto_filter.ref=s.dimensions
# Clarify old gap list rather than erasing the initial audit trail.
g=w['Input gaps']
for row in list(g.rows)[1:]:
 row[4].value='Baseline-case gap remains; partial literature evidence now in master sheets'
 row[8].value='Initial checklist preserved. A published scenario value is not an approved regional input.'
claims=w['Proposal claim audit']
for row in list(claims.rows)[1:]:
 # Readability only; manual notes retain exact scientific semantics.
 text=str(row[2].value)
 for a,b in [('25-year yearly','25-year, yearly'),('2025 full','2025 full'),('33articles','33 articles'),('110-plant','110-plant'),('15what-if','15 what-if'),('30years','30 years'),('6year','6-year'),('32.8–142.1kgCO2e/tstored','32.8–142.1 kgCO2e/t stored'),('netGHG','net GHG'),('7/15barg','7/15 barg'),('Buntercases','Bunter cases'),('0.4Mt/year,715km,99%,33.8EUR/t,41.9EUR/t last1%,1.9EUR/t','0.4 Mt/year, 715 km, 99%, EUR33.8/t, EUR41.9/t for the last 1%, EUR1.9/t'),('Describe41.9','Describe 41.9'),('cost.','cost.')]:text=text.replace(a,b)
 row[2].value=text
w.save(O/'Paper_1_master_evidence.xlsx')
old=list(w['Batch1 values'].values)[1:];new=list(w['New located values'].values)[1:]
head=[x.value for x in w['Batch1 values'][1]]
for name,rows in [('new_values.csv',new),('all_located_values.csv',old+new)]:
 with (O/name).open('w',newline='',encoding='utf-8-sig') as f:out=csv.writer(f);out.writerow(head);out.writerows(rows)

original=(O/'Paper_1_master_digest.md').read_text()
appendix=original.split('## Later-batch per-paper digest',1)[1].replace('Paper1role:','Paper 1 role:')
main='''# Paper 1 — consolidated evidence digest and research preparation

## Coverage and limits
The library contains 84 uploaded PDF files representing 83 unique publications and 1,190 physical PDF pages. B2-17 and B3-46 are the same publication, identified by their title, authors and DOI; both file paths are retained. All files were downloaded and made searchable. Twenty first-batch papers received targeted methods/results extraction, and 19 later papers have selected sections checked. The remaining 44 unique publications have abstract/relevance screening; their detailed numerical inventories are not yet fully extracted. Each reading stage is recorded in the workbook.

The workbook contains 1,097 page-located or explicitly derived value records. A record can contain a published range or grouped operating conditions; records are not independent measurements. Four process datasets are tabulated: 18 BOG cases, 18 ship–terminal interface cases, 18 vessel designs and 14 liquefaction pressure/feed cases. Original proposal-only values remain separate, and a claim-audit sheet links 13 of the proposal's 14 references to supplied PDFs. The Budiarto et al. (2025) paper remains unsupplied.

This is a substantial initial digest and a preparation pack, not a completed systematic review or a calibrated regional model. Primary-source extraction identifies what a paper reports; it does not validate simulated inputs as site observations. Plot-only data were not invented, and unresolved units remain on hold. Supplements and some detailed inventories still require review. The Drive folder and oversized ZIP were not accessed; the standalone planetary-limit PDF was subsequently read.

## Main research decision
Paper 1 should test the decision value of added model detail rather than claim the first dynamic CCS assessment or the first common-baseline calculation. Becattini et al. (2022) already model yearly system emissions against business-as-usual, overseas transport and a delayed hypothetical domestic sink. Lee et al. (2014) include time-dependent sink constraints and compensatory power. Nöhl et al. (2025) define cumulative transport-infrastructure carbon payback. Fraga et al. (2024) combine multi-period logistics, storage and post-capture GHG optimisation. Bertoni et al. (2025) embed reservoir dynamics in infrastructure optimisation, and Jeon et al. (2026) couple tank/BOG dynamics to shipping GHG intensity.

The narrower hypothesis is whether jointly resolving usable injection service and voyage/terminal operations materially changes domestic-versus-foreign net mitigation, break-even regions or pathway ranking under a matched industrial baseline. The B0–B3 comparison should measure both separate effects and their interaction. It must allow a null result: the Bunter study by Kolster et al. provides a specific case where large multi-year injection variations have little long-horizon effect. The present review does not prove that the exact proposed hypothesis is absent from all literature.

## Values most useful for the first model
- Bjerketvedt et al. (B2-08, pp6–8): 0.4 MtCO₂/year, 715 km, 12-knot design speed and candidate capacities of 3,750/5,000/7,500 tonnes. Constant-power fuel rates are 0.5/0.6/0.7 tonnes/hour; alternative full-speed rates are 0.8/0.9/1.1. At 99% transport completion, the buffer is 5,120 tonnes and average cost EUR33.8/t. At 100%, the buffer is 5,890 tonnes, while the average cost of the additional final percentage point is EUR41.9/t.
- Roussanaly et al. (B3-38, pp7–8): 26 km/hour, 12 hours of export handling, 12 hours of harbour receiving or 36 hours offshore, 8,400 operating hours/year and buffers of 1.2 times ship capacity. Pure-feed liquefaction energy is 96.3/90.4 kWh/t at 7/15 barg, versus 17.4/9.0 kWh/t for the pressurised inland-feed cases. These are different feed boundaries, not an uncertainty interval.
- Fraga et al. (B2-12, pp18/20): best-solution post-capture burdens are 32.8/46.3 kgCO₂e/t stored for Northern Lights, 142.1/139.0 for Stella Maris, and 41.5/39.2 for the combined concept at 0.7/1.5 MPa. Capture is excluded. The LNG engine factor is 629 gCO₂e/kWh, comprising 488 from combustion and 141 upstream (p10); do not add upstream emissions again.
- Higashi-Niigata (B1-07, pp6–9): three injectors with or without three pressure-relief wells, and a reported 25–30% volume increase in the latter case. The supplied plots lack visible numerical vertical-axis scales, so an absolute annual injection series cannot be recovered reliably.
- Malaysian thermal screening (B1-11, pp5–6): with estimated 50°C cooling, recommended pressure limits for Seals A–D fall from 2,153/2,731/3,264/3,701 psi to 1,632/2,209/2,739/3,178 psi. These site-specific pressure reductions cannot directly become annual rate reductions.
- Gidden et al. (B2-18, pp1/2/10): a central prudent global resource estimate of 1,460 GtCO₂ and sensitivity range 1,290–2,710 Gt, based on geospatial risk exclusions and a pressure-related, 50-year conversion assumption. This is neither a legal quota nor annual storage service for the proposed countries.

## Corrections that matter before calibration
The evidence-issues sheet contains 29 items. The Bjerketvedt buffer ratio must state its completion case and denominator: 5,120 tonnes is about 102% of a 5,000-tonne ship, whereas 5,890 is about 118%. The 118% ratio in the 99% case refers to average-cycle captured mass.

Kang et al. print approximately 2,800 kg/s as corresponding to 1 Mt/year; the continuous annual conversion does not match. Karvounis and Blunt's Table 5 prints a total annual rate of 22,620 Mt/year, while its five country rows sum to 14,664. Both remain flagged; neither is silently corrected into an empirical input. Earlier holds include the Gorgon synopsis's sustained-rate units, the Ketzin pressure gradient, thermal-table pressure datums, BOG power-percentage discrepancies and ship-interface specific-energy labels.

Aspelund et al.'s 1.4% chain CO₂ burden assumes effectively zero-emission electricity for liquefaction; it is not a modern generic lifecycle transport factor. Fraga's 46-day venting-onset assumption and Jeon's approximately 13-day GHG crossover concern different tank, impurity and operating configurations. The distinction is a transferability issue rather than evidence of a universal voyage threshold.

## Paper 1 preparation
The accompanying working manuscript preserves the proposal's three objectives and provides a cautious abstract, sourced introduction, model equations, B0–B3 contrasts, scenario/validation design and unpopulated results outline. It does not fabricate numerical findings. It adds pressure-management burdens, thermal operating limits, BOG/heel inventories and terminal pressure mismatch where supported by data. A literature figure separately illustrates reported pressure and conditioning-energy sensitivities; it is explicitly not a simulation result for the proposed regional route.

The model still needs a named Japanese source and no-CCS baseline, numerical annual site service and allocated capacity, accessible terminals and routes, compatible ship fuel curves, location/year electricity and upstream fuel factors, water-disposal energy/feasibility, asset inventories and a retention horizon. Governance papers organise feasibility and liability questions but do not establish present route permissions. Complete the pending inventories and supplementary data before treating the workbook as a harmonised parameter file.

## Per-paper digests
Reading stage and primary locations are recorded in Master library. First-batch digests below reflect targeted extraction; later entries explicitly identify abstract-level screens versus checked sections.
'''
for r in list(w['Batch1 studies'].values)[1:]:
 main+=f'\n### {r[0]} — {r[1]}\n\n{r[2]} ({r[3]}). {r[4]}.\n\n{r[9]}\n\nUse: {r[10]}\n\nLimits: {r[11]}\n'
main+='\n## Later-batch digests\n'+appendix
(O/'Paper_1_master_digest.md').write_text(main,encoding='utf-8')
def write_docx(text,path):
 d=Document()
 for l in text.splitlines():
  if l.startswith('### '):d.add_heading(l[4:],2)
  elif l.startswith('## '):d.add_heading(l[3:],1)
  elif l.startswith('# '):d.add_heading(l[2:],0)
  elif l.startswith('- '):d.add_paragraph(l[2:],style='List Bullet')
  elif l.strip():d.add_paragraph(l)
 d.save(path)
write_docx(main,O/'Paper_1_master_digest.docx')
man=(O/'Paper_1_working_manuscript.md').read_text()
man=re.sub(r'(?<=al\.)(?=20\d\d)',' ',man)
man=re.sub(r'(?<=DOI)(?=10\.)',' ',man)
for a,b in [('et al.202','et al. 202'),('et al.201','et al. 201'),('Chen2014','Chen 2014'),('Benson2020','Benson 2020'),('Roussanaly2020','Roussanaly 2020'),('Krevor2024','Krevor 2024')]:man=man.replace(a,b)
(O/'Paper_1_working_manuscript.md').write_text(man,encoding='utf-8');write_docx(man,O/'Paper_1_working_manuscript.docx')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
fig,ax=plt.subplots(1,2,figsize=(11.8,4.6),layout='constrained')
x=np.arange(4);width=.36
ax[0].bar(x-width/2,[2153,2731,3264,3701],width,label='Isothermal',color='#234E70')
ax[0].bar(x+width/2,[1632,2209,2739,3178],width,label='Estimated 50°C cooling',color='#C96B43')
ax[0].set_xticks(x,['Seal A','Seal B','Seal C','Seal D']);ax[0].set_ylabel('Recommended maximum injection pressure (psi as reported)');ax[0].set_title('(a) Site-specific thermal sensitivity');ax[0].legend(frameon=False,fontsize=8);ax[0].set_ylim(0,4400)
x=np.arange(2)
ax[1].bar(x-width/2,[96.3,17.4],width,label='7 barg',color='#234E70');ax[1].bar(x+width/2,[90.4,9.0],width,label='15 barg',color='#C96B43')
ax[1].set_xticks(x,['Pure-feed base case','Pressurised inland-feed case']);ax[1].set_ylabel('Specific liquefaction electricity (kWh/t CO₂)');ax[1].set_title('(b) Feed state changes conditioning demand');ax[1].legend(frameon=False,fontsize=8)
for a in ax:
 a.spines[['top','right']].set_visible(False);a.grid(axis='y',alpha=.2);a.set_axisbelow(True)
fig.suptitle('Published scenario sensitivities — not results for the proposed regional route',fontsize=11)
fig.savefig(O/'Literature_parameter_sensitivities.png',dpi=220)
fig.savefig(O/'Literature_parameter_sensitivities.pdf')
plt.close(fig)
(O/'Literature_figure_caption.md').write_text('Published scenario sensitivities. (a) Tan, Musa and Nik Kamaruddin (2024), ARMA-IGS-2024-0183, physical PDF pp5–6, Tables2–3, four seals in an anonymised Malaysian FieldX; pressure units preserved as psi in the recommended-limit column. Values are analytical model recommendations, not observed failure pressures. (b) Roussanaly et al. (2021), DOI10.3390/en14185635, physical PDF p7, Table3, 1MtCO2/year liquefaction cases. Pure-feed and inland-feed cases have different inlet states. Values are not a confidence interval. The plots combine separate literature examples for illustration; they do not calibrate one shared site or route.\n',encoding='utf-8')

# Full artifact checks and an explicit outstanding-work record.
check=load_workbook(O/'Paper_1_master_evidence.xlsx',read_only=True)
assert check['Master library'].max_row==85
assert check['Batch1 values'].max_row+check['New located values'].max_row-2==1097
assert check['Provisional values'].max_row==21
assert check['Roussanaly ship designs'].max_row==19
assert check['Liquefaction pressure cases'].max_row==15
for sh in ['Batch1 values','New located values']:
 for r in list(check[sh].values)[1:]:
  assert r[0] and r[1] and r[5] and r[6],(sh,r)
  assert 1<=int(r[5])<=len(json.loads((B/f'batch{r[1][1]}'/r[1]/'pages.json').read_text()))
assert sum(r[9] is not None for r in list(check['Master library'].values)[1:])==1
check.close()
assert len(Document(O/'Paper_1_working_manuscript.docx').paragraphs)>80
assert len(Document(O/'Paper_1_master_digest.docx').paragraphs)>250
pending='''# Outstanding work

- Detailed inventories for the44unique publications markedabstract/relevancescreened are not complete. Abstractscreening is not afullpaperdigest.
- Obtain unsuppliedsupplements and theBudiarto2025paper; verifyitsclaimedannualinjectivityprofiles.
- Resolve29source/dataissues, especially rateunits, pressuregradients/datums, aggregateannualrates and power-versus-energylabels.
- Obtain numericalHigashi-Niigataannualinjectionseries; plottedverticalscalescannotbereliablyrecoveredfromthesuppliedPDF.
- SelectanactualcommonJapaneseindustrialsource and accessible, namedstorage-serviceoptions; identifyroute-specificfuel/terminalandLCAinputs.
- BuildandverifytheB0–B3modelonlyaftertraceableinputselection; no numericalresearchresultsarecurrentlyavailable.
'''
# Keep this checklist readable rather than converting it into an implicit completion claim.
pending='''# Outstanding work

- Complete detailed inventories for the 44 unique publications currently marked as abstract/relevance screened.
- Obtain unsupplied supplements and the Budiarto (2025) paper; verify its claimed annual injectivity profiles.
- Resolve the 29 source/data issues, particularly rate units, pressure gradients/datums, aggregate annual rates and power-versus-energy labels.
- Obtain numerical annual injection series for Higashi-Niigata; vertical scales cannot be reliably recovered from the supplied PDF.
- Select a common Japanese industrial source and accessible named sinks, with route-specific fuel, terminal and lifecycle inputs.
- Build and verify B0–B3 only after traceable input selection. Numerical research results remain ungenerated.
'''
(O/'Outstanding_work.md').write_text(pending,encoding='utf-8')
(O/'README.md').write_text('Start with Paper_1_master_digest.docx and Paper_1_master_evidence.xlsx. Paper_1_working_manuscript.docx is a sourced scaffold with no fabricated results. 84 uploaded files correspond to83unique publications; reading depth is explicit. 1097 located/derived records are not1097independent empirical measurements. See Outstanding_work.md for pending detailed extraction and model-data gaps. Source PDF paths/hashes and numbered page text are retained; the lightweight ZIP does not duplicate the PDFs. build_master.py followed by finalize_paper1.py reproduces the master outputs from the prior batch files.\n',encoding='utf-8')
with zipfile.ZipFile(O/'Paper_1_research_pack.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(O.rglob('*')):
  if f.is_file() and f.suffix!='.zip':z.write(f,str(f.relative_to(O)))
 z.write(B/'build_master.py','build_master.py');z.write(__file__,'finalize_paper1.py')
with zipfile.ZipFile(O/'Paper_1_research_pack.zip') as z:assert z.testzip() is None
print(json.dumps({'checks':'XLSX, DOCX, source page locators, duplicate count and ZIP integrity passed','pack_bytes':(O/'Paper_1_research_pack.zip').stat().st_size,'located_records':1097,'screened_unique':83,'detailed_or_targeted':39,'remaining_abstract_screens':44},indent=2))
