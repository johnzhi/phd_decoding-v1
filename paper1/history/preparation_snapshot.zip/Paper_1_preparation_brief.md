# Paper 1 — initial research preparation

## Evidence status
Prepared from the uploaded “Paper_1_Proposal v1 25102026.docx”. The original is unchanged. This is a proposal-based preparation pack, not a digest of the Google Drive papers. The Drive connector is unavailable and the folder request was blocked by the configured proxy (HTTP CONNECT 403). No folder inventory, full text or supplement has been inspected. All paper-specific statements below describe the proposal's account and remain subject to primary-source verification. Document contents were treated as reference material, not instructions.

## Research question and defensible contribution
For identical industrial production and a common no-CCS counterfactual, when does additional retained CO2 enabled by foreign storage outweigh incremental whole-chain GHG emissions? Does resolving both annual sink deliverability and ship operations materially change that conclusion relative to simpler screening?

The proposal's most defensible contribution is a measured comparison of model resolution, climate break-even regions and pathway-ranking robustness. Dynamic CCS networks, shipping uncertainty, delayed storage readiness and transport-enabled additional sequestration are already identified as prior work in the proposal. Their integration alone should not be claimed as new. A complete reading of the closest prior papers and their supplements is still required to establish the gap. A null interaction or unchanged route ranking can also establish where a simpler model is adequate.

## Proposed study structure
1. Establish a controlled one-source/two-sink experiment before making country-specific claims. Match source output, eligible CO2 supply, baseline, capture technology, operating policy and accounting conventions.
2. Run domestic-only, foreign-only and mixed pathways with feasible injection and logistics. Keep annual captured, transported, injected, lost, vented, buffered and retained masses separate.
3. Apply B0: static injection/fixed transport factor; B1: dynamic injection/fixed factor; B2: static injection/operational shipping; B3: dynamic injection/operational shipping.
4. Report D_j = A_F,j - A_D,j; total model-resolution contrast D_3 - D_0; deliverability effect D_1 - D_0; operations effect D_2 - D_0; interaction D_3 - D_2 - D_1 + D_0.
5. Run an equal-cumulative-retention control where feasible, then the unequal-deliverability comparison. Equal cumulative storage does not imply equal injection timing, capture energy or fleet use.
6. Map Delta A = 0 across deliverability, commissioning, route distance, ship loading and energy factors. Discrete fleet additions can produce multiple thresholds or disconnected regions.
7. Add the Japan–Malaysia–Australia application only after a named source and site-specific sink evidence are available. If necessary, use one defensible domestic–foreign pair. Country storage resources cannot substitute for annual accessible injection service.

## Values captured so far
The workbook contains 20 provisional numerical/context claims from the proposal. Its 14 reference records are bibliography entries, not confirmed Drive-folder contents. These values are a verification queue; none is certified for model calibration.

The proposal reports a Norwegian shipping case at 0.4 MtCO2/year (400,000 tCO2/year) and 715 km, with a 99% completion point and EUR33.8/tCO2 average transport-chain cost. It describes EUR41.9/tCO2 as the marginal cost for the final percentage point toward 100% completion, not an average cost at full completion. It also reports an approximately EUR1.9/tCO2 expected-cost difference for deterministic planning. Exact definitions and currency year require checking in Bjerketvedt et al. (2020).

For Fraga et al. (2024, journal), the proposal reports a 30-year horizon and post-capture GHG burdens of 3.3–14.2% of stored CO2. These scenario endpoints are not a confidence interval or a full-chain avoided-emissions factor. The proposal separately describes a one-tonne-transported reference flow; that denominator must not be substituted for a stored-tonne denominator without reconciliation.

The remaining records include 110 Swedish CHP plants (Beiron), 33 LCA studies and fewer than half with full-chain coverage (Emborg), a 25-year rollout horizon (Becattini), 15 scenarios and a 30-year horizon (Fraga conference), and the 7/15 barg comparison named in the Roussanaly reference title. Pressure values are gauge pressures and title-level evidence only.

## Paper-reading order and extraction
First: Fraga journal and supplement, Bjerketvedt, Budiarto and its injection inputs, and Becattini. These address the closest combination of annual deployment, shipping operations, reservoir constraints and GHG accounting. Next: Roussanaly for pressure/conditioning, Johnsson, Karvounis and Kolster for injectivity. Then: Yuan and Emborg for boundaries, Burger and Fraga conference for the novelty comparison. Kang and Beiron provide supporting cost/scale evidence with restricted transferability.

For each PDF, confirm metadata and version, then read methods, input tables, figures, supplementary data and limitations. Extract one record per value and scenario with primary page/table/figure, exact units, denominator, geography, operating state, date, system boundary and uncertainty. Record conflicting values rather than silently choosing one. Digitised graph values need a digitisation flag and approximation uncertainty. Record “not reported” distinctly from “not yet checked”.

## Data still needed
The workbook lists source/baseline, storage, marine, energy/GHG and control/uncertainty requirements. Critical missing inputs are a named Japanese source and no-CCS emissions profile; actual sink identities, annual injection limits and availability; feasible port-to-port routes; compatible vessel cargo states, fuel rates and operating schedules; conditioning energy; location/year electricity factors; fuel life-cycle factors; and retention accounting. These cannot be recovered from broad cost benchmarks alone.

## Method decisions to settle before coding
- Define the static injection proxy before comparisons. A nameplate constant, annual-average profile and cumulative-capacity-preserving proxy answer different questions. Use sensitivity controls so model differences are not merely arbitrary calibration choices.
- Define one fixed transport factor at a declared reference operating point for B0/B1, with a consistent process boundary. Do not tune it after observing B3.
- Separate physical capture potential from realised capture. Curtailment or capture-and-release policies change both retained mass and capture-energy burdens; apply the chosen policy consistently.
- Treat annual fleet-hour limits as necessary screening constraints. They do not by themselves prove vessel scheduling, port availability or buffer feasibility. Realised trip loading must be reconciled with integer voyages.
- Clarify the endpoint treatment of captured CO2 still in tanks or ships at the end of 2050. The explicit baseline comparison and retained-mass shortcut must use compatible terminal fates and retention horizons.
- Avoid counting captured-stream releases both as lost retention and an additional source-CO2 GHG burden. Upstream fuel and non-CO2 gases still belong in the incremental inventory.
- Keep availability, capacity and injection limit definitions independent. Do not apply downtime twice if it is already embedded in a reported effective injection rate or operating-hours input.
- Use consistent GHG metric and inventory allocation for construction, residual asset life, monitoring and decommissioning. Report unsupported exclusions.
- Do not assign probability distributions merely because a study supplies scenario minima and maxima. Use deterministic bounds until joint distributions and dependencies are justified.

## Publication outputs to prepare
Tables: study/boundary comparison; source and sink inputs; voyage/conditioning parameters; model design; annual and cumulative pathway outcomes. Figures: system boundary and material flow; annual sink deliverability and retained CO2; utilisation versus absolute shipping emissions and intensity; carbon break-even regions; B0–B3 contrasts and interaction; sensitivity of pathway ranking. No result panels should be populated before a traceable dataset and verified model exist.

Suggested manuscript sequence: Introduction with verified gap; Methods with matched counterfactual and operational constraints; controlled experiment; evidence-supported regional application; model comparison and uncertainty; discussion of transferability; limitations and conclusions conditional on actual findings. Preserve the proposal's three objectives while replacing literature assertions with primary-source-supported statements.

## Readiness and next step
Prepared: source proposal extraction, 14-study reading register, 20 provisional numerical/context records, input-gap register, B0–B3 design and validation checklist. Not completed: Drive-paper reading, primary numerical verification, site selection, empirical calibration, modelling or manuscript results. Upload the PDFs and supplements, preferably as a ZIP, or provide a usable Drive connector to continue the actual literature digest.
